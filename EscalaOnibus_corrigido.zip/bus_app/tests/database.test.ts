import { describe, it, expect, beforeEach, vi } from "vitest";

// Mock AsyncStorage
const storage: Record<string, string> = {};
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(async (key: string) => storage[key] ?? null),
    setItem: vi.fn(async (key: string, value: string) => { storage[key] = value; }),
    removeItem: vi.fn(async (key: string) => { delete storage[key]; }),
    multiRemove: vi.fn(async (keys: string[]) => { keys.forEach((k) => delete storage[k]); }),
  },
}));

import { db } from "../lib/database";

describe("Database - Users", () => {
  beforeEach(async () => {
    // Clear storage and re-initialize
    Object.keys(storage).forEach((k) => delete storage[k]);
    await db.initialize();
  });

  it("should initialize with admin user", async () => {
    const admin = await db.getUserByUsername("admin");
    expect(admin).not.toBeNull();
    expect(admin?.role).toBe("admin");
    expect(admin?.password).toBe("admin123");
  });

  it("should create a driver", async () => {
    const driver = await db.createDriver({
      name: "João Silva",
      username: "joao.silva",
      password: "senha123",
      whatsapp: "(11) 99999-9999",
      driverId: "MOT-001",
    });
    expect(driver.id).toBeDefined();
    expect(driver.role).toBe("driver");
    expect(driver.name).toBe("João Silva");
  });

  it("should get drivers list", async () => {
    await db.createDriver({
      name: "Maria Santos",
      username: "maria.santos",
      password: "senha456",
      driverId: "MOT-002",
    });
    const drivers = await db.getDrivers();
    expect(drivers.length).toBeGreaterThanOrEqual(1);
    expect(drivers.every((d) => d.role === "driver")).toBe(true);
  });

  it("should update a user", async () => {
    const driver = await db.createDriver({
      name: "Pedro Costa",
      username: "pedro.costa",
      password: "senha789",
      driverId: "MOT-003",
    });
    const updated = await db.updateUser(driver.id, { name: "Pedro Alves Costa" });
    expect(updated?.name).toBe("Pedro Alves Costa");
  });

  it("should delete a user", async () => {
    const driver = await db.createDriver({
      name: "Ana Lima",
      username: "ana.lima",
      password: "senha000",
      driverId: "MOT-004",
    });
    const result = await db.deleteUser(driver.id);
    expect(result).toBe(true);
    const found = await db.getUserById(driver.id);
    expect(found).toBeNull();
  });
});

describe("Database - Schedules", () => {
  beforeEach(async () => {
    Object.keys(storage).forEach((k) => delete storage[k]);
    await db.initialize();
  });

  it("should create a schedule", async () => {
    const schedule = await db.createSchedule({
      date: "2025-12-25",
      line: "101 - Centro/Terminal",
      driverId: "driver-001",
      driverName: "João Silva",
      busModel: "Mercedes-Benz OF 1721",
      busPrefix: "4521",
      startTime: "06:00",
      endTime: "14:00",
      status: "pending",
    });
    expect(schedule.id).toBeDefined();
    expect(schedule.status).toBe("pending");
  });

  it("should get schedules by date", async () => {
    await db.createSchedule({
      date: "2025-12-25",
      line: "102",
      driverId: "driver-001",
      driverName: "Maria",
      busModel: "Volvo B270F",
      busPrefix: "1234",
      startTime: "08:00",
      endTime: "16:00",
      status: "pending",
    });
    const schedules = await db.getSchedulesByDate("2025-12-25");
    expect(schedules.length).toBeGreaterThanOrEqual(1);
    expect(schedules.every((s) => s.date === "2025-12-25")).toBe(true);
  });

  it("should approve a schedule", async () => {
    const schedule = await db.createSchedule({
      date: "2025-12-26",
      line: "103",
      driverId: "driver-002",
      driverName: "Carlos",
      busModel: "Scania K310",
      busPrefix: "5678",
      startTime: "14:00",
      endTime: "22:00",
      status: "pending",
    });
    const updated = await db.updateSchedule(schedule.id, { status: "approved" });
    expect(updated?.status).toBe("approved");
  });

  it("should get schedules by date range", async () => {
    await db.createSchedule({
      date: "2025-06-15",
      line: "105",
      driverId: "driver-001",
      driverName: "Ana",
      busModel: "Volvo",
      busPrefix: "1111",
      startTime: "06:00",
      endTime: "14:00",
      status: "pending",
    });
    await db.createSchedule({
      date: "2025-07-20",
      line: "106",
      driverId: "driver-001",
      driverName: "Ana",
      busModel: "Volvo",
      busPrefix: "1111",
      startTime: "06:00",
      endTime: "14:00",
      status: "approved",
    });
    const inRange = await db.getSchedulesByDateRange("2025-06-01", "2025-06-30");
    expect(inRange.every((s) => s.date >= "2025-06-01" && s.date <= "2025-06-30")).toBe(true);
    expect(inRange.some((s) => s.date === "2025-06-15")).toBe(true);
    expect(inRange.some((s) => s.date === "2025-07-20")).toBe(false);
  });

  it("should get all schedules sorted by date desc", async () => {
    const all = await db.getAllSchedules();
    expect(Array.isArray(all)).toBe(true);
    if (all.length >= 2) {
      expect(all[0].date >= all[1].date).toBe(true);
    }
  });

  it("should delete a schedule", async () => {
    const schedule = await db.createSchedule({
      date: "2025-12-27",
      line: "104",
      driverId: "driver-003",
      driverName: "Luiz",
      busModel: "Marcopolo G7",
      busPrefix: "9012",
      startTime: "22:00",
      endTime: "06:00",
      status: "pending",
    });
    const result = await db.deleteSchedule(schedule.id);
    expect(result).toBe(true);
    const found = await db.getScheduleById(schedule.id);
    expect(found).toBeNull();
  });
});

describe("Database - Bulk & Recurring", () => {
  beforeEach(async () => {
    Object.keys(storage).forEach((k) => delete storage[k]);
    await db.initialize();
  });

  it("should create multiple schedules in bulk", async () => {
    const base = {
      date: "2025-08-01",
      line: "200",
      driverId: "driver-001",
      driverName: "Bulk Driver",
      busModel: "Volvo",
      busPrefix: "9999",
      startTime: "06:00",
      endTime: "14:00",
      status: "pending" as const,
    };
    const dataList = [base, { ...base, date: "2025-08-02" }, { ...base, date: "2025-08-03" }];
    const created = await db.createSchedulesBulk(dataList);
    expect(created.length).toBe(3);
    expect(created.every((s) => s.id)).toBe(true);
    const all = await db.getSchedulesByDateRange("2025-08-01", "2025-08-03");
    expect(all.length).toBeGreaterThanOrEqual(3);
  });

  it("should store and retrieve denyReason", async () => {
    const schedule = await db.createSchedule({
      date: "2025-09-10",
      line: "300",
      driverId: "driver-001",
      driverName: "Test Driver",
      busModel: "Mercedes",
      busPrefix: "1234",
      startTime: "08:00",
      endTime: "16:00",
      status: "pending",
    });
    const updated = await db.updateSchedule(schedule.id, {
      status: "denied",
      denyReason: "Motorista de folga programada",
    });
    expect(updated?.status).toBe("denied");
    expect(updated?.denyReason).toBe("Motorista de folga programada");
    const fetched = await db.getScheduleById(schedule.id);
    expect(fetched?.denyReason).toBe("Motorista de folga programada");
  });
});

describe("Database - Occurrences", () => {
  beforeEach(async () => {
    Object.keys(storage).forEach((k) => delete storage[k]);
    await db.initialize();
  });

  it("should create an occurrence", async () => {
    const occ = await db.createOccurrence({
      driverId: "driver-001",
      driverName: "João Silva",
      type: "mechanical",
      description: "Problema no freio traseiro do ônibus.",
    });
    expect(occ.id).toBeDefined();
    expect(occ.isRead).toBe(false);
    expect(occ.type).toBe("mechanical");
  });

  it("should mark occurrence as read", async () => {
    const occ = await db.createOccurrence({
      driverId: "driver-001",
      driverName: "Maria Santos",
      type: "delay",
      description: "Atraso de 30 minutos devido ao trânsito intenso.",
    });
    await db.markOccurrenceAsRead(occ.id);
    const all = await db.getOccurrences();
    const found = all.find((o) => o.id === occ.id);
    expect(found?.isRead).toBe(true);
  });
});

describe("Database - Ponto Eletrônico", () => {
  beforeEach(async () => {
    Object.keys(storage).forEach((k) => delete storage[k]);
    await db.initialize();
  });

  it("should create a punch record", async () => {
    const punch = await db.createPunch({
      driverId: "driver-001",
      driverName: "João Silva",
      type: "start",
      timestamp: "2025-10-01T06:00:00.000Z",
    });
    expect(punch.id).toBeDefined();
    expect(punch.type).toBe("start");
    expect(punch.driverId).toBe("driver-001");
  });

  it("should build workday punches correctly", async () => {
    const date = "2025-10-02";
    await db.createPunch({ driverId: "driver-001", driverName: "João", type: "start", timestamp: `${date}T06:00:00.000Z` });
    await db.createPunch({ driverId: "driver-001", driverName: "João", type: "break_start", timestamp: `${date}T12:00:00.000Z` });
    await db.createPunch({ driverId: "driver-001", driverName: "João", type: "break_end", timestamp: `${date}T13:00:00.000Z` });
    await db.createPunch({ driverId: "driver-001", driverName: "João", type: "end", timestamp: `${date}T14:00:00.000Z` });

    const wp = await db.getWorkdayPunches("driver-001", date);
    expect(wp.start).toBeDefined();
    expect(wp.breakStart).toBeDefined();
    expect(wp.breakEnd).toBeDefined();
    expect(wp.end).toBeDefined();
    expect(wp.start?.type).toBe("start");
    expect(wp.end?.type).toBe("end");
  });

  it("should get punches by driver", async () => {
    await db.createPunch({ driverId: "driver-002", driverName: "Maria", type: "start", timestamp: "2025-10-03T07:00:00.000Z" });
    await db.createPunch({ driverId: "driver-001", driverName: "João", type: "start", timestamp: "2025-10-03T06:00:00.000Z" });
    const punches = await db.getPunchesByDriver("driver-002");
    expect(punches.every((p) => p.driverId === "driver-002")).toBe(true);
  });

  it("should store punch with note", async () => {
    const punch = await db.createPunch({
      driverId: "driver-001",
      driverName: "João",
      type: "start",
      timestamp: "2025-10-04T06:00:00.000Z",
      note: "Ônibus com atraso",
    });
    expect(punch.note).toBe("Ônibus com atraso");
    const wp = await db.getWorkdayPunches("driver-001", "2025-10-04");
    expect(wp.start?.note).toBe("Ônibus com atraso");
  });
});

describe("Database - ScheduleType (folga/férias)", () => {
  beforeEach(async () => {
    Object.keys(storage).forEach((k) => delete storage[k]);
    await db.initialize();
  });

  it("should create a day_off schedule", async () => {
    const schedule = await db.createSchedule({
      date: "2025-11-01",
      line: "",
      driverId: "driver-001",
      driverName: "João",
      busModel: "",
      busPrefix: "",
      startTime: "",
      endTime: "",
      scheduleType: "day_off",
      status: "approved",
    });
    expect(schedule.scheduleType).toBe("day_off");
    const fetched = await db.getScheduleById(schedule.id);
    expect(fetched?.scheduleType).toBe("day_off");
  });

  it("should create a vacation schedule", async () => {
    const schedule = await db.createSchedule({
      date: "2025-12-01",
      line: "",
      driverId: "driver-001",
      driverName: "João",
      busModel: "",
      busPrefix: "",
      startTime: "",
      endTime: "",
      scheduleType: "vacation",
      status: "approved",
    });
    expect(schedule.scheduleType).toBe("vacation");
  });
});
