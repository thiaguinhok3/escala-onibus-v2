# Guia de Sincronização Local Entre Celulares

## Como Funciona

O app agora sincroniza dados entre múltiplos celulares **sem precisar de internet**! Basta estar na mesma rede WiFi.

## Passo 1: Descobrir o IP do seu Computador

### Windows:
1. Abra o Prompt de Comando (cmd)
2. Digite: `ipconfig`
3. Procure por "IPv4 Address" (ex: 192.168.1.100)

### Mac/Linux:
1. Abra o Terminal
2. Digite: `ifconfig`
3. Procure por "inet" (ex: 192.168.1.100)

## Passo 2: Configurar o App

No seu primeiro celular (onde você criou o motorista):

1. Abra o app EscalaOnibus
2. Vá para a tela de login
3. Na parte inferior, você verá: "Admin padrão: usuario admin / senha admin123"
4. **Não faça nada ainda** - o servidor já está rodando localmente

## Passo 3: Conectar Outro Celular

No segundo celular:

1. Certifique-se de que está **conectado na mesma rede WiFi** do primeiro celular
2. Abra o app EscalaOnibus
3. Digite o usuário e senha do motorista que você criou no primeiro celular
4. **Pronto!** Os dados sincronizarão automaticamente

## Testando a Sincronização

### Teste 1: Criar Motorista em um Celular
1. No primeiro celular, faça login como admin
2. Vá para "Motoristas"
3. Crie um novo motorista (ex: "João Silva" / "joao123")
4. No segundo celular, faça logout e tente fazer login com "joao123"
5. **Deve funcionar!**

### Teste 2: Criar Escala em um Celular
1. No primeiro celular, crie uma escala
2. No segundo celular (do motorista), vá para "Minha Escala"
3. **A escala deve aparecer!**

## Troubleshooting

**"Usuário não encontrado" no segundo celular**
- Verifique se está na mesma rede WiFi
- Verifique se o username está correto (minúsculas)
- Tente fazer logout e login novamente

**Dados não sincronizam**
- Verifique se ambos os celulares estão na mesma rede WiFi
- Reinicie o app
- Verifique se o servidor está rodando (deve estar, pois o app funciona offline também)

**"Conexão recusada"**
- O servidor está em modo offline (usando banco de dados local)
- Isso é normal! O app funciona offline e sincroniza quando possível

## Modo Offline

Se o servidor não estiver disponível, o app **continua funcionando** usando o banco de dados local de cada celular. Quando o servidor voltar, os dados sincronizam automaticamente.

## Dados Sincronizados

Todos esses dados sincronizam entre celulares:
- ✅ Motoristas
- ✅ Escalas
- ✅ CNH e multas
- ✅ Ponto eletrônico
- ✅ Ocorrências
- ✅ Treinamentos
- ✅ Usuários

## Próximos Passos

Para sincronizar dados **via internet** (entre celulares em redes diferentes):
1. Faça deploy no Render.com (veja RENDER_DEPLOY_GUIDE.md)
2. Configure a URL do servidor no app
3. Pronto! Sincroniza de qualquer lugar
