# Guia Completo de Deploy no Render.com

## O que você precisa fazer:

### Passo 1: Fazer Push do Código para o GitHub

1. Abra o terminal/PowerShell no seu computador
2. Navegue até a pasta do projeto
3. Execute os comandos:

```bash
git remote set-url origin https://github.com/livetmdigital-svg/bus_driver_schedule.git
git branch -M main
git push -u origin main
```

Se pedir usuário/senha, use seu token do GitHub (não a senha da conta).

### Passo 2: Criar Banco de Dados PostgreSQL no Render

1. Acesse [render.com](https://render.com) e faça login
2. Clique em **"New +"** no canto superior direito
3. Selecione **"PostgreSQL"**
4. Configure:
   - **Name**: `escalaonibus-db`
   - **Database**: `escalaonibus`
   - **User**: `postgres`
   - **Region**: Escolha a mais próxima de você
   - **Plan**: Free (até 1GB)
5. Clique em **"Create Database"**
6. Aguarde a criação (leva ~2 minutos)
7. **Copie a URL da conexão** (Internal Database URL ou External Database URL)
   - Será algo como: `postgresql://user:password@host:5432/escalaonibus`

### Passo 3: Criar Web Service no Render

1. No Render, clique em **"New +"** → **"Web Service"**
2. Selecione **"Deploy an existing repository"**
3. Conecte sua conta GitHub (se não estiver conectada)
4. Selecione o repositório `bus_driver_schedule`
5. Configure:
   - **Name**: `escalaonibus-api`
   - **Environment**: `Node`
   - **Build Command**: `pnpm install && pnpm build`
   - **Start Command**: `pnpm start`
   - **Plan**: Free
6. Clique em **"Create Web Service"**

### Passo 4: Adicionar Variáveis de Ambiente

1. No Web Service que você acabou de criar, vá para a aba **"Environment"**
2. Clique em **"Add Environment Variable"** e adicione:

```
NODE_ENV = production
PORT = 3000
DATABASE_URL = postgresql://user:password@host:5432/escalaonibus
```

(Cole a URL que você copiou no Passo 2)

3. Clique em **"Save"**

### Passo 5: Aguardar Deploy

1. O Render fará o deploy automaticamente
2. Você verá o status em tempo real
3. Quando aparecer "Live", o servidor está pronto!
4. **Copie a URL do servidor** (será algo como: `https://escalaonibus-api.onrender.com`)

### Passo 6: Configurar o App Mobile

1. No arquivo `.env` do app (ou nas variáveis de ambiente do Render), configure:

```
EXPO_PUBLIC_API_URL=https://escalaonibus-api.onrender.com
```

2. Recompile o app

## Testando a Conexão

```bash
# Testar se o servidor está rodando
curl https://escalaonibus-api.onrender.com/api/health

# Testar login com admin padrão
curl -X POST https://escalaonibus-api.onrender.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

## Dados Persistidos

Todos os dados agora são armazenados no PostgreSQL:
- ✅ Motoristas
- ✅ Escalas
- ✅ CNH e multas
- ✅ Ponto eletrônico
- ✅ Ocorrências

**Quando você trocar de celular, todos os dados estarão disponíveis no servidor!**

## Notas Importantes

- O plano free do Render coloca o serviço em sleep após 15 minutos sem requisições
- Na primeira requisição após o sleep, pode levar alguns segundos para acordar
- O banco de dados PostgreSQL free tem limite de 1GB
- Para produção, considere um plano pago

## Troubleshooting

**"Deployment failed"**
- Verifique se o DATABASE_URL está correto
- Verifique se o repositório foi feito push corretamente

**"Server unavailable"**
- Aguarde alguns minutos para o Render fazer o deploy
- Verifique se o Web Service está com status "Live"

**"Connection refused"**
- O servidor pode estar em sleep. Faça uma requisição para acordá-lo
- Aguarde 30 segundos e tente novamente
