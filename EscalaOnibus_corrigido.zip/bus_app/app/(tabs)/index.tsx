import { View } from "react-native";

// This file is kept for compatibility with the Expo Router template.
// The app now uses (auth), (admin), and (driver) route groups.
export default function TabsIndex() {
  return <View style={{ flex: 1 }} />;
}
