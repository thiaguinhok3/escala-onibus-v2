import { Stack } from "expo-router";

// Legacy tabs group - kept for compatibility only
export default function TabsLayout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}
