"use client";
import { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { apiClient } from "@/lib/api-client";
import type { Schedule, User } from "@/lib/database";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

function getMonthRange(offset: number): { start: string; end: string; label: string } {
  const d = new Date();
  d.setDate(1);
  d.setMonth(d.getMonth() + offset);
  const year = d.getFullYear();
  const month = d.getMonth();
  const start = `${year}-${String(month + 1).padStart(2, "0")}-01`;
  const lastDay = new Date(year, month + 1, 0).getDate();
  const end = `${year}-${String(month + 1).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
  const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
  return { start, end, label: `${months[month]} ${year}` };
}

// ─── Types ────────────────────────────────────────────────────────────────────

interface DriverStats {
  driverId: string;
  driverName: string;
  total: number;
  approved: number;
  denied: number;
  pending: number;
  confirmed: number;
}

// ─── Bar Chart Component ──────────────────────────────────────────────────────

function BarChart({
  data,
  maxValue,
  colors,
}: {
  data: { label: string; value: number; color: string }[];
  maxValue: number;
  colors: ReturnType<typeof useColors>;
}) {
  if (data.length === 0 || maxValue === 0) {
    return (
      <View style={{ alignItems: "center", paddingVertical: 24 }}>
        <Text style={{ color: colors.muted, fontSize: 13 }}>Sem dados para exibir</Text>
      </View>
    );
  }

  return (
    <View style={{ gap: 10 }}>
      {data.map((item, i) => {
        const pct = maxValue > 0 ? item.value / maxValue : 0;
        return (
          <View key={i} style={{ gap: 4 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontSize: 12, color: colors.foreground, fontWeight: "600", flex: 1 }} numberOfLines={1}>
                {item.label}
              </Text>
              <Text style={{ fontSize: 12, color: item.color, fontWeight: "700", marginLeft: 8 }}>
                {item.value}
              </Text>
            </View>
            <View style={{ height: 10, backgroundColor: colors.border, borderRadius: 5, overflow: "hidden" }}>
              <View
                style={{
                  height: 10,
                  width: `${Math.round(pct * 100)}%`,
                  backgroundColor: item.color,
                  borderRadius: 5,
                }}
              />
            </View>
          </View>
        );
      })}
    </View>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({
  label,
  value,
  color,
  icon,
}: {
  label: string;
  value: number | string;
  color: string;
  icon: keyof typeof MaterialIcons.glyphMap;
}) {
  return (
    <View style={[statStyles.card, { borderTopColor: color }]}>
      <MaterialIcons name={icon} size={22} color={color} />
      <Text style={[statStyles.value, { color }]}>{value}</Text>
      <Text style={statStyles.label}>{label}</Text>
    </View>
  );
}

const statStyles = StyleSheet.create({
  card: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 14,
    paddingHorizontal: 8,
    borderTopWidth: 3,
    gap: 4,
  },
  value: {
    fontSize: 22,
    fontWeight: "800",
  },
  label: {
    fontSize: 10,
    color: "#64748B",
    fontWeight: "600",
    textAlign: "center",
  },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function AdminDashboardScreen() {
  const colors = useColors();
  const [monthOffset, setMonthOffset] = useState(0);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [prevSchedules, setPrevSchedules] = useState<Schedule[]>([]);
  const [drivers, setDrivers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [chartView, setChartView] = useState<"approved" | "denied" | "total">("total");

  const { start, end, label } = getMonthRange(monthOffset);
  const { start: prevStart, end: prevEnd, label: prevLabel } = getMonthRange(monthOffset - 1);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [allSchedules, d] = await Promise.all([
        apiClient.getSchedules(),
        apiClient.getDrivers(),
      ]);
      // Filtrar por range de datas no frontend
      const s = allSchedules.filter((sc: any) => {
        const date = sc.date?.split('T')[0] || sc.date;
        return date >= start && date <= end;
      });
      const prev = allSchedules.filter((sc: any) => {
        const date = sc.date?.split('T')[0] || sc.date;
        return date >= prevStart && date <= prevEnd;
      });
      setSchedules(s);
      setPrevSchedules(prev);
      setDrivers(d);
    } catch (error) {
      console.error('Erro ao carregar dashboard:', error);
    } finally {
      setLoading(false);
    }
  }, [start, end, prevStart, prevEnd]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Build per-driver stats
  const driverStats: DriverStats[] = drivers.map((driver) => {
    const ds = schedules.filter((s) => s.driverId === driver.id);
    return {
      driverId: driver.id,
      driverName: driver.name,
      total: ds.length,
      approved: ds.filter((s) => s.status === "approved").length,
      denied: ds.filter((s) => s.status === "denied").length,
      pending: ds.filter((s) => s.status === "pending").length,
      confirmed: ds.filter((s) => s.confirmedAt).length,
    };
  }).filter((s) => s.total > 0).sort((a, b) => b.total - a.total);

  // Global totals
  const totalSchedules = schedules.length;
  const totalApproved = schedules.filter((s) => s.status === "approved").length;
  const totalDenied = schedules.filter((s) => s.status === "denied").length;
  const totalPending = schedules.filter((s) => s.status === "pending").length;
  const totalConfirmed = schedules.filter((s) => s.confirmedAt).length;
  const approvalRate = totalSchedules > 0 ? Math.round((totalApproved / totalSchedules) * 100) : 0;

  // Previous month totals for comparison
  const prevTotal = prevSchedules.length;
  const prevApproved = prevSchedules.filter((s) => s.status === "approved").length;
  const prevApprovalRate = prevTotal > 0 ? Math.round((prevApproved / prevTotal) * 100) : 0;

  function getDelta(current: number, previous: number): { value: number; positive: boolean; neutral: boolean } {
    const diff = current - previous;
    return { value: Math.abs(diff), positive: diff >= 0, neutral: diff === 0 };
  }

  // Chart data
  const chartData = driverStats.map((ds) => ({
    label: ds.driverName.split(" ")[0],
    value: chartView === "approved" ? ds.approved : chartView === "denied" ? ds.denied : ds.total,
    color: chartView === "approved" ? colors.success : chartView === "denied" ? colors.error : colors.primary,
  }));
  const maxValue = chartData.reduce((m, d) => Math.max(m, d.value), 0);

  // Top performer
  const topDriver = driverStats.length > 0
    ? driverStats.reduce((best, d) => (d.approved > best.approved ? d : best), driverStats[0])
    : null;

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Dashboard</Text>
        <View style={styles.monthNav}>
          <Pressable onPress={() => setMonthOffset((o) => o - 1)} style={styles.navBtn}>
            <MaterialIcons name="chevron-left" size={22} color={colors.primary} />
          </Pressable>
          <Text style={[styles.monthLabel, { color: colors.foreground }]}>{label}</Text>
          <Pressable
            onPress={() => setMonthOffset((o) => Math.min(0, o + 1))}
            style={[styles.navBtn, monthOffset >= 0 && { opacity: 0.3 }]}
            disabled={monthOffset >= 0}
          >
            <MaterialIcons name="chevron-right" size={22} color={colors.primary} />
          </Pressable>
        </View>
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 16, gap: 16 }}>
          {/* Summary Cards */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Resumo do Mês</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
              <StatCard label="Total" value={totalSchedules} color={colors.primary} icon="event" />
              <StatCard label="Aprovadas" value={totalApproved} color={colors.success} icon="check-circle" />
              <StatCard label="Negadas" value={totalDenied} color={colors.error} icon="cancel" />
              <StatCard label="Pendentes" value={totalPending} color={colors.warning} icon="schedule" />
            </View>
          </View>

          {/* KPIs */}
          <View style={{ flexDirection: "row", gap: 12 }}>
            <View style={[styles.kpiCard, { backgroundColor: colors.primary + "15", borderColor: colors.primary, flex: 1 }]}>
              <Text style={[styles.kpiValue, { color: colors.primary }]}>{approvalRate}%</Text>
              <Text style={[styles.kpiLabel, { color: colors.muted }]}>Taxa de Aprovação</Text>
            </View>
            <View style={[styles.kpiCard, { backgroundColor: colors.success + "15", borderColor: colors.success, flex: 1 }]}>
              <Text style={[styles.kpiValue, { color: colors.success }]}>{totalConfirmed}</Text>
              <Text style={[styles.kpiLabel, { color: colors.muted }]}>Confirmadas pelos Motoristas</Text>
            </View>
          </View>

          {/* Month Comparison */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Comparação com {prevLabel}</Text>
            <View style={{ gap: 10 }}>
              {[
                { label: "Total de Escalas", current: totalSchedules, previous: prevTotal, color: colors.primary },
                { label: "Aprovadas", current: totalApproved, previous: prevApproved, color: colors.success },
                { label: "Taxa de Aprovação", current: approvalRate, previous: prevApprovalRate, color: colors.primary, suffix: "%" },
              ].map((item) => {
                const delta = getDelta(item.current, item.previous);
                const icon = delta.neutral ? "remove" : delta.positive ? "trending-up" : "trending-down";
                const deltaColor = delta.neutral ? colors.muted : delta.positive ? colors.success : colors.error;
                return (
                  <View key={item.label} style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 2 }}>{item.label}</Text>
                      <View style={{ flexDirection: "row", alignItems: "baseline", gap: 8 }}>
                        <Text style={{ fontSize: 20, fontWeight: "800", color: item.color }}>{item.current}{item.suffix ?? ""}</Text>
                        <Text style={{ fontSize: 12, color: colors.muted }}>vs {item.previous}{item.suffix ?? ""} em {prevLabel}</Text>
                      </View>
                    </View>
                    <View style={{ alignItems: "center", gap: 2 }}>
                      <MaterialIcons name={icon} size={22} color={deltaColor} />
                      {!delta.neutral && (
                        <Text style={{ fontSize: 11, fontWeight: "700", color: deltaColor }}>
                          {delta.positive ? "+" : "-"}{delta.value}{item.suffix ?? ""}
                        </Text>
                      )}
                    </View>
                  </View>
                );
              })}
            </View>
          </View>

          {/* Top Performer */}
          {topDriver && (
            <View style={[styles.card, { backgroundColor: colors.success + "10", borderColor: colors.success }]}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: colors.success, alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ color: "#fff", fontWeight: "800", fontSize: 18 }}>
                    {topDriver.driverName.charAt(0).toUpperCase()}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 11, color: colors.success, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.5 }}>
                    Destaque do Mês
                  </Text>
                  <Text style={{ fontSize: 16, fontWeight: "700", color: colors.foreground }}>{topDriver.driverName}</Text>
                  <Text style={{ fontSize: 12, color: colors.muted }}>
                    {topDriver.approved} escalas aprovadas · {topDriver.total} no total
                  </Text>
                </View>
                <MaterialIcons name="emoji-events" size={28} color={colors.success} />
              </View>
            </View>
          )}

          {/* Bar Chart */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Escalas por Motorista</Text>

            {/* Chart type selector */}
            <View style={{ flexDirection: "row", gap: 8, marginBottom: 16 }}>
              {(["total", "approved", "denied"] as const).map((view) => {
                const labels = { total: "Total", approved: "Aprovadas", denied: "Negadas" };
                const viewColors = { total: colors.primary, approved: colors.success, denied: colors.error };
                const isActive = chartView === view;
                return (
                  <Pressable
                    key={view}
                    style={[{
                      paddingHorizontal: 12,
                      paddingVertical: 6,
                      borderRadius: 16,
                      borderWidth: 1.5,
                      backgroundColor: isActive ? viewColors[view] : "transparent",
                      borderColor: isActive ? viewColors[view] : colors.border,
                    }]}
                    onPress={() => setChartView(view)}
                  >
                    <Text style={{ fontSize: 12, fontWeight: "600", color: isActive ? "#fff" : colors.muted }}>
                      {labels[view]}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            {driverStats.length === 0 ? (
              <View style={{ alignItems: "center", paddingVertical: 24 }}>
                <MaterialIcons name="bar-chart" size={40} color={colors.border} />
                <Text style={{ color: colors.muted, fontSize: 14, marginTop: 8 }}>
                  Nenhuma escala registrada neste mês
                </Text>
              </View>
            ) : (
              <BarChart data={chartData} maxValue={maxValue} colors={colors} />
            )}
          </View>

          {/* Driver Detail Table */}
          {driverStats.length > 0 && (
            <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>Detalhes por Motorista</Text>
              {/* Header row */}
              <View style={[styles.tableRow, { borderBottomColor: colors.border, borderBottomWidth: 1, paddingBottom: 8, marginBottom: 4 }]}>
                <Text style={[styles.tableHeader, { color: colors.muted, flex: 2 }]}>Motorista</Text>
                <Text style={[styles.tableHeader, { color: colors.muted }]}>Total</Text>
                <Text style={[styles.tableHeader, { color: colors.success }]}>Aprov.</Text>
                <Text style={[styles.tableHeader, { color: colors.error }]}>Neg.</Text>
                <Text style={[styles.tableHeader, { color: colors.warning }]}>Pend.</Text>
              </View>
              {driverStats.map((ds, i) => (
                <View
                  key={ds.driverId}
                  style={[
                    styles.tableRow,
                    i < driverStats.length - 1 && { borderBottomColor: colors.border, borderBottomWidth: 0.5, paddingBottom: 10, marginBottom: 6 },
                  ]}
                >
                  <Text style={[styles.tableCell, { color: colors.foreground, flex: 2, fontWeight: "600" }]} numberOfLines={1}>
                    {ds.driverName.split(" ")[0]}
                  </Text>
                  <Text style={[styles.tableCell, { color: colors.primary }]}>{ds.total}</Text>
                  <Text style={[styles.tableCell, { color: colors.success }]}>{ds.approved}</Text>
                  <Text style={[styles.tableCell, { color: colors.error }]}>{ds.denied}</Text>
                  <Text style={[styles.tableCell, { color: colors.warning }]}>{ds.pending}</Text>
                </View>
              ))}
            </View>
          )}
        </ScrollView>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  monthNav: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  navBtn: {
    padding: 4,
  },
  monthLabel: {
    fontSize: 14,
    fontWeight: "600",
    minWidth: 72,
    textAlign: "center",
  },
  card: {
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: "700",
    marginBottom: 14,
  },
  kpiCard: {
    borderRadius: 14,
    padding: 16,
    borderWidth: 1.5,
    alignItems: "center",
    gap: 4,
  },
  kpiValue: {
    fontSize: 28,
    fontWeight: "800",
  },
  kpiLabel: {
    fontSize: 11,
    fontWeight: "600",
    textAlign: "center",
  },
  tableRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  tableHeader: {
    fontSize: 11,
    fontWeight: "700",
    textTransform: "uppercase",
    flex: 1,
    textAlign: "center",
  },
  tableCell: {
    fontSize: 13,
    flex: 1,
    textAlign: "center",
  },
});
