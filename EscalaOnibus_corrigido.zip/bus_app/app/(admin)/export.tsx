import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  Platform,
  Alert,
  Modal,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { db, type Schedule, type User, type WorkdayPunches } from "@/lib/database";
import { exportSchedulesPDF, exportPunchPDF } from "@/lib/pdf-report";

type PeriodOption = "today" | "week" | "month" | "all";
type TabOption = "schedules" | "punch";

interface Period {
  key: PeriodOption;
  label: string;
  icon: keyof typeof MaterialIcons.glyphMap;
}

const PERIODS: Period[] = [
  { key: "today", label: "Hoje", icon: "today" },
  { key: "week", label: "Esta Semana", icon: "date-range" },
  { key: "month", label: "Este Mês", icon: "calendar-month" },
  { key: "all", label: "Todos", icon: "history" },
];

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + "T12:00:00");
  d.setDate(d.getDate() + days);
  return d.toISOString().split("T")[0];
}

function getMonthRange(): { start: string; end: string } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split("T")[0];
  return { start, end };
}

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function calcWorkMinutes(wp: WorkdayPunches): number {
  if (!wp.start) return 0;
  const endTime = wp.end?.timestamp ?? new Date().toISOString();
  const totalMs = new Date(endTime).getTime() - new Date(wp.start.timestamp).getTime();
  let breakMs = 0;
  if (wp.breakStart && wp.breakEnd) {
    breakMs = new Date(wp.breakEnd.timestamp).getTime() - new Date(wp.breakStart.timestamp).getTime();
  }
  return Math.max(0, Math.floor((totalMs - breakMs) / 60000));
}

export default function AdminExportScreen() {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<TabOption>("schedules");
  const [drivers, setDrivers] = useState<User[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<PeriodOption>("month");
  const [selectedDriverId, setSelectedDriverId] = useState<string>("all");
  const [scheduleCount, setScheduleCount] = useState<number | null>(null);
  const [punchCount, setPunchCount] = useState<number | null>(null);
  const [overdueAlerts, setOverdueAlerts] = useState<{ driver: string; date: string; hours: string }[]>([]);
  const [loadingCount, setLoadingCount] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [driverPickerVisible, setDriverPickerVisible] = useState(false);
  const [alertsVisible, setAlertsVisible] = useState(false);

  const loadDrivers = useCallback(async () => {
    const list = await db.getDrivers();
    setDrivers(list);
  }, []);

  useEffect(() => {
    loadDrivers();
  }, [loadDrivers]);

  const getDateRange = useCallback((): { start: string; end: string } | null => {
    const today = todayISO();
    switch (selectedPeriod) {
      case "today": return { start: today, end: today };
      case "week": return { start: today, end: addDays(today, 6) };
      case "month": return getMonthRange();
      case "all": return null;
    }
  }, [selectedPeriod]);

  const getPeriodLabel = useCallback((): string => {
    const today = todayISO();
    switch (selectedPeriod) {
      case "today": return `Hoje — ${formatDate(today)}`;
      case "week": { const end = addDays(today, 6); return `${formatDate(today)} a ${formatDate(end)}`; }
      case "month": { const { start, end } = getMonthRange(); return `${formatDate(start)} a ${formatDate(end)}`; }
      case "all": return activeTab === "schedules" ? "Todas as escalas" : "Todos os registros";
    }
  }, [selectedPeriod, activeTab]);

  const loadCount = useCallback(async () => {
    setLoadingCount(true);
    try {
      const range = getDateRange();
      // Schedules count
      let schedules: Schedule[];
      if (range) {
        schedules = await db.getSchedulesByDateRange(range.start, range.end);
      } else {
        schedules = await db.getAllSchedules();
      }
      if (selectedDriverId !== "all") {
        schedules = schedules.filter((s) => s.driverId === selectedDriverId);
      }
      setScheduleCount(schedules.length);

      // Punch count — check all drivers for today's overdue (>8h without end)
      const today = todayISO();
      const allDrivers = await db.getDrivers();
      const alerts: { driver: string; date: string; hours: string }[] = [];
      for (const d of allDrivers) {
        const wp = await db.getWorkdayPunches(d.id, today);
        if (wp.start && !wp.end) {
          const mins = calcWorkMinutes(wp);
          if (mins >= 480) { // 8 hours
            const h = Math.floor(mins / 60);
            const m = mins % 60;
            alerts.push({ driver: d.name, date: today, hours: `${h}h ${String(m).padStart(2, "0")}min` });
          }
        }
      }
      setOverdueAlerts(alerts);

      // Punch records count for selected driver/period
      let punchTotal = 0;
      const driversToCheck = selectedDriverId !== "all"
        ? allDrivers.filter((d) => d.id === selectedDriverId)
        : allDrivers;
      for (const d of driversToCheck) {
        const punches = await db.getPunchesByDriver(d.id);
        const filtered = range
          ? punches.filter((p) => {
              const date = p.timestamp.split("T")[0];
              return date >= range.start && date <= range.end;
            })
          : punches;
        punchTotal += filtered.length;
      }
      setPunchCount(punchTotal);
    } finally {
      setLoadingCount(false);
    }
  }, [selectedPeriod, selectedDriverId, getDateRange]);

  useEffect(() => {
    loadCount();
  }, [loadCount]);

  async function handleExportSchedules() {
    if (Platform.OS === "web") {
      Alert.alert("Indisponível", "A exportação de PDF não está disponível na versão web.");
      return;
    }
    setExporting(true);
    try {
      const range = getDateRange();
      let schedules: Schedule[];
      if (range) {
        schedules = await db.getSchedulesByDateRange(range.start, range.end);
      } else {
        schedules = await db.getAllSchedules();
      }
      const filterDriver = selectedDriverId !== "all"
        ? drivers.find((d) => d.id === selectedDriverId) ?? null
        : null;
      if (filterDriver) {
        schedules = schedules.filter((s) => s.driverId === filterDriver.id);
      }
      await exportSchedulesPDF({ schedules, drivers, filterDriver, periodLabel: getPeriodLabel() });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {
      Alert.alert("Erro", "Não foi possível gerar o PDF. Tente novamente.");
    } finally {
      setExporting(false);
    }
  }

  async function handleExportPunch() {
    if (Platform.OS === "web") {
      Alert.alert("Indisponível", "A exportação de PDF não está disponível na versão web.");
      return;
    }
    setExporting(true);
    try {
      const range = getDateRange();
      const allDrivers = await db.getDrivers();
      const driversToCheck = selectedDriverId !== "all"
        ? allDrivers.filter((d) => d.id === selectedDriverId)
        : allDrivers;
      const filterDriver = selectedDriverId !== "all"
        ? allDrivers.find((d) => d.id === selectedDriverId) ?? null
        : null;

      const workdays: WorkdayPunches[] = [];
      for (const d of driversToCheck) {
        const punches = await db.getPunchesByDriver(d.id);
        const dates = new Set(
          punches
            .map((p) => p.timestamp.split("T")[0])
            .filter((date) => !range || (date >= range.start && date <= range.end))
        );
        for (const date of dates) {
          const wp = await db.getWorkdayPunches(d.id, date);
          if (wp.start) workdays.push(wp);
        }
      }

      await exportPunchPDF({ workdays, drivers: allDrivers, filterDriver, periodLabel: getPeriodLabel() });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {
      Alert.alert("Erro", "Não foi possível gerar o PDF. Tente novamente.");
    } finally {
      setExporting(false);
    }
  }

  const selectedDriverName = selectedDriverId === "all"
    ? "Todos os motoristas"
    : drivers.find((d) => d.id === selectedDriverId)?.name ?? "Selecionar";

  return (
    <ScreenContainer containerClassName="bg-background">
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Exportar PDF</Text>
        {overdueAlerts.length > 0 && (
          <Pressable
            style={[styles.alertBadge, { backgroundColor: colors.error }]}
            onPress={() => setAlertsVisible(true)}
          >
            <MaterialIcons name="warning" size={14} color="#fff" />
            <Text style={styles.alertBadgeText}>{overdueAlerts.length}</Text>
          </Pressable>
        )}
      </View>

      {/* Tab Switcher */}
      <View style={[styles.tabBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        {([
          { key: "schedules" as TabOption, label: "Escalas", icon: "directions-bus" },
          { key: "punch" as TabOption, label: "Ponto Eletrônico", icon: "fingerprint" },
        ] as { key: TabOption; label: string; icon: keyof typeof MaterialIcons.glyphMap }[]).map((tab) => (
          <Pressable
            key={tab.key}
            style={[
              styles.tabItem,
              activeTab === tab.key && { borderBottomColor: colors.primary, borderBottomWidth: 2.5 },
            ]}
            onPress={() => setActiveTab(tab.key)}
          >
            <MaterialIcons
              name={tab.icon}
              size={18}
              color={activeTab === tab.key ? colors.primary : colors.muted}
            />
            <Text style={[styles.tabLabel, { color: activeTab === tab.key ? colors.primary : colors.muted }]}>
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, gap: 20 }}>
        {/* Period Selection */}
        <View>
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>Período</Text>
          <View style={styles.periodGrid}>
            {PERIODS.map((p) => (
              <Pressable
                key={p.key}
                style={[
                  styles.periodCard,
                  {
                    backgroundColor: selectedPeriod === p.key ? colors.primary : colors.surface,
                    borderColor: selectedPeriod === p.key ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => setSelectedPeriod(p.key)}
              >
                <MaterialIcons name={p.icon} size={22} color={selectedPeriod === p.key ? "#fff" : colors.muted} />
                <Text style={[styles.periodLabel, { color: selectedPeriod === p.key ? "#fff" : colors.foreground }]}>
                  {p.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Driver Filter */}
        <View>
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>Motorista</Text>
          <Pressable
            style={[styles.driverPicker, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={() => setDriverPickerVisible(true)}
          >
            <View style={[styles.driverPickerIcon, { backgroundColor: colors.primary + "15" }]}>
              <MaterialIcons name="person" size={20} color={colors.primary} />
            </View>
            <Text style={[styles.driverPickerText, { color: colors.foreground }]}>{selectedDriverName}</Text>
            <MaterialIcons name="arrow-drop-down" size={24} color={colors.muted} />
          </Pressable>
        </View>

        {/* Overdue Alert Banner */}
        {overdueAlerts.length > 0 && (
          <Pressable
            style={[styles.overdueCard, { backgroundColor: colors.error + "10", borderColor: colors.error }]}
            onPress={() => setAlertsVisible(true)}
          >
            <MaterialIcons name="access-time" size={22} color={colors.error} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.overdueTitle, { color: colors.error }]}>
                {overdueAlerts.length} jornada{overdueAlerts.length > 1 ? "s" : ""} excedida{overdueAlerts.length > 1 ? "s" : ""}
              </Text>
              <Text style={[styles.overdueSubtitle, { color: colors.error + "BB" }]}>
                Motoristas com mais de 8h sem registrar término. Toque para ver.
              </Text>
            </View>
            <MaterialIcons name="chevron-right" size={20} color={colors.error} />
          </Pressable>
        )}

        {/* Preview Card */}
        <View style={[styles.previewCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.previewRow}>
            <MaterialIcons name="description" size={20} color={colors.primary} />
            <Text style={[styles.previewTitle, { color: colors.foreground }]}>Resumo do Relatório</Text>
          </View>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <View style={styles.previewInfo}>
            <PreviewItem label="Tipo" value={activeTab === "schedules" ? "Escalas" : "Ponto Eletrônico"} colors={colors} />
            <PreviewItem label="Período" value={getPeriodLabel()} colors={colors} />
            <PreviewItem label="Motorista" value={selectedDriverName} colors={colors} />
            <PreviewItem
              label={activeTab === "schedules" ? "Escalas encontradas" : "Registros de ponto"}
              value={loadingCount ? "Calculando..." : `${activeTab === "schedules" ? scheduleCount ?? 0 : punchCount ?? 0} registro${(activeTab === "schedules" ? scheduleCount : punchCount) !== 1 ? "s" : ""}`}
              colors={colors}
            />
          </View>
        </View>

        {/* Export Button */}
        <Pressable
          style={[styles.exportBtn, { backgroundColor: exporting ? colors.muted : colors.primary }]}
          onPress={activeTab === "schedules" ? handleExportSchedules : handleExportPunch}
          disabled={exporting}
        >
          {exporting ? (
            <>
              <ActivityIndicator color="#fff" />
              <Text style={styles.exportBtnText}>Gerando PDF...</Text>
            </>
          ) : (
            <>
              <MaterialIcons name="picture-as-pdf" size={22} color="#fff" />
              <Text style={styles.exportBtnText}>
                Gerar PDF — {activeTab === "schedules" ? "Escalas" : "Ponto"}
              </Text>
            </>
          )}
        </Pressable>

        {Platform.OS === "web" && (
          <View style={[styles.webNote, { backgroundColor: colors.warning + "15", borderColor: colors.warning }]}>
            <MaterialIcons name="info" size={16} color={colors.warning} />
            <Text style={[styles.webNoteText, { color: colors.warning }]}>
              A exportação de PDF funciona apenas no app instalado no celular.
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Driver Picker Modal */}
      {driverPickerVisible && (
        <View style={styles.pickerOverlay}>
          <View style={[styles.pickerModal, { backgroundColor: colors.background }]}>
            <View style={[styles.pickerHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.pickerTitle, { color: colors.foreground }]}>Selecionar Motorista</Text>
              <Pressable onPress={() => setDriverPickerVisible(false)}>
                <MaterialIcons name="close" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={{ padding: 12, gap: 8 }}>
              <Pressable
                style={[styles.driverOption, { backgroundColor: selectedDriverId === "all" ? colors.primary + "15" : colors.surface, borderColor: selectedDriverId === "all" ? colors.primary : colors.border }]}
                onPress={() => { setSelectedDriverId("all"); setDriverPickerVisible(false); }}
              >
                <View style={[styles.driverOptionAvatar, { backgroundColor: colors.primary }]}>
                  <MaterialIcons name="group" size={18} color="#fff" />
                </View>
                <Text style={[styles.driverOptionName, { color: colors.foreground }]}>Todos os motoristas</Text>
                {selectedDriverId === "all" && <MaterialIcons name="check-circle" size={20} color={colors.primary} />}
              </Pressable>
              {drivers.map((d) => (
                <Pressable
                  key={d.id}
                  style={[styles.driverOption, { backgroundColor: selectedDriverId === d.id ? colors.primary + "15" : colors.surface, borderColor: selectedDriverId === d.id ? colors.primary : colors.border }]}
                  onPress={() => { setSelectedDriverId(d.id); setDriverPickerVisible(false); }}
                >
                  <View style={[styles.driverOptionAvatar, { backgroundColor: colors.primary }]}>
                    <Text style={styles.driverOptionAvatarText}>{d.name.charAt(0).toUpperCase()}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.driverOptionName, { color: colors.foreground }]}>{d.name}</Text>
                    <Text style={{ fontSize: 11, color: colors.muted }}>ID: {d.driverId}</Text>
                  </View>
                  {selectedDriverId === d.id && <MaterialIcons name="check-circle" size={20} color={colors.primary} />}
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      )}

      {/* Overdue Alerts Modal */}
      <Modal
        visible={alertsVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setAlertsVisible(false)}
      >
        <View style={{ flex: 1, backgroundColor: colors.background }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }}>
            <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>Alertas de Jornada</Text>
            <Pressable onPress={() => setAlertsVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20, gap: 12 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 8, padding: 14, borderRadius: 12, backgroundColor: colors.error + "10", borderWidth: 1, borderColor: colors.error, marginBottom: 8 }}>
              <MaterialIcons name="warning" size={20} color={colors.error} />
              <Text style={{ flex: 1, fontSize: 13, color: colors.error, fontWeight: "600" }}>
                Motoristas com jornada superior a 8h sem registrar o término hoje.
              </Text>
            </View>
            {overdueAlerts.map((alert, i) => (
              <View key={i} style={{ padding: 16, borderRadius: 14, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, flexDirection: "row", alignItems: "center", gap: 14 }}>
                <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: colors.error + "20", alignItems: "center", justifyContent: "center" }}>
                  <MaterialIcons name="person" size={22} color={colors.error} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground }}>{alert.driver}</Text>
                  <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>Data: {formatDate(alert.date)}</Text>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 }}>
                    <MaterialIcons name="timer" size={13} color={colors.error} />
                    <Text style={{ fontSize: 13, fontWeight: "700", color: colors.error }}>{alert.hours} em serviço</Text>
                  </View>
                </View>
              </View>
            ))}
          </ScrollView>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

function PreviewItem({ label, value, colors }: { label: string; value: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={previewStyles.row}>
      <Text style={[previewStyles.label, { color: colors.muted }]}>{label}</Text>
      <Text style={[previewStyles.value, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const previewStyles = StyleSheet.create({
  row: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 6 },
  label: { fontSize: 13, fontWeight: "500" },
  value: { fontSize: 13, fontWeight: "600", maxWidth: "60%", textAlign: "right" },
});

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: 22, fontWeight: "800" },
  alertBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  alertBadgeText: { color: "#fff", fontSize: 12, fontWeight: "700" },
  tabBar: {
    flexDirection: "row",
    borderBottomWidth: 1,
  },
  tabItem: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 12,
    borderBottomWidth: 2.5,
    borderBottomColor: "transparent",
  },
  tabLabel: { fontSize: 13, fontWeight: "600" },
  sectionLabel: { fontSize: 14, fontWeight: "700", marginBottom: 10 },
  periodGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  periodCard: {
    flex: 1,
    minWidth: "44%",
    alignItems: "center",
    justifyContent: "center",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    gap: 6,
  },
  periodLabel: { fontSize: 13, fontWeight: "600", textAlign: "center" },
  driverPicker: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    gap: 12,
  },
  driverPickerIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  driverPickerText: { flex: 1, fontSize: 15, fontWeight: "500" },
  overdueCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 12,
    borderWidth: 1.5,
  },
  overdueTitle: { fontSize: 14, fontWeight: "700" },
  overdueSubtitle: { fontSize: 12, marginTop: 2 },
  previewCard: { borderRadius: 16, borderWidth: 1, overflow: "hidden" },
  previewRow: { flexDirection: "row", alignItems: "center", gap: 10, padding: 14 },
  previewTitle: { fontSize: 15, fontWeight: "700" },
  divider: { height: 1 },
  previewInfo: { padding: 14, gap: 4 },
  exportBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 54,
    borderRadius: 14,
    gap: 10,
  },
  exportBtnText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  webNote: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  webNoteText: { flex: 1, fontSize: 12, fontWeight: "500" },
  pickerOverlay: {
    position: "absolute",
    top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "flex-end",
  },
  pickerModal: { borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: "70%" },
  pickerHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
  },
  pickerTitle: { fontSize: 18, fontWeight: "700" },
  driverOption: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    gap: 12,
  },
  driverOptionAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  driverOptionAvatarText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  driverOptionName: { fontSize: 14, fontWeight: "600" },
});
