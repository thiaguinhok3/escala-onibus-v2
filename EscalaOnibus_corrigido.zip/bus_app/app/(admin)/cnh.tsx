"use client";
import { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  ActivityIndicator,
  StyleSheet,
  Modal,
  ScrollView,
  TextInput,
  Alert,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import {
  db,
  type User,
  type CNHRecord,
  type Fine,
  type FineType,
  type CNHCategory,
  type Training,
} from "@/lib/database";
import { notifyCNHFine, notifyCNHReactivated } from "@/lib/notifications";

// ─── Constants ────────────────────────────────────────────────────────────────

const FINE_TYPES: { type: FineType; label: string; points: number; defaultValue: number }[] = [
  { type: "speeding_mild", label: "Excesso de velocidade (leve)", points: 3, defaultValue: 130 },
  { type: "speeding_medium", label: "Excesso de velocidade (médio)", points: 5, defaultValue: 195 },
  { type: "speeding_severe", label: "Excesso de velocidade (grave)", points: 7, defaultValue: 293 },
  { type: "red_light", label: "Avanço de sinal vermelho", points: 7, defaultValue: 293 },
  { type: "seatbelt", label: "Não usar cinto de segurança", points: 5, defaultValue: 195 },
  { type: "phone", label: "Uso de celular ao volante", points: 5, defaultValue: 195 },
  { type: "alcohol", label: "Dirigir sob influência de álcool", points: 7, defaultValue: 2934 },
  { type: "parking", label: "Estacionamento irregular", points: 3, defaultValue: 88 },
  { type: "other", label: "Outra infração", points: 3, defaultValue: 130 },
];

const CNH_CATEGORIES: CNHCategory[] = ["A", "B", "C", "D", "E", "AB", "AC", "AD", "AE"];

function getStatusColor(status: string, colors: ReturnType<typeof useColors>) {
  if (status === "active") return colors.success;
  if (status === "suspended") return colors.warning;
  return colors.error;
}

function getStatusLabel(status: string) {
  if (status === "active") return "Ativa";
  if (status === "suspended") return "Suspensa";
  return "Bloqueada";
}

function formatDate(d: string) {
  if (!d) return "";
  const [y, m, day] = d.split("-");
  return `${day}/${m}/${y}`;
}

// ─── Driver CNH Card ──────────────────────────────────────────────────────────

function DriverCNHCard({
  driver,
  cnh,
  colors,
  onPress,
}: {
  driver: User;
  cnh: CNHRecord | null;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  const remaining = cnh ? cnh.totalPoints - cnh.usedPoints : 40;
  const pct = cnh ? Math.max(0, (remaining / cnh.totalPoints) * 100) : 100;
  const barColor = pct > 50 ? colors.success : pct > 25 ? colors.warning : colors.error;

  return (
    <Pressable
      style={[card.wrap, { backgroundColor: colors.surface, borderColor: colors.border }]}
      onPress={onPress}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
        <View style={[card.avatar, { backgroundColor: cnh ? getStatusColor(cnh.status, colors) : colors.border }]}>
          <Text style={{ color: "#fff", fontWeight: "800", fontSize: 16 }}>{driver.name.charAt(0)}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>{driver.name}</Text>
          <Text style={{ fontSize: 12, color: colors.muted }}>
            {cnh ? `CNH: ${cnh.cnhNumber.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")}` : "Sem CNH cadastrada"}
          </Text>
        </View>
        {cnh && (
          <View style={[card.badge, { backgroundColor: getStatusColor(cnh.status, colors) + "20" }]}>
            <Text style={{ fontSize: 11, fontWeight: "700", color: getStatusColor(cnh.status, colors) }}>
              {getStatusLabel(cnh.status)}
            </Text>
          </View>
        )}
      </View>
      {cnh && (
        <View style={{ marginTop: 10 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 4 }}>
            <Text style={{ fontSize: 11, color: colors.muted }}>Pontos restantes</Text>
            <Text style={{ fontSize: 11, fontWeight: "700", color: barColor }}>{remaining}/{cnh.totalPoints}</Text>
          </View>
          <View style={{ height: 6, backgroundColor: colors.border, borderRadius: 3 }}>
            <View style={{ height: 6, width: `${pct}%`, backgroundColor: barColor, borderRadius: 3 }} />
          </View>
        </View>
      )}
    </Pressable>
  );
}

const card = StyleSheet.create({
  wrap: { padding: 14, borderRadius: 14, borderWidth: 1, marginBottom: 10 },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  badge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function AdminCNHScreen() {
  const colors = useColors();
  const { user } = useAuth();

  const [drivers, setDrivers] = useState<User[]>([]);
  const [cnhMap, setCnhMap] = useState<Map<string, CNHRecord>>(new Map());
  const [finesMap, setFinesMap] = useState<Map<string, Fine[]>>(new Map());
  const [trainingsMap, setTrainingsMap] = useState<Map<string, Training[]>>(new Map());
  const [loading, setLoading] = useState(true);

  // Selected driver detail modal
  const [selectedDriver, setSelectedDriver] = useState<User | null>(null);
  const [detailVisible, setDetailVisible] = useState(false);

  // Create CNH modal
  const [createCNHVisible, setCreateCNHVisible] = useState(false);
  const [cnhCategory, setCnhCategory] = useState<CNHCategory>("D");
  const [cnhExpiry, setCnhExpiry] = useState("2030-12-31");

  // Add fine modal
  const [addFineVisible, setAddFineVisible] = useState(false);
  const [selectedFineType, setSelectedFineType] = useState<FineType>("speeding_mild");
  const [fineDate, setFineDate] = useState(new Date().toISOString().split("T")[0]);
  const [fineDesc, setFineDesc] = useState("");
  const [finePoints, setFinePoints] = useState("3");
  const [fineValue, setFineValue] = useState("130");

  // Training modal
  const [trainingVisible, setTrainingVisible] = useState(false);
  const [trainingTitle, setTrainingTitle] = useState("Reciclagem de Condutores");
  const [trainingDesc, setTrainingDesc] = useState("Treinamento obrigatório para reabilitação da CNH.");
  const [trainingHours, setTrainingHours] = useState("8");

  const loadData = useCallback(async () => {
    setLoading(true);
    const driverList = await db.getDrivers();
    setDrivers(driverList);
    const cnhList = await db.getCNHRecords();
    const fineList = await db.getFines();
    const trainingList = await db.getTrainings();

    const cm = new Map<string, CNHRecord>();
    cnhList.forEach((c) => cm.set(c.driverId, c));
    const fm = new Map<string, Fine[]>();
    driverList.forEach((d) => fm.set(d.id, fineList.filter((f) => f.driverId === d.id)));
    const tm = new Map<string, Training[]>();
    driverList.forEach((d) => tm.set(d.id, trainingList.filter((t) => t.driverId === d.id)));

    setCnhMap(cm);
    setFinesMap(fm);
    setTrainingsMap(tm);
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleCreateCNH = async () => {
    if (!selectedDriver) return;
    await db.createCNH({
      driverId: selectedDriver.id,
      driverName: selectedDriver.name,
      cnhNumber: db.generateCNHNumber(),
      category: cnhCategory,
      expiresAt: cnhExpiry,
      totalPoints: 40,
      usedPoints: 0,
      status: "active",
    });
    setCreateCNHVisible(false);
    await loadData();
  };

  const handleAddFine = async () => {
    if (!selectedDriver) return;
    const cnh = cnhMap.get(selectedDriver.id);
    if (!cnh) { Alert.alert("Erro", "Cadastre a CNH primeiro."); return; }
    await db.createFine({
      driverId: selectedDriver.id,
      driverName: selectedDriver.name,
      cnhId: cnh.id,
      type: selectedFineType,
      description: fineDesc || FINE_TYPES.find((f) => f.type === selectedFineType)?.label || "",
      points: Number(finePoints),
      value: Number(fineValue),
      date: fineDate,
    });
    setAddFineVisible(false);
    setFineDesc("");
    await loadData();
    // Refresh selected driver data and send notification
    const updatedDriver = await db.getUserByUsername(selectedDriver.username);
    if (updatedDriver) setSelectedDriver(updatedDriver);
    // Get updated CNH to check remaining points
    const updatedCNH = await db.getCNHByDriver(selectedDriver.id);
    if (updatedCNH) {
      const remaining = Math.max(0, updatedCNH.totalPoints - updatedCNH.usedPoints);
      const isSuspended = updatedCNH.status !== "active";
      const fineLabel = FINE_TYPES.find((f) => f.type === selectedFineType)?.label ?? selectedFineType;
      await notifyCNHFine({
        driverName: selectedDriver.name,
        fineType: fineLabel,
        pointsDeducted: Number(finePoints),
        remainingPoints: remaining,
        isSuspended,
      });
    }
  };

  const handleDeleteFine = async (fineId: string) => {
    Alert.alert("Remover Multa", "Deseja remover esta multa e devolver os pontos?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Remover", style: "destructive", onPress: async () => {
          await db.deleteFine(fineId);
          await loadData();
        }
      },
    ]);
  };

  const handleCreateTraining = async () => {
    if (!selectedDriver) return;
    await db.createTraining({
      driverId: selectedDriver.id,
      driverName: selectedDriver.name,
      title: trainingTitle,
      description: trainingDesc,
      requiredHours: Number(trainingHours),
      status: "pending",
    });
    setTrainingVisible(false);
    await loadData();
  };

  const handleApproveTraining = async (trainingId: string) => {
    Alert.alert("Aprovar Treinamento", "Confirmar conclusão e liberar o motorista?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Aprovar", onPress: async () => {
          await db.approveTraining(trainingId, user?.name ?? "Admin");
          await loadData();
          const updatedDriver = await db.getUserByUsername(selectedDriver?.username ?? "");
          if (updatedDriver) setSelectedDriver(updatedDriver);
          // Notify driver that CNH was reactivated
          await notifyCNHReactivated();
        }
      },
    ]);
  };

  const selectedCNH = selectedDriver ? cnhMap.get(selectedDriver.id) : null;
  const selectedFines = selectedDriver ? (finesMap.get(selectedDriver.id) ?? []) : [];
  const selectedTrainings = selectedDriver ? (trainingsMap.get(selectedDriver.id) ?? []) : [];

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>CNH dos Motoristas</Text>
          <Text style={[styles.headerSub, { color: colors.muted }]}>Pontos, multas e treinamentos</Text>
        </View>
        <MaterialIcons name="credit-card" size={28} color={colors.primary} />
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : (
        <FlatList
          data={drivers}
          keyExtractor={(d) => d.id}
          contentContainerStyle={{ padding: 16 }}
          ListEmptyComponent={
            <View style={{ alignItems: "center", marginTop: 60 }}>
              <MaterialIcons name="group" size={48} color={colors.border} />
              <Text style={{ color: colors.muted, marginTop: 12 }}>Nenhum motorista cadastrado</Text>
            </View>
          }
          renderItem={({ item }) => (
            <DriverCNHCard
              driver={item}
              cnh={cnhMap.get(item.id) ?? null}
              colors={colors}
              onPress={() => { setSelectedDriver(item); setDetailVisible(true); }}
            />
          )}
        />
      )}

      {/* ── Driver Detail Modal ── */}
      <Modal visible={detailVisible} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setDetailVisible(false)}>
        {selectedDriver && (
          <View style={{ flex: 1, backgroundColor: colors.background }}>
            {/* Modal Header */}
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }}>
              <View>
                <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>{selectedDriver.name}</Text>
                <Text style={{ fontSize: 13, color: colors.muted }}>ID: {selectedDriver.driverId ?? "—"}</Text>
              </View>
              <Pressable onPress={() => setDetailVisible(false)}>
                <MaterialIcons name="close" size={24} color={colors.muted} />
              </Pressable>
            </View>

            <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
              {/* CNH Card */}
              {selectedCNH ? (
                <View style={{ padding: 16, borderRadius: 14, borderWidth: 2, borderColor: getStatusColor(selectedCNH.status, colors), backgroundColor: getStatusColor(selectedCNH.status, colors) + "10" }}>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <View>
                      <Text style={{ fontSize: 11, color: colors.muted, fontWeight: "600" }}>CARTEIRA NACIONAL DE HABILITAÇÃO</Text>
                      <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground, letterSpacing: 1, marginTop: 4 }}>
                        {selectedCNH.cnhNumber.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")}
                      </Text>
                    </View>
                    <View style={[card.badge, { backgroundColor: getStatusColor(selectedCNH.status, colors) }]}>
                      <Text style={{ color: "#fff", fontWeight: "700", fontSize: 12 }}>{getStatusLabel(selectedCNH.status)}</Text>
                    </View>
                  </View>
                  <View style={{ flexDirection: "row", gap: 20, marginTop: 12 }}>
                    <View>
                      <Text style={{ fontSize: 10, color: colors.muted }}>CATEGORIA</Text>
                      <Text style={{ fontSize: 20, fontWeight: "800", color: colors.primary }}>{selectedCNH.category}</Text>
                    </View>
                    <View>
                      <Text style={{ fontSize: 10, color: colors.muted }}>VALIDADE</Text>
                      <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>{formatDate(selectedCNH.expiresAt)}</Text>
                    </View>
                    <View>
                      <Text style={{ fontSize: 10, color: colors.muted }}>PONTOS</Text>
                      <Text style={{ fontSize: 14, fontWeight: "700", color: getStatusColor(selectedCNH.status, colors) }}>
                        {selectedCNH.totalPoints - selectedCNH.usedPoints}/{selectedCNH.totalPoints}
                      </Text>
                    </View>
                  </View>
                  {/* Points bar */}
                  <View style={{ marginTop: 10 }}>
                    <View style={{ height: 8, backgroundColor: colors.border, borderRadius: 4 }}>
                      <View style={{
                        height: 8,
                        width: `${Math.max(0, ((selectedCNH.totalPoints - selectedCNH.usedPoints) / selectedCNH.totalPoints) * 100)}%`,
                        backgroundColor: getStatusColor(selectedCNH.status, colors),
                        borderRadius: 4,
                      }} />
                    </View>
                  </View>
                </View>
              ) : (
                <View style={{ padding: 16, borderRadius: 14, borderWidth: 1, borderColor: colors.border, alignItems: "center", gap: 8 }}>
                  <MaterialIcons name="credit-card-off" size={32} color={colors.muted} />
                  <Text style={{ color: colors.muted }}>Nenhuma CNH cadastrada</Text>
                  <Pressable
                    style={{ backgroundColor: colors.primary, paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10 }}
                    onPress={() => setCreateCNHVisible(true)}
                  >
                    <Text style={{ color: "#fff", fontWeight: "700" }}>Cadastrar CNH</Text>
                  </Pressable>
                </View>
              )}

              {/* Action Buttons */}
              {selectedCNH && (
                <View style={{ flexDirection: "row", gap: 10 }}>
                  <Pressable
                    style={{ flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: colors.error + "15", padding: 12, borderRadius: 12, borderWidth: 1, borderColor: colors.error + "40" }}
                    onPress={() => {
                      const ft = FINE_TYPES[0];
                      setSelectedFineType(ft.type);
                      setFinePoints(String(ft.points));
                      setFineValue(String(ft.defaultValue));
                      setFineDate(new Date().toISOString().split("T")[0]);
                      setFineDesc("");
                      setAddFineVisible(true);
                    }}
                  >
                    <MaterialIcons name="gavel" size={18} color={colors.error} />
                    <Text style={{ color: colors.error, fontWeight: "700", fontSize: 13 }}>Registrar Multa</Text>
                  </Pressable>
                  {selectedCNH.status === "blocked" && (
                    <Pressable
                      style={{ flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: colors.primary + "15", padding: 12, borderRadius: 12, borderWidth: 1, borderColor: colors.primary + "40" }}
                      onPress={() => setTrainingVisible(true)}
                    >
                      <MaterialIcons name="school" size={18} color={colors.primary} />
                      <Text style={{ color: colors.primary, fontWeight: "700", fontSize: 13 }}>Criar Treinamento</Text>
                    </Pressable>
                  )}
                </View>
              )}

              {/* Fines List */}
              {selectedFines.length > 0 && (
                <View>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
                    Multas Registradas ({selectedFines.length})
                  </Text>
                  {selectedFines.map((fine) => (
                    <View key={fine.id} style={{ padding: 12, borderRadius: 12, borderWidth: 1, borderColor: colors.error + "30", backgroundColor: colors.error + "08", marginBottom: 8 }}>
                      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                        <View style={{ flex: 1 }}>
                          <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground }}>{fine.description}</Text>
                          <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>
                            {formatDate(fine.date)} · {fine.points} pts · R$ {fine.value.toFixed(2)}
                          </Text>
                        </View>
                        <Pressable onPress={() => handleDeleteFine(fine.id)} style={{ padding: 4 }}>
                          <MaterialIcons name="delete-outline" size={18} color={colors.error} />
                        </Pressable>
                      </View>
                    </View>
                  ))}
                </View>
              )}

              {/* Trainings List */}
              {selectedTrainings.length > 0 && (
                <View>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
                    Treinamentos
                  </Text>
                  {selectedTrainings.map((t) => (
                    <View key={t.id} style={{ padding: 12, borderRadius: 12, borderWidth: 1, borderColor: colors.primary + "30", backgroundColor: colors.primary + "08", marginBottom: 8 }}>
                      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                        <View style={{ flex: 1 }}>
                          <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground }}>{t.title}</Text>
                          <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>{t.requiredHours}h · {t.status === "pending" ? "Pendente" : t.status === "completed" ? "Concluído" : "Aprovado"}</Text>
                        </View>
                        {t.status === "completed" && (
                          <Pressable
                            style={{ backgroundColor: colors.success, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 }}
                            onPress={() => handleApproveTraining(t.id)}
                          >
                            <Text style={{ color: "#fff", fontWeight: "700", fontSize: 12 }}>Aprovar</Text>
                          </Pressable>
                        )}
                        {t.status === "approved" && (
                          <View style={{ backgroundColor: colors.success + "20", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 }}>
                            <Text style={{ color: colors.success, fontWeight: "700", fontSize: 12 }}>Aprovado</Text>
                          </View>
                        )}
                      </View>
                    </View>
                  ))}
                </View>
              )}
            </ScrollView>
          </View>
        )}
      </Modal>

      {/* ── Create CNH Modal ── */}
      <Modal visible={createCNHVisible} animationType="slide" presentationStyle="formSheet" onRequestClose={() => setCreateCNHVisible(false)}>
        <View style={{ flex: 1, backgroundColor: colors.background, padding: 24 }}>
          <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground, marginBottom: 20 }}>Cadastrar CNH</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Categoria</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
            <View style={{ flexDirection: "row", gap: 8 }}>
              {CNH_CATEGORIES.map((cat) => (
                <Pressable
                  key={cat}
                  style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10, borderWidth: 2, borderColor: cnhCategory === cat ? colors.primary : colors.border, backgroundColor: cnhCategory === cat ? colors.primary + "15" : colors.surface }}
                  onPress={() => setCnhCategory(cat)}
                >
                  <Text style={{ fontWeight: "700", color: cnhCategory === cat ? colors.primary : colors.muted }}>{cat}</Text>
                </Pressable>
              ))}
            </View>
          </ScrollView>
          <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Validade (AAAA-MM-DD)</Text>
          <TextInput
            value={cnhExpiry}
            onChangeText={setCnhExpiry}
            style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.foreground, backgroundColor: colors.surface, marginBottom: 20 }}
            placeholder="2030-12-31"
            placeholderTextColor={colors.muted}
          />
          <View style={{ flexDirection: "row", gap: 10 }}>
            <Pressable style={{ flex: 1, padding: 14, borderRadius: 12, borderWidth: 1, borderColor: colors.border, alignItems: "center" }} onPress={() => setCreateCNHVisible(false)}>
              <Text style={{ color: colors.muted, fontWeight: "700" }}>Cancelar</Text>
            </Pressable>
            <Pressable style={{ flex: 1, padding: 14, borderRadius: 12, backgroundColor: colors.primary, alignItems: "center" }} onPress={handleCreateCNH}>
              <Text style={{ color: "#fff", fontWeight: "700" }}>Cadastrar</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      {/* ── Add Fine Modal ── */}
      <Modal visible={addFineVisible} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setAddFineVisible(false)}>
        <View style={{ flex: 1, backgroundColor: colors.background }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }}>
            <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>Registrar Multa</Text>
            <Pressable onPress={() => setAddFineVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.muted }}>TIPO DE INFRAÇÃO</Text>
            {FINE_TYPES.map((ft) => (
              <Pressable
                key={ft.type}
                style={{ flexDirection: "row", alignItems: "center", gap: 10, padding: 12, borderRadius: 12, borderWidth: 2, borderColor: selectedFineType === ft.type ? colors.error : colors.border, backgroundColor: selectedFineType === ft.type ? colors.error + "10" : colors.surface }}
                onPress={() => {
                  setSelectedFineType(ft.type);
                  setFinePoints(String(ft.points));
                  setFineValue(String(ft.defaultValue));
                }}
              >
                <View style={{ width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: selectedFineType === ft.type ? colors.error : colors.border, alignItems: "center", justifyContent: "center" }}>
                  {selectedFineType === ft.type && <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: colors.error }} />}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 13, fontWeight: "600", color: colors.foreground }}>{ft.label}</Text>
                  <Text style={{ fontSize: 11, color: colors.muted }}>{ft.points} pontos · R$ {ft.defaultValue.toFixed(2)}</Text>
                </View>
              </Pressable>
            ))}
            <View style={{ flexDirection: "row", gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Pontos</Text>
                <TextInput
                  value={finePoints}
                  onChangeText={setFinePoints}
                  keyboardType="numeric"
                  style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.foreground, backgroundColor: colors.surface }}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Valor (R$)</Text>
                <TextInput
                  value={fineValue}
                  onChangeText={setFineValue}
                  keyboardType="numeric"
                  style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.foreground, backgroundColor: colors.surface }}
                />
              </View>
            </View>
            <View>
              <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Data (AAAA-MM-DD)</Text>
              <TextInput
                value={fineDate}
                onChangeText={setFineDate}
                style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.foreground, backgroundColor: colors.surface }}
              />
            </View>
            <View>
              <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Observação (opcional)</Text>
              <TextInput
                value={fineDesc}
                onChangeText={setFineDesc}
                multiline
                numberOfLines={2}
                style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.foreground, backgroundColor: colors.surface, minHeight: 60 }}
                placeholder="Detalhes da infração..."
                placeholderTextColor={colors.muted}
              />
            </View>
            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable style={{ flex: 1, padding: 14, borderRadius: 12, borderWidth: 1, borderColor: colors.border, alignItems: "center" }} onPress={() => setAddFineVisible(false)}>
                <Text style={{ color: colors.muted, fontWeight: "700" }}>Cancelar</Text>
              </Pressable>
              <Pressable style={{ flex: 1, padding: 14, borderRadius: 12, backgroundColor: colors.error, alignItems: "center" }} onPress={handleAddFine}>
                <Text style={{ color: "#fff", fontWeight: "700" }}>Registrar Multa</Text>
              </Pressable>
            </View>
          </ScrollView>
        </View>
      </Modal>

      {/* ── Create Training Modal ── */}
      <Modal visible={trainingVisible} animationType="slide" presentationStyle="formSheet" onRequestClose={() => setTrainingVisible(false)}>
        <View style={{ flex: 1, backgroundColor: colors.background, padding: 24 }}>
          <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground, marginBottom: 20 }}>Criar Treinamento</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Título</Text>
          <TextInput
            value={trainingTitle}
            onChangeText={setTrainingTitle}
            style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.foreground, backgroundColor: colors.surface, marginBottom: 14 }}
          />
          <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Descrição</Text>
          <TextInput
            value={trainingDesc}
            onChangeText={setTrainingDesc}
            multiline
            numberOfLines={3}
            style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.foreground, backgroundColor: colors.surface, marginBottom: 14, minHeight: 80 }}
          />
          <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 6 }}>Carga horária (horas)</Text>
          <TextInput
            value={trainingHours}
            onChangeText={setTrainingHours}
            keyboardType="numeric"
            style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 12, color: colors.foreground, backgroundColor: colors.surface, marginBottom: 20 }}
          />
          <View style={{ flexDirection: "row", gap: 10 }}>
            <Pressable style={{ flex: 1, padding: 14, borderRadius: 12, borderWidth: 1, borderColor: colors.border, alignItems: "center" }} onPress={() => setTrainingVisible(false)}>
              <Text style={{ color: colors.muted, fontWeight: "700" }}>Cancelar</Text>
            </Pressable>
            <Pressable style={{ flex: 1, padding: 14, borderRadius: 12, backgroundColor: colors.primary, alignItems: "center" }} onPress={handleCreateTraining}>
              <Text style={{ color: "#fff", fontWeight: "700" }}>Criar</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: 22, fontWeight: "800" },
  headerSub: { fontSize: 13, marginTop: 2 },
});
