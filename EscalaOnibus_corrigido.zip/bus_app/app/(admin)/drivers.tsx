import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Modal,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  Alert,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { EmptyState } from "@/components/ui/empty-state";
import { ConfirmModal } from "@/components/ui/confirm-modal";
import { FormField } from "@/components/ui/form-field";
import { useColors } from "@/hooks/use-colors";
import { apiClient } from "@/lib/api-client";

interface DriverForm {
  name: string;
  whatsapp: string;
  driverId: string;
  username: string;
  password: string;
}

const EMPTY_FORM: DriverForm = {
  name: "",
  whatsapp: "",
  driverId: "",
  username: "",
  password: "",
};

export default function AdminDriversScreen() {
  const colors = useColors();
  const [drivers, setDrivers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [modalVisible, setModalVisible] = useState(false);
  const [editingDriver, setEditingDriver] = useState<any | null>(null);
  const [form, setForm] = useState<DriverForm>(EMPTY_FORM);
  const [formErrors, setFormErrors] = useState<Partial<DriverForm>>({});
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<any | null>(null);

  const loadDrivers = useCallback(async () => {
    setLoading(true);
    try {
      const list = await apiClient.getDrivers();
      setDrivers(list);
    } catch (error) {
      console.error("Erro ao carregar motoristas:", error);
      Alert.alert("Erro", "Não foi possível carregar os motoristas. Verifique sua conexão.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDrivers();
  }, [loadDrivers]);

  function openCreate() {
    setForm(EMPTY_FORM);
    setFormErrors({});
    setEditingDriver(null);
    setModalVisible(true);
  }

  function openEdit(driver: any) {
    setForm({
      name: driver.name,
      whatsapp: driver.whatsapp ?? "",
      driverId: driver.driverId ?? "",
      username: driver.username,
      password: "",
    });
    setFormErrors({});
    setEditingDriver(driver);
    setModalVisible(true);
  }

  function validateForm(): boolean {
    const errors: Partial<DriverForm> = {};
    if (!form.name.trim()) errors.name = "Obrigatório";
    if (!form.driverId.trim()) errors.driverId = "Obrigatório";
    if (!form.username.trim()) errors.username = "Obrigatório";
    if (!editingDriver && !form.password.trim()) errors.password = "Obrigatório";
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  }

  async function handleSave() {
    if (!validateForm()) return;
    setSaving(true);

    try {
      if (editingDriver) {
        const updateData: any = {
          name: form.name.trim(),
          whatsapp: form.whatsapp.trim() || null,
          driverId: form.driverId.trim(),
        };
        if (form.password.trim()) {
          updateData.password = form.password;
        }
        await apiClient.updateDriver(editingDriver.id, updateData);
      } else {
        await apiClient.createDriver({
          name: form.name.trim(),
          whatsapp: form.whatsapp.trim() || null,
          driverId: form.driverId.trim(),
          username: form.username.trim().toLowerCase(),
          password: form.password,
        });
      }

      setSaving(false);
      setModalVisible(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      loadDrivers();
    } catch (error: any) {
      setSaving(false);
      const msg = error?.message || "Erro ao salvar motorista";
      if (msg.includes("já existe") || msg.includes("already exists")) {
        setFormErrors((e) => ({ ...e, username: "Usuário já existe" }));
      } else {
        Alert.alert("Erro", msg);
      }
    }
  }

  async function handleDelete() {
    if (!confirmDelete) return;
    try {
      await apiClient.deleteDriver(confirmDelete.id);
      setConfirmDelete(null);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      loadDrivers();
    } catch (error: any) {
      Alert.alert("Erro", error?.message || "Erro ao excluir motorista");
    }
  }

  return (
    <ScreenContainer containerClassName="bg-background">
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Motoristas</Text>
        <Pressable
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={openCreate}
        >
          <MaterialIcons name="add" size={22} color="#fff" />
        </Pressable>
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={drivers}
          keyExtractor={(item) => item.id}
          contentContainerStyle={drivers.length === 0 ? { flex: 1 } : { padding: 16, gap: 12 }}
          ListEmptyComponent={
            <EmptyState
              icon="group-off"
              title="Nenhum motorista"
              description="Toque no botão + para cadastrar o primeiro motorista."
            />
          }
          renderItem={({ item }) => (
            <DriverCard
              driver={item}
              colors={colors}
              onEdit={() => openEdit(item)}
              onDelete={() => setConfirmDelete(item)}
            />
          )}
        />
      )}

      {/* Driver Form Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>
              {editingDriver ? "Editar Motorista" : "Novo Motorista"}
            </Text>
            <Pressable onPress={() => setModalVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20 }}>
            <FormField
              label="Nome Completo"
              value={form.name}
              onChangeText={(v) => setForm((f) => ({ ...f, name: v }))}
              placeholder="Ex: João da Silva"
              error={formErrors.name}
              autoCapitalize="words"
            />
            <FormField
              label="WhatsApp"
              value={form.whatsapp}
              onChangeText={(v) => setForm((f) => ({ ...f, whatsapp: v }))}
              placeholder="Ex: (11) 99999-9999"
              keyboardType="phone-pad"
            />
            <FormField
              label="ID do Motorista"
              value={form.driverId}
              onChangeText={(v) => setForm((f) => ({ ...f, driverId: v }))}
              placeholder="Ex: MOT-001"
              error={formErrors.driverId}
              autoCapitalize="characters"
            />
            {!editingDriver && (
              <FormField
                label="Usuário (login)"
                value={form.username}
                onChangeText={(v) => setForm((f) => ({ ...f, username: v }))}
                placeholder="Ex: joao.silva"
                error={formErrors.username}
                autoCapitalize="none"
                autoCorrect={false}
              />
            )}
            <FormField
              label={editingDriver ? "Nova Senha (deixe em branco para manter)" : "Senha"}
              value={form.password}
              onChangeText={(v) => setForm((f) => ({ ...f, password: v }))}
              placeholder={editingDriver ? "Nova senha (opcional)" : "Senha de acesso"}
              error={formErrors.password}
              isPassword
            />

            <Pressable
              style={[styles.saveBtn, { backgroundColor: colors.primary }]}
              onPress={handleSave}
              disabled={saving}
            >
              {saving ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.saveBtnText}>
                  {editingDriver ? "Salvar Alterações" : "Cadastrar Motorista"}
                </Text>
              )}
            </Pressable>
          </ScrollView>
        </View>
      </Modal>

      <ConfirmModal
        visible={!!confirmDelete}
        title="Excluir Motorista"
        message={`Deseja excluir o motorista ${confirmDelete?.name}? Esta ação não pode ser desfeita.`}
        confirmLabel="Excluir"
        destructive
        onConfirm={handleDelete}
        onCancel={() => setConfirmDelete(null)}
      />
    </ScreenContainer>
  );
}

function DriverCard({
  driver,
  colors,
  onEdit,
  onDelete,
}: {
  driver: any;
  colors: ReturnType<typeof useColors>;
  onEdit: () => void;
  onDelete: () => void;
}) {
  return (
    <View style={[cardStyles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={cardStyles.cardTop}>
        <View style={[cardStyles.avatar, { backgroundColor: driver.isSuspended ? colors.error : colors.primary }]}>
          <Text style={cardStyles.avatarText}>{driver.name.charAt(0).toUpperCase()}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[cardStyles.name, { color: colors.foreground }]}>{driver.name}</Text>
          {driver.isSuspended && (
            <Text style={[cardStyles.sub, { color: colors.error, fontWeight: "700" }]}>⚠ Suspenso</Text>
          )}
          <Text style={[cardStyles.sub, { color: colors.muted }]}>ID: {driver.driverId || "—"}</Text>
          {driver.whatsapp ? (
            <Text style={[cardStyles.sub, { color: colors.muted }]}>
              📱 {driver.whatsapp}
            </Text>
          ) : null}
          <Text style={[cardStyles.sub, { color: colors.muted }]}>
            Usuário: {driver.username}
          </Text>
        </View>
      </View>
      <View style={[cardStyles.actions, { borderTopColor: colors.border }]}>
        <Pressable
          style={({ pressed }) => [cardStyles.actionBtn, pressed && { opacity: 0.7 }]}
          onPress={onEdit}
        >
          <MaterialIcons name="edit" size={16} color={colors.primary} />
          <Text style={[cardStyles.actionText, { color: colors.primary }]}>Editar</Text>
        </Pressable>
        <Pressable
          style={({ pressed }) => [cardStyles.actionBtn, pressed && { opacity: 0.7 }]}
          onPress={onDelete}
        >
          <MaterialIcons name="delete" size={16} color={colors.error} />
          <Text style={[cardStyles.actionText, { color: colors.error }]}>Excluir</Text>
        </Pressable>
      </View>
    </View>
  );
}

const cardStyles = StyleSheet.create({
  card: {
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
  },
  cardTop: {
    flexDirection: "row",
    padding: 14,
    gap: 12,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "700",
  },
  name: {
    fontSize: 15,
    fontWeight: "700",
  },
  sub: {
    fontSize: 12,
    marginTop: 2,
  },
  actions: {
    flexDirection: "row",
    borderTopWidth: 1,
    paddingHorizontal: 8,
    paddingVertical: 6,
    gap: 4,
  },
  actionBtn: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    gap: 4,
  },
  actionText: {
    fontSize: 12,
    fontWeight: "600",
  },
});

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  saveBtn: {
    height: 50,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 8,
  },
  saveBtnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
});
