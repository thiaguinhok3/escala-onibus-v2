"use client";
import { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  ActivityIndicator,
  StyleSheet,
  Modal,
  ScrollView,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { db, type User, type WorkdayPunches, type PunchRecord } from "@/lib/database";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function formatTime(isoStr: string): string {
  const d = new Date(isoStr);
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function calcWorkDuration(wp: WorkdayPunches): string {
  if (!wp.start) return "--";
  const endTime = wp.end?.timestamp ?? new Date().toISOString();
  const totalMs = new Date(endTime).getTime() - new Date(wp.start.timestamp).getTime();
  let breakMs = 0;
  if (wp.breakStart && wp.breakEnd) {
    breakMs = new Date(wp.breakEnd.timestamp).getTime() - new Date(wp.breakStart.timestamp).getTime();
  }
  const workMs = Math.max(0, totalMs - breakMs);
  const totalMin = Math.floor(workMs / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return `${h}h ${String(m).padStart(2, "0")}min`;
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + "T12:00:00");
  d.setDate(d.getDate() + days);
  return d.toISOString().split("T")[0];
}

// ─── Driver Punch Row ─────────────────────────────────────────────────────────

function DriverPunchRow({
  driver,
  wp,
  colors,
  onPress,
}: {
  driver: User;
  wp: WorkdayPunches | null;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  const hasAny = !!wp?.start;
  const isComplete = !!wp?.end;

  return (
    <Pressable
      style={[rowStyles.row, { backgroundColor: colors.surface, borderColor: colors.border }]}
      onPress={onPress}
    >
      <View style={[rowStyles.avatar, { backgroundColor: hasAny ? colors.primary : colors.border }]}>
        <Text style={{ color: "#fff", fontSize: 16, fontWeight: "700" }}>
          {driver.name.charAt(0).toUpperCase()}
        </Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>{driver.name}</Text>
        {hasAny ? (
          <View style={{ flexDirection: "row", gap: 10, marginTop: 3 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
              <MaterialIcons name="login" size={12} color={colors.success} />
              <Text style={{ fontSize: 11, color: colors.muted }}>{formatTime(wp!.start!.timestamp)}</Text>
            </View>
            {wp?.end && (
              <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                <MaterialIcons name="logout" size={12} color={colors.error} />
                <Text style={{ fontSize: 11, color: colors.muted }}>{formatTime(wp.end.timestamp)}</Text>
              </View>
            )}
            <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
              <MaterialIcons name="timer" size={12} color={colors.primary} />
              <Text style={{ fontSize: 11, color: colors.muted }}>{calcWorkDuration(wp!)}</Text>
            </View>
          </View>
        ) : (
          <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>Sem registro hoje</Text>
        )}
      </View>
      <View style={[rowStyles.badge, {
        backgroundColor: !hasAny ? colors.border + "40" : isComplete ? colors.success + "20" : colors.warning + "20",
      }]}>
        <Text style={{ fontSize: 10, fontWeight: "700", color: !hasAny ? colors.muted : isComplete ? colors.success : colors.warning }}>
          {!hasAny ? "Ausente" : isComplete ? "Completo" : "Em andamento"}
        </Text>
      </View>
    </Pressable>
  );
}

const rowStyles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    marginBottom: 10,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function AdminPunchesScreen() {
  const colors = useColors();
  const [selectedDate, setSelectedDate] = useState(todayISO());
  const [drivers, setDrivers] = useState<User[]>([]);
  const [workdays, setWorkdays] = useState<Map<string, WorkdayPunches>>(new Map());
  const [loading, setLoading] = useState(true);
  const [selectedWP, setSelectedWP] = useState<{ driver: User; wp: WorkdayPunches } | null>(null);
  const [detailVisible, setDetailVisible] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    const driverList = await db.getDrivers();
    setDrivers(driverList);
    const wps = await Promise.all(
      driverList.map((d) => db.getWorkdayPunches(d.id, selectedDate))
    );
    const map = new Map<string, WorkdayPunches>();
    driverList.forEach((d, i) => map.set(d.id, wps[i]));
    setWorkdays(map);
    setLoading(false);
  }, [selectedDate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const presentCount = [...workdays.values()].filter((w) => w.start).length;
  const completeCount = [...workdays.values()].filter((w) => w.end).length;

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Ponto Eletrônico</Text>
          <Text style={[styles.headerSub, { color: colors.muted }]}>Controle de jornada</Text>
        </View>
        <MaterialIcons name="fingerprint" size={28} color={colors.primary} />
      </View>

      {/* Date Selector */}
      <View style={[styles.dateBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => setSelectedDate(addDays(selectedDate, -1))} style={styles.dateArrow}>
          <MaterialIcons name="chevron-left" size={24} color={colors.primary} />
        </Pressable>
        <Text style={[styles.dateText, { color: colors.foreground }]}>
          {selectedDate === todayISO() ? "Hoje — " : ""}{formatDate(selectedDate)}
        </Text>
        <Pressable onPress={() => setSelectedDate(addDays(selectedDate, 1))} style={styles.dateArrow}>
          <MaterialIcons name="chevron-right" size={24} color={colors.primary} />
        </Pressable>
      </View>

      {/* Summary */}
      <View style={[styles.summaryRow, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <View style={[styles.summaryCard, { borderTopColor: colors.primary }]}>
          <Text style={[styles.summaryValue, { color: colors.primary }]}>{drivers.length}</Text>
          <Text style={styles.summaryLabel}>Total</Text>
        </View>
        <View style={[styles.summaryCard, { borderTopColor: colors.success }]}>
          <Text style={[styles.summaryValue, { color: colors.success }]}>{presentCount}</Text>
          <Text style={styles.summaryLabel}>Registraram</Text>
        </View>
        <View style={[styles.summaryCard, { borderTopColor: colors.warning }]}>
          <Text style={[styles.summaryValue, { color: colors.warning }]}>{presentCount - completeCount}</Text>
          <Text style={styles.summaryLabel}>Em andamento</Text>
        </View>
        <View style={[styles.summaryCard, { borderTopColor: colors.error }]}>
          <Text style={[styles.summaryValue, { color: colors.error }]}>{drivers.length - presentCount}</Text>
          <Text style={styles.summaryLabel}>Ausentes</Text>
        </View>
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : drivers.length === 0 ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <MaterialIcons name="group" size={48} color={colors.border} />
          <Text style={{ color: colors.muted, marginTop: 12 }}>Nenhum motorista cadastrado</Text>
        </View>
      ) : (
        <FlatList
          data={drivers}
          keyExtractor={(d) => d.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }) => (
            <DriverPunchRow
              driver={item}
              wp={workdays.get(item.id) ?? null}
              colors={colors}
              onPress={() => {
                const wp = workdays.get(item.id);
                if (wp?.start) {
                  setSelectedWP({ driver: item, wp });
                  setDetailVisible(true);
                }
              }}
            />
          )}
        />
      )}

      {/* Detail Modal */}
      <Modal
        visible={detailVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setDetailVisible(false)}
      >
        {selectedWP && (
          <View style={{ flex: 1, backgroundColor: colors.background }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }}>
              <View>
                <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>
                  {selectedWP.driver.name}
                </Text>
                <Text style={{ fontSize: 13, color: colors.muted }}>{formatDate(selectedDate)}</Text>
              </View>
              <Pressable onPress={() => setDetailVisible(false)}>
                <MaterialIcons name="close" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
              {/* Duration card */}
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12, padding: 16, borderRadius: 14, borderWidth: 1, borderColor: colors.primary, backgroundColor: colors.primary + "10" }}>
                <MaterialIcons name="timer" size={20} color={colors.primary} />
                <View>
                  <Text style={{ fontSize: 11, color: colors.muted, fontWeight: "600" }}>JORNADA EFETIVA</Text>
                  <Text style={{ fontSize: 24, fontWeight: "800", color: colors.foreground }}>{calcWorkDuration(selectedWP.wp)}</Text>
                </View>
              </View>

              {/* Punch detail rows */}
              {([
                { punch: selectedWP.wp.start, label: "Início de Serviço", color: colors.success, icon: "login" },
                { punch: selectedWP.wp.breakStart, label: "Início da Pausa", color: colors.warning, icon: "restaurant" },
                { punch: selectedWP.wp.breakEnd, label: "Retorno da Pausa", color: colors.primary, icon: "replay" },
                { punch: selectedWP.wp.end, label: "Término de Trabalho", color: colors.error, icon: "logout" },
              ] as { punch?: PunchRecord; label: string; color: string; icon: keyof typeof MaterialIcons.glyphMap }[])
                .map((item, i) => (
                  <View key={i} style={{ padding: 14, borderRadius: 12, borderWidth: 1, borderColor: item.punch ? item.color + "40" : colors.border, backgroundColor: item.punch ? item.color + "08" : colors.surface }}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                      <View style={{ width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: item.punch ? item.color : colors.border }}>
                        <MaterialIcons name={item.icon} size={14} color="#fff" />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={{ fontSize: 12, fontWeight: "700", color: item.punch ? colors.foreground : colors.muted }}>{item.label}</Text>
                        <Text style={{ fontSize: 16, fontWeight: "800", color: item.punch ? item.color : colors.muted }}>
                          {item.punch ? formatTime(item.punch.timestamp) : "Não registrado"}
                        </Text>
                        {item.punch?.note && (
                          <Text style={{ fontSize: 11, color: colors.muted, fontStyle: "italic", marginTop: 2 }}>"{item.punch.note}"</Text>
                        )}
                      </View>
                    </View>
                  </View>
                ))}
            </ScrollView>
          </View>
        )}
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: 22, fontWeight: "800" },
  headerSub: { fontSize: 13, marginTop: 2 },
  dateBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  dateArrow: { padding: 4 },
  dateText: { fontSize: 15, fontWeight: "700" },
  summaryRow: {
    flexDirection: "row",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderBottomWidth: 1,
    gap: 8,
  },
  summaryCard: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 8,
    borderTopWidth: 3,
  },
  summaryValue: { fontSize: 20, fontWeight: "800" },
  summaryLabel: { fontSize: 10, color: "#64748B", fontWeight: "600", marginTop: 2 },
});
