import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Modal,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { EmptyState } from "@/components/ui/empty-state";
import { useColors } from "@/hooks/use-colors";
import { db, type Occurrence, type OccurrenceType } from "@/lib/database";

const OCCURRENCE_LABELS: Record<OccurrenceType, string> = {
  mechanical: "Problema Mecânico",
  accident: "Acidente",
  delay: "Atraso",
  passenger: "Problema com Passageiro",
  route: "Problema na Rota",
  other: "Outro",
};

const OCCURRENCE_ICONS: Record<OccurrenceType, keyof typeof MaterialIcons.glyphMap> = {
  mechanical: "build",
  accident: "car-crash",
  delay: "schedule",
  passenger: "person-off",
  route: "alt-route",
  other: "report",
};

function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function AdminReportsScreen() {
  const colors = useColors();
  const [occurrences, setOccurrences] = useState<Occurrence[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Occurrence | null>(null);

  const loadOccurrences = useCallback(async () => {
    setLoading(true);
    const list = await db.getOccurrences();
    setOccurrences(list);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadOccurrences();
  }, [loadOccurrences]);

  async function handleView(occ: Occurrence) {
    setSelected(occ);
    if (!occ.isRead) {
      await db.markOccurrenceAsRead(occ.id);
      loadOccurrences();
    }
  }

  const unreadCount = occurrences.filter((o) => !o.isRead).length;

  return (
    <ScreenContainer containerClassName="bg-background">
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Relatórios</Text>
          {unreadCount > 0 && (
            <Text style={[styles.headerSub, { color: colors.warning }]}>
              {unreadCount} nova{unreadCount > 1 ? "s" : ""} ocorrência{unreadCount > 1 ? "s" : ""}
            </Text>
          )}
        </View>
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={occurrences}
          keyExtractor={(item) => item.id}
          contentContainerStyle={occurrences.length === 0 ? { flex: 1 } : { padding: 16, gap: 10 }}
          ListEmptyComponent={
            <EmptyState
              icon="description"
              title="Nenhum relatório"
              description="Os motoristas ainda não enviaram ocorrências."
            />
          }
          renderItem={({ item }) => (
            <OccurrenceCard
              occurrence={item}
              colors={colors}
              onPress={() => handleView(item)}
            />
          )}
        />
      )}

      {/* Detail Modal */}
      <Modal
        visible={!!selected}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setSelected(null)}
      >
        {selected && (
          <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Detalhes da Ocorrência</Text>
              <Pressable onPress={() => setSelected(null)}>
                <MaterialIcons name="close" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
              <View style={[styles.typeTag, { backgroundColor: colors.warning + "20", borderColor: colors.warning }]}>
                <MaterialIcons name={OCCURRENCE_ICONS[selected.type]} size={18} color={colors.warning} />
                <Text style={[styles.typeText, { color: colors.warning }]}>
                  {OCCURRENCE_LABELS[selected.type]}
                </Text>
              </View>
              <DetailRow label="Motorista" value={selected.driverName} colors={colors} />
              <DetailRow label="Data/Hora" value={formatDateTime(selected.createdAt)} colors={colors} />
              <View style={{ gap: 4 }}>
                <Text style={{ fontSize: 12, color: colors.muted, fontWeight: "600" }}>Descrição</Text>
                <Text style={{ fontSize: 15, color: colors.foreground, lineHeight: 22 }}>
                  {selected.description}
                </Text>
              </View>
            </ScrollView>
          </View>
        )}
      </Modal>
    </ScreenContainer>
  );
}

function OccurrenceCard({
  occurrence,
  colors,
  onPress,
}: {
  occurrence: Occurrence;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [
        cardStyles.card,
        {
          backgroundColor: colors.surface,
          borderColor: occurrence.isRead ? colors.border : colors.warning,
          borderLeftWidth: occurrence.isRead ? 1 : 4,
          opacity: pressed ? 0.85 : 1,
        },
      ]}
      onPress={onPress}
    >
      <View style={cardStyles.row}>
        <View
          style={[
            cardStyles.iconBox,
            { backgroundColor: colors.warning + "20" },
          ]}
        >
          <MaterialIcons
            name={OCCURRENCE_ICONS[occurrence.type]}
            size={22}
            color={colors.warning}
          />
        </View>
        <View style={{ flex: 1, gap: 2 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <Text style={[cardStyles.typeLabel, { color: colors.foreground }]}>
              {OCCURRENCE_LABELS[occurrence.type]}
            </Text>
            {!occurrence.isRead && (
              <View style={[cardStyles.newBadge, { backgroundColor: colors.warning }]}>
                <Text style={cardStyles.newBadgeText}>Novo</Text>
              </View>
            )}
          </View>
          <Text style={[cardStyles.driver, { color: colors.muted }]}>
            {occurrence.driverName}
          </Text>
          <Text style={[cardStyles.desc, { color: colors.muted }]} numberOfLines={2}>
            {occurrence.description}
          </Text>
          <Text style={[cardStyles.time, { color: colors.muted }]}>
            {formatDateTime(occurrence.createdAt)}
          </Text>
        </View>
        <MaterialIcons name="chevron-right" size={20} color={colors.muted} />
      </View>
    </Pressable>
  );
}

function DetailRow({
  label,
  value,
  colors,
}: {
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 2 }}>
      <Text style={{ fontSize: 12, color: colors.muted, fontWeight: "600" }}>{label}</Text>
      <Text style={{ fontSize: 15, color: colors.foreground }}>{value}</Text>
    </View>
  );
}

const cardStyles = StyleSheet.create({
  card: {
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
  },
  row: {
    flexDirection: "row",
    padding: 14,
    gap: 12,
    alignItems: "flex-start",
  },
  iconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  typeLabel: {
    fontSize: 14,
    fontWeight: "700",
  },
  driver: {
    fontSize: 12,
  },
  desc: {
    fontSize: 13,
    lineHeight: 18,
  },
  time: {
    fontSize: 11,
    marginTop: 2,
  },
  newBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  newBadgeText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },
});

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  headerSub: {
    fontSize: 13,
    marginTop: 2,
    fontWeight: "600",
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  typeTag: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    alignSelf: "flex-start",
  },
  typeText: {
    fontSize: 14,
    fontWeight: "700",
  },
});
