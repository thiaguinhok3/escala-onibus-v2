import React, { useState } from "react";
import {
  View,
  Text,
  Pressable,
  Modal,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  Alert,
  Linking,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { FormField } from "@/components/ui/form-field";
import { ConfirmModal } from "@/components/ui/confirm-modal";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { apiClient } from "@/lib/api-client";

export default function AdminProfileScreen() {
  const colors = useColors();
  const { user, logout, refreshUser } = useAuth();

  const [passwordModalVisible, setPasswordModalVisible] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [saving, setSaving] = useState(false);
  const [logoutConfirm, setLogoutConfirm] = useState(false);

  async function handleChangePassword() {
    setPasswordError("");
    if (!currentPassword || !newPassword || !confirmPassword) {
      setPasswordError("Preencha todos os campos.");
      return;
    }
    if (user?.password !== currentPassword) {
      setPasswordError("Senha atual incorreta.");
      return;
    }
    if (newPassword.length < 4) {
      setPasswordError("A nova senha deve ter ao menos 4 caracteres.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError("As senhas não coincidem.");
      return;
    }
    setSaving(true);
    try {
      await apiClient.updateDriver(user!.id, { password: newPassword });
      await refreshUser();
      setPasswordModalVisible(false);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error: any) {
      setPasswordError(error?.message || 'Erro ao atualizar senha.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <ScreenContainer containerClassName="bg-background">
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Perfil</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
        {/* Avatar + Name */}
        <View style={[styles.profileCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={[styles.avatar, { backgroundColor: colors.primary }]}>
            <Text style={styles.avatarText}>
              {user?.name?.charAt(0)?.toUpperCase() ?? "A"}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.name, { color: colors.foreground }]}>{user?.name}</Text>
            <View style={[styles.roleBadge, { backgroundColor: colors.primary + "20" }]}>
              <Text style={[styles.roleText, { color: colors.primary }]}>Administrador</Text>
            </View>
          </View>
        </View>

        {/* Info */}
        <View style={[styles.infoCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <InfoRow
            icon="person"
            label="Usuário"
            value={user?.username ?? ""}
            colors={colors}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <InfoRow
            icon="lock"
            label="Senha"
            value="••••••••"
            colors={colors}
          />
        </View>

        {/* Actions */}
        <Pressable
          style={[styles.actionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
          onPress={() => setPasswordModalVisible(true)}
        >
          <MaterialIcons name="lock" size={20} color={colors.primary} />
          <Text style={[styles.actionText, { color: colors.foreground }]}>Alterar Senha</Text>
          <MaterialIcons name="chevron-right" size={20} color={colors.muted} />
        </Pressable>

        <Pressable
          style={[styles.actionCard, { backgroundColor: colors.success + "15", borderColor: colors.success }]}
          onPress={() => {
            const whatsappUrl = `https://wa.me/5519995605536?text=Olá%20EscalaOnibus%2C%20preciso%20de%20suporte`;
            Linking.openURL(whatsappUrl).catch(() => {
              Alert.alert("Erro", "Não foi possível abrir o WhatsApp. Verifique se está instalado.");
            });
          }}
        >
          <MaterialIcons name="support-agent" size={20} color={colors.success} />
          <Text style={[styles.actionText, { color: colors.foreground }]}>Suporte via WhatsApp</Text>
          <MaterialIcons name="chevron-right" size={20} color={colors.muted} />
        </Pressable>

        <View style={[styles.infoCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <InfoRow
            icon="info"
            label="Versão do App"
            value="1.0.0"
            colors={colors}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <InfoRow
            icon="directions-bus"
            label="Sistema"
            value="EscalaOnibus"
            colors={colors}
          />
        </View>

        <Pressable
          style={[styles.logoutBtn, { borderColor: colors.error }]}
          onPress={() => setLogoutConfirm(true)}
        >
          <MaterialIcons name="logout" size={20} color={colors.error} />
          <Text style={[styles.logoutText, { color: colors.error }]}>Sair da Conta</Text>
        </Pressable>

        <Text style={[styles.footerText, { color: colors.muted }]}>
          EscalaOnibus v1.0.0 • Suporte: (19) 99560-5536
        </Text>
      </ScrollView>

      {/* Change Password Modal */}
      <Modal
        visible={passwordModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setPasswordModalVisible(false)}
      >
        <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Alterar Senha</Text>
            <Pressable onPress={() => setPasswordModalVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20 }}>
            <FormField
              label="Senha Atual"
              value={currentPassword}
              onChangeText={setCurrentPassword}
              placeholder="Digite a senha atual"
              isPassword
            />
            <FormField
              label="Nova Senha"
              value={newPassword}
              onChangeText={setNewPassword}
              placeholder="Digite a nova senha"
              isPassword
            />
            <FormField
              label="Confirmar Nova Senha"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              placeholder="Repita a nova senha"
              isPassword
            />
            {passwordError ? (
              <View style={[styles.errorBox, { backgroundColor: "#FEE2E2", borderColor: colors.error }]}>
                <Text style={{ color: colors.error, fontSize: 13 }}>{passwordError}</Text>
              </View>
            ) : null}
            <Pressable
              style={[styles.saveBtn, { backgroundColor: colors.primary }]}
              onPress={handleChangePassword}
              disabled={saving}
            >
              {saving ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.saveBtnText}>Salvar Nova Senha</Text>
              )}
            </Pressable>
          </ScrollView>
        </View>
      </Modal>

      <ConfirmModal
        visible={logoutConfirm}
        title="Sair da Conta"
        message="Deseja realmente sair? Você precisará fazer login novamente."
        confirmLabel="Sair"
        destructive
        onConfirm={async () => {
          setLogoutConfirm(false);
          await logout();
        }}
        onCancel={() => setLogoutConfirm(false)}
      />
    </ScreenContainer>
  );
}

function InfoRow({
  icon,
  label,
  value,
  colors,
}: {
  icon: keyof typeof MaterialIcons.glyphMap;
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={infoStyles.row}>
      <MaterialIcons name={icon} size={18} color={colors.muted} />
      <View style={{ flex: 1 }}>
        <Text style={[infoStyles.label, { color: colors.muted }]}>{label}</Text>
        <Text style={[infoStyles.value, { color: colors.foreground }]}>{value}</Text>
      </View>
    </View>
  );
}

const infoStyles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 12,
  },
  label: {
    fontSize: 11,
    fontWeight: "600",
  },
  value: {
    fontSize: 14,
    marginTop: 1,
  },
});

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  profileCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 16,
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: "#fff",
    fontSize: 28,
    fontWeight: "800",
  },
  name: {
    fontSize: 18,
    fontWeight: "700",
  },
  roleBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 6,
    marginTop: 4,
  },
  roleText: {
    fontSize: 12,
    fontWeight: "700",
  },
  infoCard: {
    borderRadius: 16,
    borderWidth: 1,
    overflow: "hidden",
  },
  divider: {
    height: 1,
    marginHorizontal: 14,
  },
  actionCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    gap: 12,
  },
  actionText: {
    flex: 1,
    fontSize: 15,
    fontWeight: "600",
  },
  logoutBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    borderRadius: 16,
    borderWidth: 1.5,
    gap: 8,
    marginTop: 8,
  },
  logoutText: {
    fontSize: 15,
    fontWeight: "700",
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  errorBox: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  saveBtn: {
    height: 50,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 8,
  },
  saveBtnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  footerText: {
    textAlign: "center",
    fontSize: 12,
    marginTop: 8,
    marginBottom: 20,
  },
});
