import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Modal,
  ScrollView,
  TextInput,
  Alert,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { StatusBadge } from "@/components/ui/status-badge";
import { EmptyState } from "@/components/ui/empty-state";
import { ConfirmModal } from "@/components/ui/confirm-modal";
import { FormField } from "@/components/ui/form-field";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { apiClient } from "@/lib/api-client";
import type { Schedule, User, ScheduleStatus, ScheduleType } from "@/lib/database";
import { notifyScheduleApproved, notifyScheduleDenied } from "@/lib/notifications";
import { Platform } from "react-native";

type ModalMode = "create" | "edit" | "view";
type RecurringMode = "none" | "week" | "month" | "custom";

interface ScheduleForm {
  date: string;
  line: string;
  driverId: string;
  busModel: string;
  busPrefix: string;
  startTime: string;
  endTime: string;
  observations: string;
  scheduleType: ScheduleType;
}

const EMPTY_FORM: ScheduleForm = {
  date: "",
  line: "",
  driverId: "",
  busModel: "",
  busPrefix: "",
  startTime: "",
  endTime: "",
  observations: "",
  scheduleType: "work",
};

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + "T12:00:00");
  d.setDate(d.getDate() + days);
  return d.toISOString().split("T")[0];
}

export default function AdminSchedulesScreen() {
  const colors = useColors();
  const { user } = useAuth();

  const [selectedDate, setSelectedDate] = useState(todayISO());
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [drivers, setDrivers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  const [modalVisible, setModalVisible] = useState(false);
  const [modalMode, setModalMode] = useState<ModalMode>("create");
  const [selectedSchedule, setSelectedSchedule] = useState<Schedule | null>(null);
  const [form, setForm] = useState<ScheduleForm>(EMPTY_FORM);
  const [formErrors, setFormErrors] = useState<Partial<ScheduleForm>>({});
  const [saving, setSaving] = useState(false);

  const [confirmDelete, setConfirmDelete] = useState<Schedule | null>(null);
  const [driverPickerVisible, setDriverPickerVisible] = useState(false);
  const [filterDriverId, setFilterDriverId] = useState<string>("all");
  const [filterPickerVisible, setFilterPickerVisible] = useState(false);
  const [recurringMode, setRecurringMode] = useState<RecurringMode>("none");
  const [recurringDays, setRecurringDays] = useState<number>(7); // for custom
  const [denyTarget, setDenyTarget] = useState<Schedule | null>(null);
  const [denyReason, setDenyReason] = useState<string>("");
  const [denyModalVisible, setDenyModalVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [searchFocused, setSearchFocused] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [allSchedules, d] = await Promise.all([
        apiClient.getSchedules(),
        apiClient.getDrivers(),
      ]);
      // Filtrar escalas pela data selecionada
      const s = allSchedules.filter((sc: any) => {
        const date = sc.date?.split('T')[0] || sc.date;
        return date === selectedDate;
      });
      setSchedules(s);
      setDrivers(d);
    } catch (error) {
      console.error('Erro ao carregar escalas:', error);
      Alert.alert('Erro', 'Não foi possível carregar os dados. Verifique sua conexão.');
    } finally {
      setLoading(false);
    }
  }, [selectedDate]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  function openCreate() {
    setForm({ ...EMPTY_FORM, date: selectedDate });
    setFormErrors({});
    setModalMode("create");
    setSelectedSchedule(null);
    setModalVisible(true);
  }

  function openEdit(s: Schedule) {
    setForm({
      date: s.date,
      line: s.line,
      driverId: s.driverId,
      busModel: s.busModel,
      busPrefix: s.busPrefix,
      startTime: s.startTime,
      endTime: s.endTime,
      observations: s.observations ?? "",
      scheduleType: s.scheduleType ?? "work",
    });
    setFormErrors({});
    setModalMode("edit");
    setSelectedSchedule(s);
    setModalVisible(true);
  }

  function openView(s: Schedule) {
    setSelectedSchedule(s);
    setModalMode("view");
    setModalVisible(true);
  }

  function validateForm(): boolean {
    const errors: Partial<ScheduleForm> = {};
    if (!form.date) errors.date = "Obrigatório";
    if (!form.line.trim()) errors.line = "Obrigatório";
    if (!form.driverId) errors.driverId = "Selecione um motorista";
    if (!form.busModel.trim()) errors.busModel = "Obrigatório";
    if (!form.busPrefix.trim()) errors.busPrefix = "Obrigatório";
    if (!form.startTime) errors.startTime = "Obrigatório";
    if (!form.endTime) errors.endTime = "Obrigatório";
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  }

  function getRecurringDates(startDate: string): string[] {
    const dates: string[] = [];
    let count = 0;
    if (recurringMode === "week") count = 7;
    else if (recurringMode === "month") count = 30;
    else if (recurringMode === "custom") count = recurringDays;
    for (let i = 1; i < count; i++) {
      dates.push(addDays(startDate, i));
    }
    return dates;
  }

  async function handleSave() {
    if (!validateForm()) return;
    setSaving(true);
    const driver = drivers.find((d) => d.id === form.driverId);
    if (!driver) { setSaving(false); return; }

    try {
      if (modalMode === "create") {
        if (recurringMode !== "none") {
          const extraDates = getRecurringDates(form.date);
          const allDates = [form.date, ...extraDates];
          for (const date of allDates) {
            await apiClient.createSchedule({ ...form, date, driverName: driver.name });
          }
          Alert.alert("Escalas criadas!", `${allDates.length} escalas criadas com sucesso.`);
        } else {
          await apiClient.createSchedule({ ...form, driverName: driver.name });
        }
      } else if (modalMode === "edit" && selectedSchedule) {
        await apiClient.updateSchedule(selectedSchedule.id, { ...form, driverName: driver.name });
      }
    } catch (error: any) {
      Alert.alert("Erro", error?.message || "Erro ao salvar escala");
      setSaving(false);
      return;
    }
    setSaving(false);
    setModalVisible(false);
    setRecurringMode("none");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    loadData();
  }

  async function handleApprove(s: any) {
    try {
      await apiClient.updateSchedule(s.id, { status: "approved" });
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      if (Platform.OS !== "web") {
        await notifyScheduleApproved({
          driverName: s.driverName || s.driver_name || "",
          date: s.date,
          line: s.line,
          startTime: s.startTime || s.start_time,
          endTime: s.endTime || s.end_time,
        });
      }
      loadData();
    } catch (error: any) {
      Alert.alert("Erro", error?.message || "Erro ao aprovar escala");
    }
  }

  function openDenyModal(s: Schedule) {
    setDenyTarget(s);
    setDenyReason("");
    setDenyModalVisible(true);
  }

  async function handleDeny(reason: string) {
    if (!denyTarget) return;
    try {
      await apiClient.updateSchedule(denyTarget.id, { status: "denied", denyReason: reason.trim() || undefined });
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      if (Platform.OS !== "web") {
        await notifyScheduleDenied({
          driverName: (denyTarget as any).driverName || (denyTarget as any).driver_name || "",
          date: denyTarget.date,
          line: denyTarget.line,
        });
      }
      setDenyModalVisible(false);
      setDenyTarget(null);
      setDenyReason("");
      setModalVisible(false);
      loadData();
    } catch (error: any) {
      Alert.alert("Erro", error?.message || "Erro ao negar escala");
    }
  }

  async function handleDelete() {
    if (!confirmDelete) return;
    try {
      await apiClient.deleteSchedule(confirmDelete.id);
      setConfirmDelete(null);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      loadData();
    } catch (error: any) {
      Alert.alert("Erro", error?.message || "Erro ao excluir escala");
    }
  }

  // Apply driver filter
  const filteredSchedules = schedules
    .filter((s) => filterDriverId === "all" || s.driverId === filterDriverId)
    .filter((s) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        s.driverName.toLowerCase().includes(q) ||
        s.line.toLowerCase().includes(q) ||
        s.busPrefix.toLowerCase().includes(q) ||
        s.busModel.toLowerCase().includes(q)
      );
    });

  const totalApproved = filteredSchedules.filter((s) => s.status === "approved").length;
  const totalPending = filteredSchedules.filter((s) => s.status === "pending").length;
  const totalDenied = filteredSchedules.filter((s) => s.status === "denied").length;

  const selectedDriver = drivers.find((d) => d.id === form.driverId);
  const filterDriverName =
    filterDriverId === "all"
      ? "Todos"
      : drivers.find((d) => d.id === filterDriverId)?.name ?? "Motorista";

  return (
    <ScreenContainer containerClassName="bg-background">
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Escalas</Text>
          <Text style={[styles.headerSub, { color: colors.muted }]}>
            Olá, {user?.name ?? "Admin"}
          </Text>
        </View>
        <Pressable
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={openCreate}
        >
          <MaterialIcons name="add" size={22} color="#fff" />
        </Pressable>
      </View>

      {/* Date Selector */}
      <View style={[styles.dateBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => setSelectedDate(addDays(selectedDate, -1))} style={styles.dateArrow}>
          <MaterialIcons name="chevron-left" size={24} color={colors.primary} />
        </Pressable>
        <Text style={[styles.dateText, { color: colors.foreground }]}>
          {selectedDate === todayISO() ? "Hoje — " : ""}{formatDate(selectedDate)}
        </Text>
        <Pressable onPress={() => setSelectedDate(addDays(selectedDate, 1))} style={styles.dateArrow}>
          <MaterialIcons name="chevron-right" size={24} color={colors.primary} />
        </Pressable>
      </View>

      {/* Search Bar */}
      <View style={[{ paddingHorizontal: 16, paddingVertical: 8, backgroundColor: colors.background, borderBottomWidth: 1, borderBottomColor: colors.border }]}>
        <View style={[{ flexDirection: "row", alignItems: "center", backgroundColor: colors.surface, borderRadius: 10, borderWidth: 1.5, borderColor: searchFocused ? colors.primary : colors.border, paddingHorizontal: 10, gap: 8 }]}>
          <MaterialIcons name="search" size={18} color={searchFocused ? colors.primary : colors.muted} />
          <TextInput
            style={[{ flex: 1, height: 38, fontSize: 14, color: colors.foreground }]}
            placeholder="Buscar por motorista, linha, prefixo..."
            placeholderTextColor={colors.muted}
            value={searchQuery}
            onChangeText={setSearchQuery}
            onFocus={() => setSearchFocused(true)}
            onBlur={() => setSearchFocused(false)}
            returnKeyType="search"
            clearButtonMode="while-editing"
          />
          {searchQuery.length > 0 && (
            <Pressable onPress={() => setSearchQuery("")}>
              <MaterialIcons name="close" size={16} color={colors.muted} />
            </Pressable>
          )}
        </View>
      </View>

      {/* Driver Filter Bar */}
      <View style={[styles.filterBar, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <Pressable
          style={[styles.filterBtn, { backgroundColor: filterDriverId === "all" ? colors.surface : colors.primary + "15", borderColor: filterDriverId === "all" ? colors.border : colors.primary }]}
          onPress={() => setFilterPickerVisible(true)}
        >
          <MaterialIcons name="person-search" size={16} color={filterDriverId === "all" ? colors.muted : colors.primary} />
          <Text style={[styles.filterBtnText, { color: filterDriverId === "all" ? colors.muted : colors.primary }]} numberOfLines={1}>
            {filterDriverName}
          </Text>
          <MaterialIcons name="arrow-drop-down" size={18} color={filterDriverId === "all" ? colors.muted : colors.primary} />
        </Pressable>
        {filterDriverId !== "all" && (
          <Pressable
            style={[styles.filterClearBtn, { backgroundColor: colors.error + "15" }]}
            onPress={() => setFilterDriverId("all")}
          >
            <MaterialIcons name="close" size={16} color={colors.error} />
          </Pressable>
        )}
      </View>

      {/* Summary */}
      <View style={[styles.summaryRow, { backgroundColor: colors.background }]}>
        <SummaryCard label="Total" value={filteredSchedules.length} color={colors.primary} />
        <SummaryCard label="Aprovadas" value={totalApproved} color={colors.success} />
        <SummaryCard label="Pendentes" value={totalPending} color={colors.warning} />
        <SummaryCard label="Negadas" value={totalDenied} color={colors.error} />
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={filteredSchedules}
          keyExtractor={(item) => item.id}
          contentContainerStyle={filteredSchedules.length === 0 ? { flex: 1 } : { padding: 16, gap: 12 }}
          ListEmptyComponent={
            <EmptyState
              icon="event-busy"
              title="Nenhuma escala"
              description={filterDriverId !== "all" ? `Nenhuma escala para ${filterDriverName} neste dia.` : "Toque no botão + para criar uma escala para este dia."}
            />
          }
          renderItem={({ item }) => (
            <ScheduleCard
              schedule={item}
              colors={colors}
              onView={() => openView(item)}
              onEdit={() => openEdit(item)}
              onApprove={() => handleApprove(item)}
              onDeny={() => openDenyModal(item)}
              onDelete={() => setConfirmDelete(item)}
            />
          )}
        />
      )}

      {/* Schedule Form Modal */}
      <Modal
        visible={modalVisible && (modalMode === "create" || modalMode === "edit")}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>
              {modalMode === "create" ? "Nova Escala" : "Editar Escala"}
            </Text>
            <Pressable onPress={() => setModalVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 20 }}>
            {/* Schedule Type Selector */}
            <View style={{ marginBottom: 16 }}>
              <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Tipo de Escala</Text>
              <View style={{ flexDirection: "row", gap: 8 }}>
                {(["work", "day_off", "vacation"] as ScheduleType[]).map((t) => {
                  const labels: Record<ScheduleType, string> = { work: "Trabalho", day_off: "Folga", vacation: "Férias" };
                  const typeColors: Record<ScheduleType, string> = { work: colors.primary, day_off: colors.warning, vacation: colors.success };
                  const isActive = form.scheduleType === t;
                  return (
                    <Pressable
                      key={t}
                      style={[{ flex: 1, paddingVertical: 10, borderRadius: 10, borderWidth: 1.5, alignItems: "center", backgroundColor: isActive ? typeColors[t] + "20" : colors.surface, borderColor: isActive ? typeColors[t] : colors.border }]}
                      onPress={() => setForm((f) => ({ ...f, scheduleType: t }))}
                    >
                      <Text style={{ fontSize: 13, fontWeight: "700", color: isActive ? typeColors[t] : colors.muted }}>{labels[t]}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>

            <FormField
              label="Data (AAAA-MM-DD)"
              value={form.date}
              onChangeText={(v) => setForm((f) => ({ ...f, date: v }))}
              placeholder="Ex: 2025-12-31"
              error={formErrors.date}
              keyboardType="numbers-and-punctuation"
            />
            <FormField
              label="Linha"
              value={form.line}
              onChangeText={(v) => setForm((f) => ({ ...f, line: v }))}
              placeholder="Ex: 101 - Centro/Terminal"
              error={formErrors.line}
            />

            {/* Driver Picker */}
            <View style={{ marginBottom: 16 }}>
              <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Motorista</Text>
              <Pressable
                style={[
                  styles.pickerBtn,
                  {
                    borderColor: formErrors.driverId ? colors.error : colors.border,
                    backgroundColor: colors.background,
                  },
                ]}
                onPress={() => setDriverPickerVisible(true)}
              >
                <Text style={{ color: selectedDriver ? colors.foreground : colors.muted, fontSize: 15 }}>
                  {selectedDriver ? selectedDriver.name : "Selecionar motorista..."}
                </Text>
                <MaterialIcons name="arrow-drop-down" size={24} color={colors.muted} />
              </Pressable>
              {formErrors.driverId ? (
                <Text style={{ color: colors.error, fontSize: 12, marginTop: 4 }}>{formErrors.driverId}</Text>
              ) : null}
            </View>

            <FormField
              label="Modelo do Ônibus"
              value={form.busModel}
              onChangeText={(v) => setForm((f) => ({ ...f, busModel: v }))}
              placeholder="Ex: Mercedes-Benz OF 1721"
              error={formErrors.busModel}
            />
            <FormField
              label="Prefixo"
              value={form.busPrefix}
              onChangeText={(v) => setForm((f) => ({ ...f, busPrefix: v }))}
              placeholder="Ex: 4521"
              error={formErrors.busPrefix}
            />
            <View style={{ flexDirection: "row", gap: 12 }}>
              <View style={{ flex: 1 }}>
                <FormField
                  label="Hora Início"
                  value={form.startTime}
                  onChangeText={(v) => setForm((f) => ({ ...f, startTime: v }))}
                  placeholder="06:00"
                  error={formErrors.startTime}
                  keyboardType="numbers-and-punctuation"
                />
              </View>
              <View style={{ flex: 1 }}>
                <FormField
                  label="Hora Fim"
                  value={form.endTime}
                  onChangeText={(v) => setForm((f) => ({ ...f, endTime: v }))}
                  placeholder="14:00"
                  error={formErrors.endTime}
                  keyboardType="numbers-and-punctuation"
                />
              </View>
            </View>
            <FormField
              label="Observações (opcional)"
              value={form.observations}
              onChangeText={(v) => setForm((f) => ({ ...f, observations: v }))}
              placeholder="Informações adicionais..."
              multiline
              numberOfLines={3}
              style={{ minHeight: 80, textAlignVertical: "top" }}
            />

            {/* Recurring Schedule (only on create) */}
            {modalMode === "create" && (
              <View style={{ marginBottom: 16 }}>
                <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Repetir Escala</Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                  {(["none", "week", "month", "custom"] as RecurringMode[]).map((mode) => {
                    const labels: Record<RecurringMode, string> = { none: "Não repetir", week: "7 dias", month: "30 dias", custom: "Personalizado" };
                    const isActive = recurringMode === mode;
                    return (
                      <Pressable
                        key={mode}
                        style={[{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, backgroundColor: isActive ? colors.primary : colors.surface, borderColor: isActive ? colors.primary : colors.border }]}
                        onPress={() => setRecurringMode(mode)}
                      >
                        <Text style={{ fontSize: 13, fontWeight: "600", color: isActive ? "#fff" : colors.muted }}>{labels[mode]}</Text>
                      </Pressable>
                    );
                  })}
                </View>
                {recurringMode === "custom" && (
                  <View style={{ marginTop: 10, flexDirection: "row", alignItems: "center", gap: 12 }}>
                    <Text style={{ color: colors.muted, fontSize: 13 }}>Repetir por</Text>
                    <TextInput
                      style={[{ width: 64, borderWidth: 1.5, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, fontSize: 15, textAlign: "center", borderColor: colors.border, color: colors.foreground, backgroundColor: colors.background }]}
                      keyboardType="number-pad"
                      value={String(recurringDays)}
                      onChangeText={(v) => setRecurringDays(Math.max(1, Math.min(90, parseInt(v) || 1)))}
                    />
                    <Text style={{ color: colors.muted, fontSize: 13 }}>dias consecutivos</Text>
                  </View>
                )}
                {recurringMode !== "none" && (
                  <Text style={{ marginTop: 6, fontSize: 12, color: colors.primary }}>
                    {`Serão criadas ${recurringMode === "week" ? 7 : recurringMode === "month" ? 30 : recurringDays} escalas a partir de ${form.date || "a data informada"}.`}
                  </Text>
                )}
              </View>
            )}

            <Pressable
              style={[styles.saveBtn, { backgroundColor: colors.primary }]}
              onPress={handleSave}
              disabled={saving}
            >
              {saving ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.saveBtnText}>
                  {modalMode === "create"
                    ? recurringMode !== "none"
                      ? `Criar ${recurringMode === "week" ? 7 : recurringMode === "month" ? 30 : recurringDays} Escalas`
                      : "Criar Escala"
                    : "Salvar Alterações"}
                </Text>
              )}
            </Pressable>
          </ScrollView>
        </View>
      </Modal>

      {/* Driver Picker Modal */}
      <Modal
        visible={driverPickerVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setDriverPickerVisible(false)}
      >
        <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Selecionar Motorista</Text>
            <Pressable onPress={() => setDriverPickerVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          <FlatList
            data={drivers}
            keyExtractor={(d) => d.id}
            contentContainerStyle={{ padding: 16, gap: 8 }}
            ListEmptyComponent={
              <EmptyState
                icon="group-off"
                title="Nenhum motorista"
                description="Cadastre motoristas na aba Motoristas."
              />
            }
            renderItem={({ item }) => (
              <Pressable
                style={[
                  styles.driverPickerItem,
                  {
                    backgroundColor: item.id === form.driverId ? colors.primary + "15" : colors.surface,
                    borderColor: item.id === form.driverId ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => {
                  setForm((f) => ({ ...f, driverId: item.id }));
                  setDriverPickerVisible(false);
                }}
              >
                <View style={[styles.driverAvatar, { backgroundColor: colors.primary }]}>
                  <Text style={{ color: "#fff", fontWeight: "700", fontSize: 16 }}>
                    {item.name.charAt(0).toUpperCase()}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.driverName, { color: colors.foreground }]}>{item.name}</Text>
                  <Text style={[styles.driverSub, { color: colors.muted }]}>ID: {item.driverId}</Text>
                </View>
                {item.id === form.driverId && (
                  <MaterialIcons name="check-circle" size={20} color={colors.primary} />
                )}
              </Pressable>
            )}
          />
        </View>
      </Modal>

      {/* View Schedule Modal */}
      <Modal
        visible={modalVisible && modalMode === "view"}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setModalVisible(false)}
      >
        {selectedSchedule && (
          <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>Detalhes da Escala</Text>
              <Pressable onPress={() => setModalVisible(false)}>
                <MaterialIcons name="close" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
              <StatusBadge status={selectedSchedule.status} />
              <DetailRow label="Data" value={formatDate(selectedSchedule.date)} colors={colors} />
              <DetailRow label="Linha" value={selectedSchedule.line} colors={colors} />
              <DetailRow label="Motorista" value={selectedSchedule.driverName} colors={colors} />
              <DetailRow label="Modelo do Ônibus" value={selectedSchedule.busModel} colors={colors} />
              <DetailRow label="Prefixo" value={selectedSchedule.busPrefix} colors={colors} />
              <DetailRow label="Horário" value={`${selectedSchedule.startTime} — ${selectedSchedule.endTime}`} colors={colors} />
              {selectedSchedule.observations ? (
                <DetailRow label="Observações" value={selectedSchedule.observations} colors={colors} />
              ) : null}
              {selectedSchedule.confirmedAt ? (
                <DetailRow
                  label="Confirmado pelo motorista"
                  value={new Date(selectedSchedule.confirmedAt).toLocaleString("pt-BR")}
                  colors={colors}
                />
              ) : null}

              {selectedSchedule.status === "pending" && (
                <View style={{ flexDirection: "row", gap: 12, marginTop: 8 }}>
                  <Pressable
                    style={[styles.actionBtn, { backgroundColor: colors.success }]}
                    onPress={async () => {
                      await handleApprove(selectedSchedule);
                      setModalVisible(false);
                    }}
                  >
                    <MaterialIcons name="check" size={18} color="#fff" />
                    <Text style={styles.actionBtnText}>Aprovar</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.actionBtn, { backgroundColor: colors.error }]}
                    onPress={() => {
                      openDenyModal(selectedSchedule);
                    }}
                  >
                    <MaterialIcons name="close" size={18} color="#fff" />
                    <Text style={styles.actionBtnText}>Negar</Text>
                  </Pressable>
                </View>
              )}
            </ScrollView>
          </View>
        )}
      </Modal>

      {/* Confirm Delete */}
      <ConfirmModal
        visible={!!confirmDelete}
        title="Excluir Escala"
        message={`Deseja excluir a escala de ${confirmDelete?.driverName} em ${formatDate(confirmDelete?.date ?? "")}?`}
        confirmLabel="Excluir"
        destructive
        onConfirm={handleDelete}
        onCancel={() => setConfirmDelete(null)}
      />

      {/* Deny Reason Modal */}
      {denyModalVisible && denyTarget && (
        <View style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ borderTopLeftRadius: 20, borderTopRightRadius: 20, backgroundColor: colors.background, padding: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: "700", color: colors.foreground, marginBottom: 4 }}>Negar Escala</Text>
            <Text style={{ fontSize: 13, color: colors.muted, marginBottom: 16 }}>
              {`${denyTarget.driverName} — ${formatDate(denyTarget.date)}`}
            </Text>
            <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Motivo (opcional)</Text>
            <TextInput
              style={[{ borderWidth: 1.5, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, minHeight: 80, textAlignVertical: "top", borderColor: colors.border, color: colors.foreground, backgroundColor: colors.surface, marginBottom: 16 }]}
              placeholder="Ex: Motorista de folga, escala cancelada..."
              placeholderTextColor={colors.muted}
              multiline
              value={denyReason}
              onChangeText={setDenyReason}
              returnKeyType="done"
            />
            <View style={{ flexDirection: "row", gap: 12 }}>
              <Pressable
                style={[{ flex: 1, height: 48, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }]}
                onPress={() => { setDenyModalVisible(false); setDenyTarget(null); }}
              >
                <Text style={{ fontWeight: "600", color: colors.muted }}>Cancelar</Text>
              </Pressable>
              <Pressable
                style={[{ flex: 1, height: 48, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: colors.error }]}
                onPress={() => handleDeny(denyReason)}
              >
                <Text style={{ fontWeight: "700", color: "#fff" }}>Confirmar Negação</Text>
              </Pressable>
            </View>
          </View>
        </View>
      )}

      {/* Filter by Driver Modal */}
      {filterPickerVisible && (
        <View style={[{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }]}>
          <View style={[{ borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: "70%", backgroundColor: colors.background }]}>
            <View style={[{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 20, borderBottomWidth: 1, borderBottomColor: colors.border }]}>
              <Text style={[{ fontSize: 18, fontWeight: "700", color: colors.foreground }]}>Filtrar por Motorista</Text>
              <Pressable onPress={() => setFilterPickerVisible(false)}>
                <MaterialIcons name="close" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={{ padding: 12, gap: 8 }}>
              <Pressable
                style={[{ flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 12, borderWidth: 1.5, gap: 12, backgroundColor: filterDriverId === "all" ? colors.primary + "15" : colors.surface, borderColor: filterDriverId === "all" ? colors.primary : colors.border }]}
                onPress={() => { setFilterDriverId("all"); setFilterPickerVisible(false); }}
              >
                <View style={[{ width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary }]}>
                  <MaterialIcons name="group" size={18} color="#fff" />
                </View>
                <Text style={[{ flex: 1, fontSize: 15, fontWeight: "600", color: colors.foreground }]}>Todos os motoristas</Text>
                {filterDriverId === "all" && <MaterialIcons name="check-circle" size={20} color={colors.primary} />}
              </Pressable>
              {drivers.map((d) => (
                <Pressable
                  key={d.id}
                  style={[{ flexDirection: "row", alignItems: "center", padding: 14, borderRadius: 12, borderWidth: 1.5, gap: 12, backgroundColor: filterDriverId === d.id ? colors.primary + "15" : colors.surface, borderColor: filterDriverId === d.id ? colors.primary : colors.border }]}
                  onPress={() => { setFilterDriverId(d.id); setFilterPickerVisible(false); }}
                >
                  <View style={[{ width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary }]}>
                    <Text style={{ color: "#fff", fontSize: 16, fontWeight: "700" }}>{d.name.charAt(0).toUpperCase()}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[{ fontSize: 15, fontWeight: "600", color: colors.foreground }]}>{d.name}</Text>
                    <Text style={{ fontSize: 11, color: colors.muted }}>ID: {d.driverId}</Text>
                  </View>
                  {filterDriverId === d.id && <MaterialIcons name="check-circle" size={20} color={colors.primary} />}
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      )}
    </ScreenContainer>
  );
}

function SummaryCard({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: string;
}) {
  return (
    <View style={[summaryStyles.card, { borderTopColor: color }]}>
      <Text style={[summaryStyles.value, { color }]}>{value}</Text>
      <Text style={summaryStyles.label}>{label}</Text>
    </View>
  );
}

const summaryStyles = StyleSheet.create({
  card: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 10,
    borderTopWidth: 3,
    backgroundColor: "transparent",
  },
  value: {
    fontSize: 22,
    fontWeight: "800",
  },
  label: {
    fontSize: 10,
    color: "#64748B",
    marginTop: 2,
    fontWeight: "600",
  },
});

function ScheduleCard({
  schedule,
  colors,
  onView,
  onEdit,
  onApprove,
  onDeny,
  onDelete,
}: {
  schedule: Schedule;
  colors: ReturnType<typeof useColors>;
  onView: () => void;
  onEdit: () => void;
  onApprove: () => void;
  onDeny: () => void;
  onDelete: () => void;
}) {
  const typeLabel: Record<string, string> = { work: "", day_off: "FOLGA", vacation: "FÉRIAS" };
  const typeColor: Record<string, string> = { work: colors.primary, day_off: colors.warning, vacation: colors.success };
  const sType = schedule.scheduleType ?? "work";
  const borderLeftColor = typeColor[sType] ?? colors.primary;

  return (
    <Pressable
      style={[cardStyles.card, { backgroundColor: colors.surface, borderColor: colors.border, borderLeftWidth: 4, borderLeftColor }]}
      onPress={onView}
    >
      <View style={cardStyles.cardTop}>
        <View style={{ flex: 1, gap: 4 }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            <Text style={[cardStyles.driverName, { color: colors.foreground }]}>
              {schedule.driverName}
            </Text>
            {sType !== "work" && (
              <View style={{ backgroundColor: borderLeftColor + "20", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
                <Text style={{ fontSize: 10, fontWeight: "800", color: borderLeftColor }}>{typeLabel[sType]}</Text>
              </View>
            )}
          </View>
          <Text style={[cardStyles.line, { color: colors.muted }]}>
            {schedule.line}
          </Text>
          <Text style={[cardStyles.time, { color: colors.muted }]}>
            {sType === "work" ? `${schedule.startTime} — ${schedule.endTime} · Prefixo ${schedule.busPrefix}` : schedule.observations || ""}
          </Text>
        </View>
        <StatusBadge status={schedule.status} size="sm" />
      </View>
      <View style={[cardStyles.cardActions, { borderTopColor: colors.border }]}>
        {schedule.status === "pending" && (
          <>
            <ActionButton icon="check" label="Aprovar" color={colors.success} onPress={onApprove} />
            <ActionButton icon="close" label="Negar" color={colors.error} onPress={onDeny} />
          </>
        )}
        <ActionButton icon="edit" label="Editar" color={colors.primary} onPress={onEdit} />
        <ActionButton icon="delete" label="Excluir" color={colors.error} onPress={onDelete} />
      </View>
    </Pressable>
  );
}

function ActionButton({
  icon,
  label,
  color,
  onPress,
}: {
  icon: keyof typeof MaterialIcons.glyphMap;
  label: string;
  color: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [
        cardStyles.actionBtn,
        pressed && { opacity: 0.7 },
      ]}
      onPress={onPress}
    >
      <MaterialIcons name={icon} size={16} color={color} />
      <Text style={[cardStyles.actionLabel, { color }]}>{label}</Text>
    </Pressable>
  );
}

function DetailRow({
  label,
  value,
  colors,
}: {
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 2 }}>
      <Text style={{ fontSize: 12, color: colors.muted, fontWeight: "600" }}>{label}</Text>
      <Text style={{ fontSize: 15, color: colors.foreground }}>{value}</Text>
    </View>
  );
}

const cardStyles = StyleSheet.create({
  card: {
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
  },
  cardTop: {
    flexDirection: "row",
    padding: 14,
    gap: 12,
    alignItems: "flex-start",
  },
  driverName: {
    fontSize: 15,
    fontWeight: "700",
  },
  line: {
    fontSize: 13,
  },
  time: {
    fontSize: 12,
  },
  cardActions: {
    flexDirection: "row",
    borderTopWidth: 1,
    paddingHorizontal: 8,
    paddingVertical: 6,
    gap: 4,
  },
  actionBtn: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 6,
    gap: 4,
  },
  actionLabel: {
    fontSize: 12,
    fontWeight: "600",
  },
});

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  headerSub: {
    fontSize: 13,
    marginTop: 2,
  },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  dateBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  dateArrow: {
    padding: 8,
  },
  dateText: {
    fontSize: 15,
    fontWeight: "600",
  },
  summaryRow: {
    flexDirection: "row",
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  fieldLabel: {
    fontSize: 13,
    fontWeight: "600",
    marginBottom: 6,
  },
  pickerBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1.5,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  saveBtn: {
    height: 50,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 8,
  },
  saveBtnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  driverPickerItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    gap: 12,
  },
  driverAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  driverName: {
    fontSize: 15,
    fontWeight: "600",
  },
  driverSub: {
    fontSize: 12,
    marginTop: 2,
  },
  actionBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    borderRadius: 10,
    gap: 6,
  },
  actionBtnText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 14,
  },
  filterBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    gap: 8,
  },
  filterBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1.5,
    gap: 6,
  },
  filterBtnText: {
    flex: 1,
    fontSize: 13,
    fontWeight: "600",
  },
  filterClearBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
  },
});
