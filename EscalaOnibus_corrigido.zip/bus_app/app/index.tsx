import { useEffect } from "react";
import { View, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { useAuth } from "@/lib/auth-context";
import { useColors } from "@/hooks/use-colors";

export default function IndexScreen() {
  const { isLoading, isAuthenticated, user } = useAuth();
  const router = useRouter();
  const colors = useColors();

  useEffect(() => {
    if (isLoading) return;
    if (!isAuthenticated) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      router.replace("/(auth)/login" as any);
    } else if (user?.role === "admin") {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      router.replace("/(admin)" as any);
    } else if (user?.isSuspended) {
      // Driver with blocked CNH — show suspension screen
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      router.replace("/suspended" as any);
    } else {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      router.replace("/(driver)" as any);
    }
  }, [isLoading, isAuthenticated, user]);

  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );
}
