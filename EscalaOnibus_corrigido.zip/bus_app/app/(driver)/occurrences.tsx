import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Modal,
  ScrollView,
  TextInput,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { EmptyState } from "@/components/ui/empty-state";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { apiClient } from "@/lib/api-client";
import type { Occurrence, OccurrenceType } from "@/lib/database";

const OCCURRENCE_TYPES: { value: OccurrenceType; label: string; icon: keyof typeof MaterialIcons.glyphMap }[] = [
  { value: "mechanical", label: "Problema Mecânico", icon: "build" },
  { value: "accident", label: "Acidente", icon: "car-crash" },
  { value: "delay", label: "Atraso", icon: "schedule" },
  { value: "passenger", label: "Problema com Passageiro", icon: "person-off" },
  { value: "route", label: "Problema na Rota", icon: "alt-route" },
  { value: "other", label: "Outro", icon: "report" },
];

function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function DriverOccurrencesScreen() {
  const colors = useColors();
  const { user } = useAuth();

  const [occurrences, setOccurrences] = useState<Occurrence[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedType, setSelectedType] = useState<OccurrenceType | null>(null);
  const [description, setDescription] = useState("");
  const [descError, setDescError] = useState("");
  const [typeError, setTypeError] = useState("");
  const [saving, setSaving] = useState(false);
  const [typePickerVisible, setTypePickerVisible] = useState(false);

  const loadOccurrences = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const driverId = user.driverId || user.id;
      const mine = await apiClient.getOccurrencesByDriver(driverId);
      setOccurrences(mine);
    } catch (error) {
      console.error('Erro ao carregar ocorrências:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadOccurrences();
  }, [loadOccurrences]);

  function openForm() {
    setSelectedType(null);
    setDescription("");
    setDescError("");
    setTypeError("");
    setModalVisible(true);
  }

  async function handleSubmit() {
    let valid = true;
    if (!selectedType) {
      setTypeError("Selecione o tipo de ocorrência.");
      valid = false;
    } else {
      setTypeError("");
    }
    if (!description.trim() || description.trim().length < 10) {
      setDescError("Descreva a ocorrência com pelo menos 10 caracteres.");
      valid = false;
    } else {
      setDescError("");
    }
    if (!valid) return;

    setSaving(true);
    try {
      const driverId = user!.driverId || user!.id;
      await apiClient.createOccurrence({
        driverId,
        driverName: user!.name,
        type: selectedType!,
        description: description.trim(),
      });
      setModalVisible(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      loadOccurrences();
    } catch (error: any) {
      console.error('Erro ao criar ocorrência:', error);
    } finally {
      setSaving(false);
    }
  }

  const selectedTypeInfo = OCCURRENCE_TYPES.find((t) => t.value === selectedType);

  return (
    <ScreenContainer containerClassName="bg-background">
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Ocorrências</Text>
        <Pressable
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={openForm}
        >
          <MaterialIcons name="add" size={22} color="#fff" />
        </Pressable>
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={occurrences}
          keyExtractor={(item) => item.id}
          contentContainerStyle={occurrences.length === 0 ? { flex: 1 } : { padding: 16, gap: 10 }}
          ListEmptyComponent={
            <EmptyState
              icon="check-circle"
              title="Nenhuma ocorrência"
              description="Toque no botão + para reportar uma ocorrência ou problema."
            />
          }
          renderItem={({ item }) => (
            <OccurrenceCard occurrence={item} colors={colors} />
          )}
        />
      )}

      {/* Report Form Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Reportar Ocorrência</Text>
            <Pressable onPress={() => setModalVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20 }}>
            {/* Type Selector */}
            <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Tipo de Ocorrência</Text>
            <Pressable
              style={[
                styles.typePicker,
                {
                  borderColor: typeError ? colors.error : colors.border,
                  backgroundColor: colors.background,
                },
              ]}
              onPress={() => setTypePickerVisible(true)}
            >
              {selectedTypeInfo ? (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <MaterialIcons name={selectedTypeInfo.icon} size={18} color={colors.warning} />
                  <Text style={{ color: colors.foreground, fontSize: 15 }}>
                    {selectedTypeInfo.label}
                  </Text>
                </View>
              ) : (
                <Text style={{ color: colors.muted, fontSize: 15 }}>
                  Selecionar tipo...
                </Text>
              )}
              <MaterialIcons name="arrow-drop-down" size={24} color={colors.muted} />
            </Pressable>
            {typeError ? (
              <Text style={{ color: colors.error, fontSize: 12, marginTop: 4, marginBottom: 12 }}>
                {typeError}
              </Text>
            ) : (
              <View style={{ height: 16 }} />
            )}

            {/* Description */}
            <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Descrição</Text>
            <View
              style={[
                styles.textAreaWrapper,
                {
                  borderColor: descError ? colors.error : colors.border,
                  backgroundColor: colors.background,
                },
              ]}
            >
              <TextInput
                style={[styles.textArea, { color: colors.foreground }]}
                placeholder="Descreva detalhadamente o que aconteceu..."
                placeholderTextColor={colors.muted}
                value={description}
                onChangeText={setDescription}
                multiline
                numberOfLines={5}
                textAlignVertical="top"
              />
            </View>
            {descError ? (
              <Text style={{ color: colors.error, fontSize: 12, marginTop: 4 }}>{descError}</Text>
            ) : null}

            <Pressable
              style={[styles.submitBtn, { backgroundColor: colors.primary, marginTop: 24 }]}
              onPress={handleSubmit}
              disabled={saving}
            >
              {saving ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <MaterialIcons name="send" size={18} color="#fff" />
                  <Text style={styles.submitBtnText}>Enviar Ocorrência</Text>
                </>
              )}
            </Pressable>
          </ScrollView>
        </View>
      </Modal>

      {/* Type Picker Modal */}
      <Modal
        visible={typePickerVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setTypePickerVisible(false)}
      >
        <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
          <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Tipo de Ocorrência</Text>
            <Pressable onPress={() => setTypePickerVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: 16, gap: 8 }}>
            {OCCURRENCE_TYPES.map((t) => (
              <Pressable
                key={t.value}
                style={[
                  styles.typeItem,
                  {
                    backgroundColor:
                      selectedType === t.value ? colors.warning + "15" : colors.surface,
                    borderColor:
                      selectedType === t.value ? colors.warning : colors.border,
                  },
                ]}
                onPress={() => {
                  setSelectedType(t.value);
                  setTypePickerVisible(false);
                }}
              >
                <View style={[styles.typeIconBox, { backgroundColor: colors.warning + "20" }]}>
                  <MaterialIcons name={t.icon} size={22} color={colors.warning} />
                </View>
                <Text style={[styles.typeLabel, { color: colors.foreground }]}>{t.label}</Text>
                {selectedType === t.value && (
                  <MaterialIcons name="check-circle" size={20} color={colors.warning} />
                )}
              </Pressable>
            ))}
          </ScrollView>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

function OccurrenceCard({
  occurrence,
  colors,
}: {
  occurrence: Occurrence;
  colors: ReturnType<typeof useColors>;
}) {
  const typeInfo = OCCURRENCE_TYPES.find((t) => t.value === occurrence.type);
  return (
    <View
      style={[
        occStyles.card,
        { backgroundColor: colors.surface, borderColor: colors.border },
      ]}
    >
      <View style={[occStyles.iconBox, { backgroundColor: colors.warning + "20" }]}>
        <MaterialIcons name={typeInfo?.icon ?? "report"} size={22} color={colors.warning} />
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={[occStyles.type, { color: colors.foreground }]}>
          {typeInfo?.label ?? "Ocorrência"}
        </Text>
        <Text style={[occStyles.desc, { color: colors.muted }]} numberOfLines={2}>
          {occurrence.description}
        </Text>
        <Text style={[occStyles.time, { color: colors.muted }]}>
          {formatDateTime(occurrence.createdAt)}
        </Text>
      </View>
    </View>
  );
}

const occStyles = StyleSheet.create({
  card: {
    flexDirection: "row",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    gap: 12,
    alignItems: "flex-start",
  },
  iconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  type: {
    fontSize: 14,
    fontWeight: "700",
  },
  desc: {
    fontSize: 13,
    lineHeight: 18,
  },
  time: {
    fontSize: 11,
    marginTop: 2,
  },
});

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  fieldLabel: {
    fontSize: 13,
    fontWeight: "600",
    marginBottom: 6,
  },
  typePicker: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1.5,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  textAreaWrapper: {
    borderWidth: 1.5,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    minHeight: 120,
  },
  textArea: {
    fontSize: 15,
    lineHeight: 22,
    minHeight: 100,
  },
  submitBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 50,
    borderRadius: 12,
    gap: 8,
  },
  submitBtnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  typeItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    gap: 12,
  },
  typeIconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  typeLabel: {
    flex: 1,
    fontSize: 15,
    fontWeight: "600",
  },
});
