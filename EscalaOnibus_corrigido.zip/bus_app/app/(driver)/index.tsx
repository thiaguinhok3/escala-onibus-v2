import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Modal,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
  Alert,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { StatusBadge } from "@/components/ui/status-badge";
import { EmptyState } from "@/components/ui/empty-state";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { apiClient } from "@/lib/api-client";
import type { Schedule } from "@/lib/database";

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + "T12:00:00");
  d.setDate(d.getDate() + days);
  return d.toISOString().split("T")[0];
}

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function getDayName(dateStr: string): string {
  const d = new Date(dateStr + "T12:00:00");
  const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  return days[d.getDay()];
}

export default function DriverScheduleScreen() {
  const colors = useColors();
  const { user } = useAuth();

  const [weekSchedules, setWeekSchedules] = useState<Schedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Schedule | null>(null);
  const [confirming, setConfirming] = useState(false);

  const today = todayISO();
  const weekEnd = addDays(today, 6);

  const loadSchedules = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const driverId = user.driverId || user.id;
      const allSchedules = await apiClient.getSchedulesByDriver(driverId);
      // Filtrar pela semana atual
      const list = allSchedules.filter((s: any) => {
        const date = s.date?.split('T')[0] || s.date;
        return date >= today && date <= weekEnd;
      });
      setWeekSchedules(list);
    } catch (error) {
      console.error('Erro ao carregar escalas:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadSchedules();
  }, [loadSchedules]);

  const todaySchedule = weekSchedules.find((s) => s.date === today);

  async function handleConfirm(schedule: Schedule) {
    setConfirming(true);
    try {
      await apiClient.updateSchedule(schedule.id, { confirmedAt: new Date().toISOString() });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error: any) {
      Alert.alert('Erro', error?.message || 'Erro ao confirmar escala');
    } finally {
      setConfirming(false);
      setSelected(null);
      loadSchedules();
    }
  }

  return (
    <ScreenContainer containerClassName="bg-background">
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.greeting, { color: colors.muted }]}>Olá,</Text>
          <Text style={[styles.name, { color: colors.foreground }]}>{user?.name}</Text>
        </View>
        <View style={[styles.dateBadge, { backgroundColor: colors.primary + "15" }]}>
          <Text style={[styles.dateText, { color: colors.primary }]}>
            {formatDate(today)}
          </Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, gap: 16 }}>
        {/* Today's Schedule */}
        <View>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Escala de Hoje</Text>
          {loading ? (
            <ActivityIndicator color={colors.primary} style={{ marginTop: 20 }} />
          ) : todaySchedule ? (
            <TodayCard
              schedule={todaySchedule}
              colors={colors}
              onPress={() => setSelected(todaySchedule)}
            />
          ) : (
            <View style={[styles.noScheduleCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <MaterialIcons name="event-busy" size={32} color={colors.muted} />
              <Text style={[styles.noScheduleText, { color: colors.muted }]}>
                Sem escala para hoje
              </Text>
            </View>
          )}
        </View>

        {/* Week Schedule */}
        <View>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Próximos 7 dias
          </Text>
          {loading ? (
            <ActivityIndicator color={colors.primary} />
          ) : weekSchedules.length === 0 ? (
            <View style={[styles.noScheduleCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <MaterialIcons name="calendar-today" size={32} color={colors.muted} />
              <Text style={[styles.noScheduleText, { color: colors.muted }]}>
                Nenhuma escala nos próximos 7 dias
              </Text>
            </View>
          ) : (
            <View style={{ gap: 8 }}>
              {weekSchedules.map((s) => (
                <WeekCard
                  key={s.id}
                  schedule={s}
                  isToday={s.date === today}
                  colors={colors}
                  onPress={() => setSelected(s)}
                />
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Detail Modal */}
      <Modal
        visible={!!selected}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setSelected(null)}
      >
        {selected && (
          <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>
                Escala — {formatDate(selected.date)}
              </Text>
              <Pressable onPress={() => setSelected(null)}>
                <MaterialIcons name="close" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
              <StatusBadge status={selected.status} />

              <DetailRow label="Linha" value={selected.line} colors={colors} />
              <DetailRow label="Modelo do Ônibus" value={selected.busModel} colors={colors} />
              <DetailRow label="Prefixo" value={selected.busPrefix} colors={colors} />
              <DetailRow
                label="Horário"
                value={`${selected.startTime} — ${selected.endTime}`}
                colors={colors}
              />
              {selected.observations ? (
                <DetailRow label="Observações" value={selected.observations} colors={colors} />
              ) : null}
              {selected.status === "denied" && selected.denyReason ? (
                <View style={{ backgroundColor: colors.error + "12", borderRadius: 10, padding: 14, borderLeftWidth: 3, borderLeftColor: colors.error, gap: 4 }}>
                  <Text style={{ fontSize: 12, fontWeight: "700", color: colors.error, textTransform: "uppercase", letterSpacing: 0.5 }}>Motivo da Negação</Text>
                  <Text style={{ fontSize: 14, color: colors.foreground, lineHeight: 20 }}>{selected.denyReason}</Text>
                </View>
              ) : selected.status === "denied" ? (
                <View style={{ backgroundColor: colors.error + "12", borderRadius: 10, padding: 14, borderLeftWidth: 3, borderLeftColor: colors.error }}>
                  <Text style={{ fontSize: 13, color: colors.muted }}>Nenhum motivo informado pelo administrador.</Text>
                </View>
              ) : null}
              {selected.confirmedAt ? (
                <View
                  style={[
                    styles.confirmedBox,
                    { backgroundColor: colors.success + "15", borderColor: colors.success },
                  ]}
                >
                  <MaterialIcons name="check-circle" size={18} color={colors.success} />
                  <Text style={[styles.confirmedText, { color: colors.success }]}>
                    Visualização confirmada em{" "}
                    {new Date(selected.confirmedAt).toLocaleString("pt-BR")}
                  </Text>
                </View>
              ) : selected.status === "approved" ? (
                <Pressable
                  style={[styles.confirmBtn, { backgroundColor: colors.success }]}
                  onPress={() => handleConfirm(selected)}
                  disabled={confirming}
                >
                  {confirming ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <>
                      <MaterialIcons name="check" size={18} color="#fff" />
                      <Text style={styles.confirmBtnText}>Confirmar Visualização</Text>
                    </>
                  )}
                </Pressable>
              ) : null}
            </ScrollView>
          </View>
        )}
      </Modal>
    </ScreenContainer>
  );
}

function TodayCard({
  schedule,
  colors,
  onPress,
}: {
  schedule: Schedule;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [
        todayStyles.card,
        { backgroundColor: colors.primary, opacity: pressed ? 0.9 : 1 },
      ]}
      onPress={onPress}
    >
      <View style={todayStyles.topRow}>
        <View style={{ flex: 1 }}>
          <Text style={todayStyles.line}>{schedule.line}</Text>
          <Text style={todayStyles.time}>
            {schedule.startTime} — {schedule.endTime}
          </Text>
        </View>
        <View style={[todayStyles.statusBox, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
          <StatusBadge status={schedule.status} />
        </View>
      </View>
      <View style={todayStyles.bottomRow}>
        <View style={todayStyles.infoItem}>
          <MaterialIcons name="directions-bus" size={14} color="rgba(255,255,255,0.8)" />
          <Text style={todayStyles.infoText}>{schedule.busModel}</Text>
        </View>
        <View style={todayStyles.infoItem}>
          <MaterialIcons name="tag" size={14} color="rgba(255,255,255,0.8)" />
          <Text style={todayStyles.infoText}>Prefixo {schedule.busPrefix}</Text>
        </View>
        {schedule.confirmedAt && (
          <View style={todayStyles.infoItem}>
            <MaterialIcons name="check-circle" size={14} color="rgba(255,255,255,0.8)" />
            <Text style={todayStyles.infoText}>Confirmada</Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

function WeekCard({
  schedule,
  isToday,
  colors,
  onPress,
}: {
  schedule: Schedule;
  isToday: boolean;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [
        weekStyles.card,
        {
          backgroundColor: colors.surface,
          borderColor: isToday ? colors.primary : colors.border,
          borderLeftWidth: isToday ? 4 : 1,
          opacity: pressed ? 0.85 : 1,
        },
      ]}
      onPress={onPress}
    >
      <View style={weekStyles.dateCol}>
        <Text style={[weekStyles.dayName, { color: isToday ? colors.primary : colors.muted }]}>
          {getDayName(schedule.date)}
        </Text>
        <Text style={[weekStyles.dayNum, { color: isToday ? colors.primary : colors.foreground }]}>
          {schedule.date.split("-")[2]}
        </Text>
      </View>
      <View style={weekStyles.content}>
        <Text style={[weekStyles.line, { color: colors.foreground }]} numberOfLines={1}>
          {schedule.line}
        </Text>
        <Text style={[weekStyles.time, { color: colors.muted }]}>
          {schedule.startTime} — {schedule.endTime}
        </Text>
      </View>
      <StatusBadge status={schedule.status} size="sm" />
    </Pressable>
  );
}

function DetailRow({
  label,
  value,
  colors,
}: {
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 2 }}>
      <Text style={{ fontSize: 12, color: colors.muted, fontWeight: "600" }}>{label}</Text>
      <Text style={{ fontSize: 15, color: colors.foreground }}>{value}</Text>
    </View>
  );
}

const todayStyles = StyleSheet.create({
  card: {
    borderRadius: 16,
    padding: 16,
    gap: 12,
  },
  topRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
  },
  line: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "800",
  },
  time: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 14,
    marginTop: 2,
  },
  statusBox: {
    borderRadius: 8,
    padding: 4,
  },
  bottomRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  infoItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  infoText: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 12,
  },
});

const weekStyles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    gap: 12,
  },
  dateCol: {
    width: 40,
    alignItems: "center",
  },
  dayName: {
    fontSize: 11,
    fontWeight: "600",
  },
  dayNum: {
    fontSize: 20,
    fontWeight: "800",
  },
  content: {
    flex: 1,
    gap: 2,
  },
  line: {
    fontSize: 14,
    fontWeight: "600",
  },
  time: {
    fontSize: 12,
  },
});

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  greeting: {
    fontSize: 13,
  },
  name: {
    fontSize: 20,
    fontWeight: "800",
  },
  dateBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  dateText: {
    fontSize: 13,
    fontWeight: "700",
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 10,
  },
  noScheduleCard: {
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    borderRadius: 12,
    borderWidth: 1,
    gap: 8,
  },
  noScheduleText: {
    fontSize: 14,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  confirmedBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  confirmedText: {
    fontSize: 13,
    fontWeight: "600",
    flex: 1,
  },
  confirmBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 50,
    borderRadius: 12,
    gap: 8,
    marginTop: 8,
  },
  confirmBtnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
});
