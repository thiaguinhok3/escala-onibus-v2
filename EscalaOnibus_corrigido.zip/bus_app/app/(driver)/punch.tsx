"use client";
import { useState, useCallback, useEffect, useRef } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  StyleSheet,
  Alert,
  TextInput,
  Modal,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import * as ImagePicker from "expo-image-picker";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";
import { db, type PunchRecord, type PunchType, type WorkdayPunches, type Schedule } from "@/lib/database";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function formatTime(isoStr: string): string {
  const d = new Date(isoStr);
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function calcDuration(startISO: string, endISO: string): string {
  const ms = new Date(endISO).getTime() - new Date(startISO).getTime();
  if (ms < 0) return "--";
  const totalMin = Math.floor(ms / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return `${h}h ${String(m).padStart(2, "0")}min`;
}

function calcWorkDuration(wp: WorkdayPunches): string {
  if (!wp.start) return "--";
  const endTime = wp.end?.timestamp ?? new Date().toISOString();
  const totalMs = new Date(endTime).getTime() - new Date(wp.start.timestamp).getTime();
  let breakMs = 0;
  if (wp.breakStart && wp.breakEnd) {
    breakMs = new Date(wp.breakEnd.timestamp).getTime() - new Date(wp.breakStart.timestamp).getTime();
  }
  const workMs = Math.max(0, totalMs - breakMs);
  const totalMin = Math.floor(workMs / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return `${h}h ${String(m).padStart(2, "0")}min`;
}

// ─── Clock Component ──────────────────────────────────────────────────────────

function LiveClock({ color }: { color: string }) {
  const [time, setTime] = useState(new Date());
  const ref = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    ref.current = setInterval(() => setTime(new Date()), 1000);
    return () => { if (ref.current) clearInterval(ref.current); };
  }, []);

  return (
    <Text style={[clockStyles.time, { color }]}>
      {time.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
    </Text>
  );
}

const clockStyles = StyleSheet.create({
  time: { fontSize: 42, fontWeight: "800", letterSpacing: 2, fontVariant: ["tabular-nums"] },
});

// ─── Punch Button ─────────────────────────────────────────────────────────────

function PunchButton({
  label,
  sublabel,
  icon,
  color,
  done,
  doneTime,
  disabled,
  onPress,
}: {
  label: string;
  sublabel: string;
  icon: keyof typeof MaterialIcons.glyphMap;
  color: string;
  done: boolean;
  doneTime?: string;
  disabled: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [
        btnStyles.btn,
        { borderColor: done ? color : "#E2E8F0", backgroundColor: done ? color + "10" : "#F8FAFC" },
        disabled && !done && { opacity: 0.4 },
        pressed && !disabled && { transform: [{ scale: 0.97 }] },
      ]}
      onPress={onPress}
      disabled={disabled}
    >
      <View style={[btnStyles.iconBox, { backgroundColor: done ? color : "#CBD5E1" }]}>
        <MaterialIcons name={done ? "check" : icon} size={22} color="#fff" />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[btnStyles.label, { color: done ? color : "#334155" }]}>{label}</Text>
        <Text style={[btnStyles.sublabel, { color: done ? color + "BB" : "#94A3B8" }]}>
          {done && doneTime ? `Registrado às ${doneTime}` : sublabel}
        </Text>
      </View>
      {!done && !disabled && (
        <View style={[btnStyles.tapBadge, { backgroundColor: color }]}>
          <Text style={btnStyles.tapText}>BATER</Text>
        </View>
      )}
    </Pressable>
  );
}

const btnStyles = StyleSheet.create({
  btn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    padding: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    marginBottom: 12,
  },
  iconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  label: { fontSize: 15, fontWeight: "700" },
  sublabel: { fontSize: 12, marginTop: 2 },
  tapBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  tapText: { fontSize: 10, fontWeight: "800", color: "#fff", letterSpacing: 0.5 },
});

// ─── History Card ─────────────────────────────────────────────────────────────

function HistoryCard({
  wp,
  colors,
  onPress,
}: {
  wp: WorkdayPunches;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  const isComplete = !!wp.end;
  return (
    <Pressable
      style={[hStyles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
      onPress={onPress}
    >
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>{formatDate(wp.date)}</Text>
        <View style={[hStyles.badge, { backgroundColor: isComplete ? colors.success + "20" : colors.warning + "20" }]}>
          <Text style={{ fontSize: 11, fontWeight: "700", color: isComplete ? colors.success : colors.warning }}>
            {isComplete ? "Completo" : "Em andamento"}
          </Text>
        </View>
      </View>
      <View style={{ flexDirection: "row", gap: 16, marginTop: 8 }}>
        {wp.start && (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <MaterialIcons name="login" size={13} color={colors.success} />
            <Text style={{ fontSize: 12, color: colors.muted }}>{formatTime(wp.start.timestamp)}</Text>
          </View>
        )}
        {wp.end && (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <MaterialIcons name="logout" size={13} color={colors.error} />
            <Text style={{ fontSize: 12, color: colors.muted }}>{formatTime(wp.end.timestamp)}</Text>
          </View>
        )}
        {wp.start && (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <MaterialIcons name="timer" size={13} color={colors.primary} />
            <Text style={{ fontSize: 12, color: colors.muted }}>{calcWorkDuration(wp)}</Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

const hStyles = StyleSheet.create({
  card: { borderRadius: 12, padding: 14, borderWidth: 1, marginBottom: 10 },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function DriverPunchScreen() {
  const colors = useColors();
  const { user } = useAuth();

  const [today] = useState(todayISO());
  const [workday, setWorkday] = useState<WorkdayPunches | null>(null);
  const [todaySchedule, setTodaySchedule] = useState<Schedule | null>(null);
  const [loading, setLoading] = useState(true);
  const [punching, setPunching] = useState(false);
  const [history, setHistory] = useState<WorkdayPunches[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [noteModalVisible, setNoteModalVisible] = useState(false);
  const [pendingPunchType, setPendingPunchType] = useState<PunchType | null>(null);
  const [note, setNote] = useState("");
  const [selectedWP, setSelectedWP] = useState<WorkdayPunches | null>(null);
  const [detailVisible, setDetailVisible] = useState(false);

  const loadData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const [wp, schedules, allPunches] = await Promise.all([
      db.getWorkdayPunches(user.id, today),
      db.getSchedulesByDriver(user.id),
      db.getPunchesByDriver(user.id),
    ]);
    setWorkday(wp);

    // Today's schedule
    const ts = schedules.find((s) => s.date === today && s.status === "approved");
    setTodaySchedule(ts ?? null);

    // Build history (last 14 days, excluding today)
    const dates = new Set(allPunches.map((p) => p.timestamp.split("T")[0]));
    const pastDates = [...dates].filter((d) => d < today).sort().reverse().slice(0, 14);
    const wps = await Promise.all(pastDates.map((d) => db.getWorkdayPunches(user.id, d)));
    setHistory(wps.filter((w) => w.start));
    setLoading(false);
  }, [user, today]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function requestPunch(type: PunchType) {
    setPendingPunchType(type);
    setNote("");
    setNoteModalVisible(true);
  }

  async function takePhotoAndShare() {
    if (Platform.OS === "web") {
      Alert.alert("Indisponível", "Captura de foto não está disponível na versão web.");
      return;
    }

    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permissão necessária", "Permita o acesso à câmera para registrar o ponto com foto.");
      return;
    }

    try {
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: false,
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const photoUri = result.assets[0].uri;
        
        // Check if sharing is available
        const isAvailable = await Sharing.isAvailableAsync();
        if (isAvailable) {
          await Sharing.shareAsync(photoUri, {
            mimeType: "image/jpeg",
            dialogTitle: "Compartilhar foto do ponto",
            UTI: "com.apple.mail-message",
          });
          
          // After sharing, register the punch
          await confirmPunch();
        } else {
          Alert.alert("Erro", "Compartilhamento não disponível neste dispositivo.");
        }
      }
    } catch (error) {
      Alert.alert("Erro", "Não foi possível capturar a foto. Tente novamente.");
    }
  }

  async function confirmPunch() {
    if (!user || !pendingPunchType) return;

    setPunching(true);
    setNoteModalVisible(false);

    try {
      await db.createPunch({
        driverId: user.id,
        driverName: user.name,
        scheduleId: todaySchedule?.id,
        type: pendingPunchType,
        timestamp: new Date().toISOString(),
        note: note || undefined,
      });

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setPendingPunchType(null);
      setNote("");
      await loadData();
    } catch (error) {
      Alert.alert("Erro", "Não foi possível registrar o ponto. Tente novamente.");
    } finally {
      setPunching(false);
    }
  }

  const canPunch = (type: PunchType): boolean => {
    if (!workday) return type === "start";
    if (type === "start") return !workday.start;
    if (type === "break_start") return !!workday.start && !workday.breakStart;
    if (type === "break_end") return !!workday.breakStart && !workday.breakEnd;
    if (type === "end") return !!workday.start && !workday.end;
    return false;
  };

  if (loading) {
    return (
      <ScreenContainer>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView contentContainerStyle={{ padding: 20, gap: 20 }}>
        {/* Today's Schedule Card */}
        {todaySchedule ? (
          <View style={[styles.scheduleCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
              <View>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.muted }}>ESCALA DE HOJE</Text>
                <Text style={{ fontSize: 16, fontWeight: "800", color: colors.foreground, marginTop: 4 }}>
                  Linha {todaySchedule.line}
                </Text>
                <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4 }}>
                  {todaySchedule.startTime} – {todaySchedule.endTime}
                </Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: colors.success + "20" }]}>
                <MaterialIcons name="check-circle" size={16} color={colors.success} />
                <Text style={{ fontSize: 11, fontWeight: "700", color: colors.success }}>Aprovada</Text>
              </View>
            </View>
          </View>
        ) : (
          <View style={[styles.noScheduleCard, { backgroundColor: colors.warning + "10", borderColor: colors.warning }]}>
            <MaterialIcons name="info" size={20} color={colors.warning} />
            <Text style={{ fontSize: 13, fontWeight: "600", color: colors.warning }}>Nenhuma escala aprovada para hoje</Text>
          </View>
        )}

        {/* Live Clock */}
        <View style={{ alignItems: "center", gap: 8 }}>
          <LiveClock color={colors.primary} />
          <Text style={{ fontSize: 13, color: colors.muted }}>Hora atual</Text>
        </View>

        {/* Punch Buttons */}
        <View>
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>Registrar Ponto</Text>
          <PunchButton
            label="Início de Serviço"
            sublabel="Toque para registrar entrada"
            icon="login"
            color={colors.success}
            done={!!workday?.start}
            doneTime={workday?.start ? formatTime(workday.start.timestamp) : undefined}
            disabled={!canPunch("start")}
            onPress={() => requestPunch("start")}
          />
          <PunchButton
            label="Pausa (Almoço/Janta)"
            sublabel="Toque para registrar pausa"
            icon="restaurant"
            color={colors.warning}
            done={!!workday?.breakStart}
            doneTime={workday?.breakStart ? formatTime(workday.breakStart.timestamp) : undefined}
            disabled={!canPunch("break_start")}
            onPress={() => requestPunch("break_start")}
          />
          <PunchButton
            label="Retorno da Pausa"
            sublabel="Toque para registrar retorno"
            icon="check-circle"
            color={colors.primary}
            done={!!workday?.breakEnd}
            doneTime={workday?.breakEnd ? formatTime(workday.breakEnd.timestamp) : undefined}
            disabled={!canPunch("break_end")}
            onPress={() => requestPunch("break_end")}
          />
          <PunchButton
            label="Término de Trabalho"
            sublabel="Toque para registrar saída"
            icon="logout"
            color={colors.error}
            done={!!workday?.end}
            doneTime={workday?.end ? formatTime(workday.end.timestamp) : undefined}
            disabled={!canPunch("end")}
            onPress={() => requestPunch("end")}
          />
        </View>

        {/* Work Summary */}
        {workday?.start && (
          <View style={[styles.summaryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>Resumo do Dia</Text>
            <View style={{ gap: 10, marginTop: 12 }}>
              <SummaryRow label="Jornada" value={calcWorkDuration(workday)} colors={colors} />
              {workday.breakStart && workday.breakEnd && (
                <SummaryRow label="Pausa" value={calcDuration(workday.breakStart.timestamp, workday.breakEnd.timestamp)} colors={colors} />
              )}
            </View>
          </View>
        )}

        {/* History */}
        <View>
          <Pressable
            style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}
            onPress={() => setShowHistory(!showHistory)}
          >
            <Text style={[styles.sectionLabel, { color: colors.foreground, margin: 0 }]}>Histórico (Últimos 14 dias)</Text>
            <MaterialIcons name={showHistory ? "expand-less" : "expand-more"} size={24} color={colors.muted} />
          </Pressable>
          {showHistory && (
            <View>
              {history.length > 0 ? (
                history.map((wp) => (
                  <HistoryCard
                    key={wp.date}
                    wp={wp}
                    colors={colors}
                    onPress={() => { setSelectedWP(wp); setDetailVisible(true); }}
                  />
                ))
              ) : (
                <Text style={{ fontSize: 13, color: colors.muted, textAlign: "center", paddingVertical: 20 }}>
                  Nenhum registro anterior
                </Text>
              )}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Note & Photo Modal */}
      <Modal
        visible={noteModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setNoteModalVisible(false)}
      >
        <View style={{ flex: 1, backgroundColor: colors.background }}>
          <View style={[styles.modalHeader, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
            <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>
              {pendingPunchType === "start" ? "Início de Serviço" : pendingPunchType === "break_start" ? "Pausa" : pendingPunchType === "break_end" ? "Retorno" : "Término"}
            </Text>
            <Pressable onPress={() => setNoteModalVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>

          <ScrollView contentContainerStyle={{ padding: 20, gap: 20 }}>
            {/* Observation Field */}
            <View>
              <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>Observações (Opcional)</Text>
              <TextInput
                style={[styles.noteInput, { backgroundColor: colors.surface, color: colors.foreground, borderColor: colors.border }]}
                placeholder="Digite qualquer observação..."
                placeholderTextColor={colors.muted}
                value={note}
                onChangeText={setNote}
                multiline
                numberOfLines={4}
              />
            </View>

            {/* Photo Section */}
            <View>
              <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground, marginBottom: 8 }}>
                📸 Foto Obrigatória
              </Text>
              <Text style={{ fontSize: 12, color: colors.muted, marginBottom: 12 }}>
                Tire uma foto e compartilhe via WhatsApp, Email ou outro aplicativo para registrar o ponto.
              </Text>
              <Pressable
                style={[styles.photoBtn, { backgroundColor: colors.primary, borderColor: colors.primary }]}
                onPress={takePhotoAndShare}
                disabled={punching}
              >
                {punching ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <MaterialIcons name="camera-alt" size={28} color="#fff" />
                    <Text style={{ fontSize: 14, fontWeight: "700", color: "#fff", marginTop: 8 }}>
                      Tirar Foto e Compartilhar
                    </Text>
                  </>
                )}
              </Pressable>
            </View>

            {/* Info */}
            <View style={[styles.infoBox, { backgroundColor: colors.primary + "10", borderColor: colors.primary }]}>
              <MaterialIcons name="info" size={16} color={colors.primary} />
              <Text style={{ flex: 1, fontSize: 12, color: colors.primary, marginLeft: 8 }}>
                A foto será compartilhada via WhatsApp, Email ou outro aplicativo de sua escolha. Após compartilhar, o ponto será registrado automaticamente.
              </Text>
            </View>

            {/* Confirm Button */}
            <Pressable
              style={[styles.confirmBtn, { backgroundColor: punching ? colors.muted : colors.success }]}
              onPress={confirmPunch}
              disabled={punching}
            >
              {punching ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={{ fontSize: 16, fontWeight: "700", color: "#fff" }}>Registrar Ponto</Text>
              )}
            </Pressable>
          </ScrollView>
        </View>
      </Modal>

      {/* Detail Modal */}
      <Modal visible={detailVisible} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setDetailVisible(false)}>
        <View style={{ flex: 1, backgroundColor: colors.background }}>
          <View style={[styles.modalHeader, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
            <Text style={{ fontSize: 18, fontWeight: "800", color: colors.foreground }}>Detalhes do Dia</Text>
            <Pressable onPress={() => setDetailVisible(false)}>
              <MaterialIcons name="close" size={24} color={colors.muted} />
            </Pressable>
          </View>
          {selectedWP && (
            <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
              <DetailRow label="Data" value={formatDate(selectedWP.date)} colors={colors} />
              {selectedWP.start && <DetailRow label="Início" value={formatTime(selectedWP.start.timestamp)} colors={colors} />}
              {selectedWP.breakStart && <DetailRow label="Pausa" value={formatTime(selectedWP.breakStart.timestamp)} colors={colors} />}
              {selectedWP.breakEnd && <DetailRow label="Retorno" value={formatTime(selectedWP.breakEnd.timestamp)} colors={colors} />}
              {selectedWP.end && <DetailRow label="Término" value={formatTime(selectedWP.end.timestamp)} colors={colors} />}
              <DetailRow label="Jornada Total" value={calcWorkDuration(selectedWP)} colors={colors} />
            </ScrollView>
          )}
        </View>
      </Modal>
    </ScreenContainer>
  );
}

function SummaryRow({ label, value, colors }: { label: string; value: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
      <Text style={{ fontSize: 13, color: colors.muted }}>{label}</Text>
      <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground }}>{value}</Text>
    </View>
  );
}

function DetailRow({ label, value, colors }: { label: string; value: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between", paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border }}>
      <Text style={{ fontSize: 14, color: colors.muted }}>{label}</Text>
      <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  scheduleCard: { borderRadius: 14, padding: 16, borderWidth: 1 },
  noScheduleCard: { borderRadius: 14, padding: 16, borderWidth: 1.5, flexDirection: "row", alignItems: "center", gap: 12 },
  statusBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  sectionLabel: { fontSize: 14, fontWeight: "700", marginBottom: 12 },
  summaryCard: { borderRadius: 14, padding: 16, borderWidth: 1 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20, borderBottomWidth: 1 },
  noteInput: { borderRadius: 12, borderWidth: 1.5, padding: 14, fontSize: 14, textAlignVertical: "top" },
  photoBtn: { borderRadius: 14, borderWidth: 1.5, padding: 24, alignItems: "center", justifyContent: "center" },
  infoBox: { borderRadius: 12, borderWidth: 1, padding: 12, flexDirection: "row", alignItems: "flex-start" },
  confirmBtn: { borderRadius: 14, padding: 16, alignItems: "center", marginBottom: 20 },
});
