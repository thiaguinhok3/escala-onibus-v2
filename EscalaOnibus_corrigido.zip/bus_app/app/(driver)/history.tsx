import React, { useState, useCallback, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Modal,
  ScrollView,
  ActivityIndicator,
  StyleSheet,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { StatusBadge } from "@/components/ui/status-badge";
import { EmptyState } from "@/components/ui/empty-state";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { apiClient } from "@/lib/api-client";
import type { Schedule } from "@/lib/database";

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function getDayName(dateStr: string): string {
  const d = new Date(dateStr + "T12:00:00");
  const days = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  return days[d.getDay()];
}

function todayISO(): string {
  return new Date().toISOString().split("T")[0];
}

export default function DriverHistoryScreen() {
  const colors = useColors();
  const { user } = useAuth();

  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Schedule | null>(null);

  const loadHistory = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const driverId = user.driverId || user.id;
      const all = await apiClient.getSchedulesByDriver(driverId);
      const today = todayISO();
      const past = all.filter((s: any) => {
        const date = s.date?.split('T')[0] || s.date;
        return date < today;
      });
      setSchedules(past);
    } catch (error) {
      console.error('Erro ao carregar histórico:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  return (
    <ScreenContainer containerClassName="bg-background">
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Histórico</Text>
        <Text style={[styles.headerSub, { color: colors.muted }]}>
          {schedules.length} escala{schedules.length !== 1 ? "s" : ""} anteriores
        </Text>
      </View>

      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : (
        <FlatList
          data={schedules}
          keyExtractor={(item) => item.id}
          contentContainerStyle={schedules.length === 0 ? { flex: 1 } : { padding: 16, gap: 10 }}
          ListEmptyComponent={
            <EmptyState
              icon="history"
              title="Nenhum histórico"
              description="Suas escalas anteriores aparecerão aqui."
            />
          }
          renderItem={({ item }) => (
            <HistoryCard
              schedule={item}
              colors={colors}
              onPress={() => setSelected(item)}
            />
          )}
        />
      )}

      {/* Detail Modal */}
      <Modal
        visible={!!selected}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setSelected(null)}
      >
        {selected && (
          <View style={[styles.modalContainer, { backgroundColor: colors.background }]}>
            <View style={[styles.modalHeader, { borderBottomColor: colors.border }]}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>
                {getDayName(selected.date)}, {formatDate(selected.date)}
              </Text>
              <Pressable onPress={() => setSelected(null)}>
                <MaterialIcons name="close" size={24} color={colors.muted} />
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
              <StatusBadge status={selected.status} />
              <DetailRow label="Linha" value={selected.line} colors={colors} />
              <DetailRow label="Modelo do Ônibus" value={selected.busModel} colors={colors} />
              <DetailRow label="Prefixo" value={selected.busPrefix} colors={colors} />
              <DetailRow
                label="Horário"
                value={`${selected.startTime} — ${selected.endTime}`}
                colors={colors}
              />
              {selected.observations ? (
                <DetailRow label="Observações" value={selected.observations} colors={colors} />
              ) : null}
              {selected.status === "denied" && selected.denyReason ? (
                <View style={{ backgroundColor: colors.error + "12", borderRadius: 10, padding: 14, borderLeftWidth: 3, borderLeftColor: colors.error, gap: 4 }}>
                  <Text style={{ fontSize: 12, fontWeight: "700", color: colors.error, textTransform: "uppercase", letterSpacing: 0.5 }}>Motivo da Negação</Text>
                  <Text style={{ fontSize: 14, color: colors.foreground, lineHeight: 20 }}>{selected.denyReason}</Text>
                </View>
              ) : selected.status === "denied" ? (
                <View style={{ backgroundColor: colors.error + "12", borderRadius: 10, padding: 14, borderLeftWidth: 3, borderLeftColor: colors.error }}>
                  <Text style={{ fontSize: 13, color: colors.muted }}>Nenhum motivo informado pelo administrador.</Text>
                </View>
              ) : null}
              {selected.confirmedAt ? (
                <View
                  style={[
                    styles.confirmedBox,
                    { backgroundColor: colors.success + "15", borderColor: colors.success },
                  ]}
                >
                  <MaterialIcons name="check-circle" size={18} color={colors.success} />
                  <Text style={[styles.confirmedText, { color: colors.success }]}>
                    Visualização confirmada em{" "}
                    {new Date(selected.confirmedAt).toLocaleString("pt-BR")}
                  </Text>
                </View>
              ) : null}
            </ScrollView>
          </View>
        )}
      </Modal>
    </ScreenContainer>
  );
}

function HistoryCard({
  schedule,
  colors,
  onPress,
}: {
  schedule: Schedule;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [
        cardStyles.card,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          opacity: pressed ? 0.85 : 1,
        },
      ]}
      onPress={onPress}
    >
      <View style={cardStyles.dateCol}>
        <Text style={[cardStyles.dayName, { color: colors.muted }]}>
          {getDayName(schedule.date).slice(0, 3)}
        </Text>
        <Text style={[cardStyles.dayNum, { color: colors.foreground }]}>
          {schedule.date.split("-")[2]}
        </Text>
        <Text style={[cardStyles.month, { color: colors.muted }]}>
          {schedule.date.split("-")[1]}/{schedule.date.split("-")[0].slice(2)}
        </Text>
      </View>
      <View style={cardStyles.content}>
        <Text style={[cardStyles.line, { color: colors.foreground }]} numberOfLines={1}>
          {schedule.line}
        </Text>
        <Text style={[cardStyles.time, { color: colors.muted }]}>
          {schedule.startTime} — {schedule.endTime} · {schedule.busPrefix}
        </Text>
        {schedule.confirmedAt && (
          <View style={cardStyles.confirmedRow}>
            <MaterialIcons name="check-circle" size={12} color={colors.success} />
            <Text style={[cardStyles.confirmedText, { color: colors.success }]}>Confirmada</Text>
          </View>
        )}
      </View>
      <StatusBadge status={schedule.status} size="sm" />
    </Pressable>
  );
}

function DetailRow({
  label,
  value,
  colors,
}: {
  label: string;
  value: string;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 2 }}>
      <Text style={{ fontSize: 12, color: colors.muted, fontWeight: "600" }}>{label}</Text>
      <Text style={{ fontSize: 15, color: colors.foreground }}>{value}</Text>
    </View>
  );
}

const cardStyles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    gap: 12,
  },
  dateCol: {
    width: 44,
    alignItems: "center",
  },
  dayName: {
    fontSize: 10,
    fontWeight: "600",
  },
  dayNum: {
    fontSize: 22,
    fontWeight: "800",
  },
  month: {
    fontSize: 10,
  },
  content: {
    flex: 1,
    gap: 2,
  },
  line: {
    fontSize: 14,
    fontWeight: "600",
  },
  time: {
    fontSize: 12,
  },
  confirmedRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 2,
  },
  confirmedText: {
    fontSize: 11,
    fontWeight: "600",
  },
});

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
  },
  headerSub: {
    fontSize: 13,
    marginTop: 2,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  confirmedBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  confirmedText: {
    fontSize: 13,
    fontWeight: "600",
    flex: 1,
  },
});
