import { useEffect, useState, useRef } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Image,
  Alert,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { db, type CNHRecord, type Schedule } from "@/lib/database";

function formatDate(d: string) {
  if (!d) return "";
  const [y, m, day] = d.split("-");
  return `${day}/${m}/${y}`;
}

function todayISO() {
  return new Date().toISOString().split("T")[0];
}

function getStatusColor(status: string, colors: ReturnType<typeof useColors>) {
  if (status === "active") return colors.success;
  if (status === "suspended") return colors.warning;
  return colors.error;
}

function getStatusLabel(status: string) {
  if (status === "active") return "ATIVA";
  if (status === "suspended") return "SUSPENSA";
  return "BLOQUEADA";
}

export default function DriverBadgeScreen() {
  const colors = useColors();
  const { user, refreshUser } = useAuth();
  const [cnh, setCnh] = useState<CNHRecord | null>(null);
  const [todaySchedule, setTodaySchedule] = useState<Schedule | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      const cnhData = await db.getCNHByDriver(user.id);
      setCnh(cnhData);
      const schedules = await db.getSchedulesByDate(todayISO());
      const mine = schedules.find((s) => s.driverId === user.id && s.scheduleType !== "day_off" && s.scheduleType !== "vacation") ?? null;
      setTodaySchedule(mine);
      setLoading(false);
    };
    load();
  }, [user]);

  const handleChangePhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permissão necessária", "Permita o acesso à galeria para escolher uma foto.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.6,
      base64: false,
    });
    if (!result.canceled && result.assets[0]) {
      await db.updateUser(user!.id, { photoUri: result.assets[0].uri });
      await refreshUser();
    }
  };

  const handleTakePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permissão necessária", "Permita o acesso à câmera para tirar uma foto.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.6,
    });
    if (!result.canceled && result.assets[0]) {
      await db.updateUser(user!.id, { photoUri: result.assets[0].uri });
      await refreshUser();
    }
  };

  if (loading || !user) {
    return (
      <ScreenContainer>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      </ScreenContainer>
    );
  }

  const cnhPoints = cnh ? cnh.totalPoints - cnh.usedPoints : null;
  const cnhPct = cnh ? Math.max(0, (cnhPoints! / cnh.totalPoints) * 100) : 0;

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Meu Crachá</Text>
          <Text style={[styles.headerSub, { color: colors.muted }]}>Identificação digital</Text>
        </View>
        <MaterialIcons name="badge" size={28} color={colors.primary} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
        {/* ── BADGE CARD ── */}
        <View style={[styles.badgeCard, { backgroundColor: colors.primary }]}>
          {/* Company header */}
          <View style={styles.badgeHeader}>
            <MaterialIcons name="directions-bus" size={22} color="rgba(255,255,255,0.9)" />
            <Text style={styles.badgeCompany}>EscalaOnibus</Text>
            <Text style={styles.badgeRole}>MOTORISTA</Text>
          </View>

          {/* Photo + Name */}
          <View style={styles.badgeBody}>
            <Pressable onPress={handleTakePhoto} style={styles.photoWrap}>
              {user.photoUri ? (
                <Image source={{ uri: user.photoUri }} style={styles.photo} />
              ) : (
                <View style={[styles.photoPlaceholder, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
                  <Text style={{ fontSize: 36, fontWeight: "800", color: "#fff" }}>
                    {user.name.charAt(0).toUpperCase()}
                  </Text>
                </View>
              )}
              <View style={styles.cameraOverlay}>
                <MaterialIcons name="camera-alt" size={14} color="#fff" />
              </View>
            </Pressable>

            <View style={styles.badgeInfo}>
              <Text style={styles.badgeName}>{user.name}</Text>
              <Text style={styles.badgeId}>ID: {user.driverId ?? "—"}</Text>
              {user.whatsapp && (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 }}>
                  <MaterialIcons name="phone" size={12} color="rgba(255,255,255,0.7)" />
                  <Text style={styles.badgeContact}>{user.whatsapp}</Text>
                </View>
              )}
            </View>
          </View>

          {/* Today's schedule */}
          {todaySchedule && (
            <View style={styles.badgeSchedule}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                <MaterialIcons name="directions-bus" size={14} color="rgba(255,255,255,0.8)" />
                <Text style={styles.badgeScheduleText}>Linha {todaySchedule.line} · {todaySchedule.startTime}–{todaySchedule.endTime}</Text>
              </View>
              <View style={[styles.statusDot, { backgroundColor: todaySchedule.status === "approved" ? colors.success : todaySchedule.status === "denied" ? colors.error : colors.warning }]} />
            </View>
          )}

          {/* Barcode-like decoration */}
          <View style={styles.barcodeRow}>
            {Array.from({ length: 28 }).map((_, i) => (
              <View key={i} style={[styles.barcodeLine, { height: i % 3 === 0 ? 20 : 14, backgroundColor: "rgba(255,255,255,0.4)" }]} />
            ))}
          </View>
          <Text style={styles.barcodeText}>{user.username.toUpperCase()}</Text>
        </View>

        {/* Change photo button */}
        <View style={{ flexDirection: "row", gap: 10 }}>
          <Pressable
            style={{ flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface }}
            onPress={handleTakePhoto}
          >
            <MaterialIcons name="camera-alt" size={18} color={colors.primary} />
            <Text style={{ color: colors.primary, fontWeight: "700", fontSize: 13 }}>Câmera</Text>
          </Pressable>
          <Pressable
            style={{ flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface }}
            onPress={handleChangePhoto}
          >
            <MaterialIcons name="photo-library" size={18} color={colors.primary} />
            <Text style={{ color: colors.primary, fontWeight: "700", fontSize: 13 }}>Galeria</Text>
          </Pressable>
        </View>

        {/* ── CNH CARD ── */}
        {cnh ? (
          <View style={[styles.cnhCard, { backgroundColor: colors.surface, borderColor: getStatusColor(cnh.status, colors) }]}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
              <View>
                <Text style={{ fontSize: 10, color: colors.muted, fontWeight: "600", letterSpacing: 1 }}>CARTEIRA NACIONAL DE HABILITAÇÃO</Text>
                <Text style={{ fontSize: 17, fontWeight: "800", color: colors.foreground, letterSpacing: 1, marginTop: 4 }}>
                  {cnh.cnhNumber.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")}
                </Text>
              </View>
              <View style={[styles.cnhStatusBadge, { backgroundColor: getStatusColor(cnh.status, colors) }]}>
                <Text style={{ color: "#fff", fontWeight: "800", fontSize: 10 }}>{getStatusLabel(cnh.status)}</Text>
              </View>
            </View>

            <View style={{ flexDirection: "row", gap: 24, marginTop: 12 }}>
              <View>
                <Text style={{ fontSize: 9, color: colors.muted, fontWeight: "600" }}>CATEGORIA</Text>
                <Text style={{ fontSize: 24, fontWeight: "900", color: colors.primary }}>{cnh.category}</Text>
              </View>
              <View>
                <Text style={{ fontSize: 9, color: colors.muted, fontWeight: "600" }}>VALIDADE</Text>
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground, marginTop: 2 }}>{formatDate(cnh.expiresAt)}</Text>
              </View>
              <View>
                <Text style={{ fontSize: 9, color: colors.muted, fontWeight: "600" }}>PONTOS RESTANTES</Text>
                <Text style={{ fontSize: 14, fontWeight: "700", color: getStatusColor(cnh.status, colors), marginTop: 2 }}>
                  {cnhPoints}/{cnh.totalPoints}
                </Text>
              </View>
            </View>

            {/* Points bar */}
            <View style={{ marginTop: 12 }}>
              <View style={{ height: 8, backgroundColor: colors.border, borderRadius: 4 }}>
                <View style={{ height: 8, width: `${cnhPct}%`, backgroundColor: getStatusColor(cnh.status, colors), borderRadius: 4 }} />
              </View>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
                <Text style={{ fontSize: 10, color: colors.muted }}>0 pts</Text>
                <Text style={{ fontSize: 10, color: colors.muted }}>{cnh.totalPoints} pts</Text>
              </View>
            </View>

            {cnh.status !== "active" && (
              <View style={{ marginTop: 10, padding: 10, borderRadius: 10, backgroundColor: getStatusColor(cnh.status, colors) + "15" }}>
                <Text style={{ fontSize: 12, color: getStatusColor(cnh.status, colors), fontWeight: "600", textAlign: "center" }}>
                  {cnh.status === "suspended"
                    ? "⚠️ CNH em situação de alerta. Evite novas infrações."
                    : "🚫 CNH bloqueada. Conclua o treinamento para reativar."}
                </Text>
              </View>
            )}
          </View>
        ) : (
          <View style={[styles.cnhCard, { backgroundColor: colors.surface, borderColor: colors.border, alignItems: "center", gap: 8 }]}>
            <MaterialIcons name="credit-card-off" size={32} color={colors.muted} />
            <Text style={{ color: colors.muted, fontSize: 14 }}>CNH não cadastrada</Text>
            <Text style={{ color: colors.muted, fontSize: 12, textAlign: "center" }}>
              Solicite ao administrador o cadastro da sua CNH no sistema.
            </Text>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  headerTitle: { fontSize: 22, fontWeight: "800" },
  headerSub: { fontSize: 13, marginTop: 2 },
  badgeCard: {
    borderRadius: 20,
    overflow: "hidden",
    elevation: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  badgeHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.2)",
  },
  badgeCompany: { flex: 1, fontSize: 16, fontWeight: "800", color: "#fff" },
  badgeRole: { fontSize: 10, fontWeight: "700", color: "rgba(255,255,255,0.7)", letterSpacing: 1 },
  badgeBody: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
    padding: 20,
  },
  photoWrap: { position: "relative" },
  photo: { width: 80, height: 80, borderRadius: 40, borderWidth: 3, borderColor: "rgba(255,255,255,0.8)" },
  photoPlaceholder: { width: 80, height: 80, borderRadius: 40, alignItems: "center", justifyContent: "center", borderWidth: 3, borderColor: "rgba(255,255,255,0.4)" },
  cameraOverlay: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "rgba(0,0,0,0.6)",
    alignItems: "center",
    justifyContent: "center",
  },
  badgeInfo: { flex: 1 },
  badgeName: { fontSize: 18, fontWeight: "800", color: "#fff" },
  badgeId: { fontSize: 13, color: "rgba(255,255,255,0.8)", marginTop: 2 },
  badgeContact: { fontSize: 12, color: "rgba(255,255,255,0.7)" },
  badgeSchedule: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: 20,
    marginBottom: 12,
    padding: 10,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.15)",
  },
  badgeScheduleText: { fontSize: 12, color: "rgba(255,255,255,0.9)", fontWeight: "600" },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
  barcodeRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "center",
    gap: 2,
    paddingHorizontal: 20,
    paddingTop: 12,
  },
  barcodeLine: { width: 2, borderRadius: 1 },
  barcodeText: { textAlign: "center", fontSize: 9, color: "rgba(255,255,255,0.5)", letterSpacing: 2, paddingVertical: 8 },
  cnhCard: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 2,
  },
  cnhStatusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
});
