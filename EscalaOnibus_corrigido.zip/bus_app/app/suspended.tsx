import { useEffect, useState } from "react";
import { View, Text, ScrollView, Pressable, StyleSheet, ActivityIndicator } from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { db, type CNHRecord, type Training } from "@/lib/database";

function formatDate(d: string) {
  if (!d) return "";
  const [y, m, day] = d.split("-");
  return `${day}/${m}/${y}`;
}

export default function SuspendedScreen() {
  const colors = useColors();
  const { user, logout } = useAuth();
  const [cnh, setCnh] = useState<CNHRecord | null>(null);
  const [trainings, setTrainings] = useState<Training[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      const cnhData = await db.getCNHByDriver(user.id);
      setCnh(cnhData);
      const tList = await db.getTrainingsByDriver(user.id);
      setTrainings(tList);
      setLoading(false);
    };
    load();
  }, [user]);

  const handleMarkCompleted = async (trainingId: string) => {
    await db.updateTraining(trainingId, { status: "completed", completedAt: new Date().toISOString() });
    const tList = await db.getTrainingsByDriver(user!.id);
    setTrainings(tList);
  };

  const pendingTraining = trainings.find((t) => t.status === "pending");
  const completedTraining = trainings.find((t) => t.status === "completed");
  const approvedTraining = trainings.find((t) => t.status === "approved");

  if (loading) {
    return (
      <ScreenContainer>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView contentContainerStyle={{ padding: 24, gap: 20 }}>
        {/* Warning Banner */}
        <View style={[styles.banner, { backgroundColor: colors.error + "15", borderColor: colors.error }]}>
          <MaterialIcons name="block" size={48} color={colors.error} />
          <Text style={[styles.bannerTitle, { color: colors.error }]}>Acesso Suspenso</Text>
          <Text style={[styles.bannerSub, { color: colors.muted }]}>
            Sua CNH foi bloqueada por excesso de pontos de infração. Você não pode acessar as funções do aplicativo até concluir o treinamento obrigatório e receber aprovação do administrador.
          </Text>
        </View>

        {/* CNH Status */}
        {cnh && (
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Situação da CNH</Text>
            <View style={{ flexDirection: "row", gap: 20, marginTop: 10 }}>
              <View>
                <Text style={{ fontSize: 10, color: colors.muted }}>NÚMERO</Text>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground }}>
                  {cnh.cnhNumber.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")}
                </Text>
              </View>
              <View>
                <Text style={{ fontSize: 10, color: colors.muted }}>CATEGORIA</Text>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.foreground }}>{cnh.category}</Text>
              </View>
              <View>
                <Text style={{ fontSize: 10, color: colors.muted }}>PONTOS USADOS</Text>
                <Text style={{ fontSize: 13, fontWeight: "700", color: colors.error }}>{cnh.usedPoints}/{cnh.totalPoints}</Text>
              </View>
            </View>
            <View style={[styles.statusBadge, { backgroundColor: colors.error }]}>
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 12 }}>CNH BLOQUEADA</Text>
            </View>
          </View>
        )}

        {/* Training Status */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>Treinamento Obrigatório</Text>

          {approvedTraining ? (
            <View style={{ alignItems: "center", gap: 8, marginTop: 12 }}>
              <MaterialIcons name="check-circle" size={40} color={colors.success} />
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.success }}>Treinamento Aprovado!</Text>
              <Text style={{ fontSize: 13, color: colors.muted, textAlign: "center" }}>
                Aprovado em {formatDate(approvedTraining.approvedAt?.split("T")[0] ?? "")} por {approvedTraining.approvedBy}.
              </Text>
              <Text style={{ fontSize: 13, color: colors.muted, textAlign: "center" }}>
                Aguarde o desbloqueio pelo administrador ou faça logout e entre novamente.
              </Text>
            </View>
          ) : completedTraining ? (
            <View style={{ alignItems: "center", gap: 8, marginTop: 12 }}>
              <MaterialIcons name="hourglass-top" size={40} color={colors.warning} />
              <Text style={{ fontSize: 15, fontWeight: "700", color: colors.warning }}>Aguardando Aprovação</Text>
              <Text style={{ fontSize: 13, color: colors.muted, textAlign: "center" }}>
                Você concluiu o treinamento "{completedTraining.title}". Aguarde o administrador aprovar sua conclusão para liberar o acesso.
              </Text>
            </View>
          ) : pendingTraining ? (
            <View style={{ gap: 12, marginTop: 12 }}>
              <View style={{ padding: 14, borderRadius: 12, borderWidth: 1, borderColor: colors.primary + "40", backgroundColor: colors.primary + "08" }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: colors.foreground }}>{pendingTraining.title}</Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>{pendingTraining.description}</Text>
                <Text style={{ fontSize: 12, color: colors.primary, marginTop: 6, fontWeight: "600" }}>
                  Carga horária: {pendingTraining.requiredHours}h
                </Text>
              </View>
              <Text style={{ fontSize: 13, color: colors.muted, textAlign: "center" }}>
                Após concluir o treinamento presencialmente, toque no botão abaixo para informar ao administrador.
              </Text>
              <Pressable
                style={{ backgroundColor: colors.primary, padding: 14, borderRadius: 12, alignItems: "center" }}
                onPress={() => handleMarkCompleted(pendingTraining.id)}
              >
                <Text style={{ color: "#fff", fontWeight: "700", fontSize: 15 }}>Marcar como Concluído</Text>
              </Pressable>
            </View>
          ) : (
            <View style={{ alignItems: "center", gap: 8, marginTop: 12 }}>
              <MaterialIcons name="school" size={40} color={colors.muted} />
              <Text style={{ fontSize: 14, color: colors.muted, textAlign: "center" }}>
                Nenhum treinamento atribuído ainda. Entre em contato com o administrador.
              </Text>
            </View>
          )}
        </View>

        {/* Steps */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>Como desbloquear</Text>
          {[
            { step: "1", text: "Aguarde o administrador criar um treinamento para você", done: !!pendingTraining || !!completedTraining || !!approvedTraining },
            { step: "2", text: "Conclua o treinamento presencialmente", done: !!completedTraining || !!approvedTraining },
            { step: "3", text: "Marque como concluído no app", done: !!completedTraining || !!approvedTraining },
            { step: "4", text: "Aguarde aprovação do administrador", done: !!approvedTraining },
          ].map((item) => (
            <View key={item.step} style={{ flexDirection: "row", gap: 12, alignItems: "flex-start", marginTop: 12 }}>
              <View style={{ width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: item.done ? colors.success : colors.border }}>
                {item.done
                  ? <MaterialIcons name="check" size={16} color="#fff" />
                  : <Text style={{ fontSize: 12, fontWeight: "700", color: colors.muted }}>{item.step}</Text>
                }
              </View>
              <Text style={{ flex: 1, fontSize: 13, color: item.done ? colors.muted : colors.foreground, marginTop: 4 }}>{item.text}</Text>
            </View>
          ))}
        </View>

        {/* Logout */}
        <Pressable
          style={{ padding: 14, borderRadius: 12, borderWidth: 1, borderColor: colors.border, alignItems: "center" }}
          onPress={logout}
        >
          <Text style={{ color: colors.muted, fontWeight: "700" }}>Sair do Aplicativo</Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  banner: {
    padding: 24,
    borderRadius: 16,
    borderWidth: 2,
    alignItems: "center",
    gap: 10,
  },
  bannerTitle: { fontSize: 22, fontWeight: "800", textAlign: "center" },
  bannerSub: { fontSize: 14, textAlign: "center", lineHeight: 20 },
  card: {
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
  },
  cardTitle: { fontSize: 15, fontWeight: "700" },
  statusBadge: {
    marginTop: 10,
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
});
