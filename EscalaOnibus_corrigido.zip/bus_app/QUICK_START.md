# ⚡ Quick Start - EscalaOnibus

Comece em 5 minutos!

## 🎯 Seu Aplicativo Está Pronto!

Todos os dados agora são armazenados em **nuvem** (Neon PostgreSQL) e acessíveis de qualquer lugar.

## 📦 O Que Você Recebeu

✅ **App Mobile** (Expo/React Native)
- Telas de Admin e Motorista
- Autenticação em nuvem
- Sincronização em tempo real
- Botão de suporte WhatsApp

✅ **Backend** (Node.js + Express)
- API REST completa
- Banco de dados PostgreSQL
- Autenticação JWT
- CORS configurado

✅ **Banco de Dados** (Neon.tech)
- PostgreSQL em nuvem
- Gratuito
- Backup automático

## 🚀 Próximos Passos

### 1. Criar Repositório no GitHub

```bash
# Acesse: https://github.com/new
# Preencha:
# - Name: bus_driver_schedule
# - Private: ✅
# - Initialize: Deixe em branco
# - Clique: Create repository
```

### 2. Fazer Push do Código

```bash
cd /home/ubuntu/bus_app
git remote add origin https://github.com/SEU_USUARIO/bus_driver_schedule.git
git push -u origin main
```

### 3. Deploy Backend no Render

```
1. Acesse: https://render.com
2. Clique: New → Web Service
3. Conecte seu repositório
4. Configure:
   - Build: pnpm install && pnpm build
   - Start: pnpm start
   - Add Environment Variables (DATABASE_URL)
5. Deploy!
```

### 4. Atualizar URL da API

Após o Render gerar a URL (ex: `https://escalaonibus-api.onrender.com`):

```bash
# Edite .env.production
EXPO_PUBLIC_API_URL=https://escalaonibus-api.onrender.com
```

### 5. Testar App

```bash
# Gerar QR code
pnpm run qr

# Escaneie com Expo Go
# Login: admin / admin123
```

## 📱 Credenciais Padrão

| Campo | Valor |
|-------|-------|
| **Usuário** | `admin` |
| **Senha** | `admin123` |
| **Papel** | Administrador |

⚠️ **Altere a senha após primeiro login!**

## 🔗 URLs Importantes

| Serviço | URL |
|---------|-----|
| **Neon Console** | https://console.neon.tech |
| **Render Dashboard** | https://render.com/dashboard |
| **GitHub** | https://github.com/seu-usuario/bus_driver_schedule |
| **Banco de Dados** | postgresql://... (em .env) |

## 📊 Estrutura de Dados

### Usuários
- Admin (gerencia motoristas)
- Motoristas (múltiplos, em qualquer lugar)

### Escalas
- Criar, editar, aprovar, negar
- Sincroniza em tempo real

### Ponto Eletrônico
- Entrada/saída com foto
- Localização GPS
- Histórico completo

### Ocorrências
- Problemas durante turno
- Tipos: mecânico, acidente, atraso, etc.

### CNH Virtual
- Gestão de habilitação
- Multas e pontos
- Status (ativo/suspenso/bloqueado)

## 🎨 Personalização

### Mudar Cores

Edite: `theme.config.js`

### Mudar Logo

Edite: `app.config.ts` → `logoUrl`

### Mudar Nome

Edite: `app.config.ts` → `appName`

## 🔐 Segurança

✅ Dados em nuvem (não local)
✅ Autenticação JWT
✅ Senhas com hash
✅ CORS configurado
✅ SSL/TLS automático (Render)

## 📞 Suporte

**WhatsApp**: (19) 99560-5536

Clique no botão "Suporte via WhatsApp" no perfil do admin!

## ❓ Perguntas Frequentes

### P: Como adicionar novos motoristas?
**R**: Admin → Motoristas → Botão "+" → Preencha dados

### P: Como criar escalas?
**R**: Admin → Escalas → Botão "+" → Selecione motorista e data

### P: Como o motorista vê suas escalas?
**R**: Motorista → Home → Vê escalas da semana

### P: Os dados são perdidos se desligar o celular?
**R**: Não! Tudo está em nuvem. Ao fazer login novamente, os dados aparecem.

### P: Funciona sem internet?
**R**: Parcialmente. Pode usar dados locais em cache, mas sincroniza quando conectar.

### P: Quantos motoristas posso ter?
**R**: Ilimitado! Está em nuvem.

## 🎓 Documentação Completa

Veja: `README.md` e `DEPLOYMENT_GUIDE.md`

## ✨ Recursos Principais

| Feature | Admin | Motorista |
|---------|-------|-----------|
| Criar escalas | ✅ | ❌ |
| Aprovar escalas | ✅ | ❌ |
| Ver escalas | ✅ | ✅ |
| Confirmar escala | ❌ | ✅ |
| Ponto eletrônico | ❌ | ✅ |
| Registrar ocorrência | ❌ | ✅ |
| Dashboard | ✅ | ❌ |
| Relatórios | ✅ | ❌ |

## 🚀 Você Está Pronto!

Seu app está **100% funcional** e **pronto para produção**.

Basta fazer o push para GitHub, deploy no Render, e compartilhar o QR code com seus motoristas!

---

**Desenvolvido com ❤️ para EscalaOnibus**
