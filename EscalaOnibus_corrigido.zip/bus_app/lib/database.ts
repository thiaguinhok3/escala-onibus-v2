import AsyncStorage from "@react-native-async-storage/async-storage";

// ─── Types ───────────────────────────────────────────────────────────────────

export type UserRole = "admin" | "driver";

export interface User {
  id: string;
  name: string;
  username: string;
  password: string;
  role: UserRole;
  whatsapp?: string;
  driverId?: string;
  pin?: string; // 4-digit PIN for punch clock
  photoUri?: string; // profile photo for badge
  isSuspended?: boolean; // true when CNH is blocked and training not approved
  createdAt: string;
}

export type ScheduleStatus = "pending" | "approved" | "denied";
export type ScheduleType = "work" | "day_off" | "vacation";

export interface Schedule {
  id: string;
  date: string; // ISO date string YYYY-MM-DD
  line: string;
  driverId: string;
  driverName: string;
  busModel: string;
  busPrefix: string;
  startTime: string; // HH:MM
  endTime: string; // HH:MM
  scheduleType?: ScheduleType; // "work" (default) | "day_off" | "vacation"
  observations?: string;
  status: ScheduleStatus;
  denyReason?: string; // Reason provided by admin when denying
  confirmedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// ─── Ponto Eletrônico ────────────────────────────────────────────────────────

export type PunchType = "start" | "break_start" | "break_end" | "end";

export interface PunchRecord {
  id: string;
  driverId: string;
  driverName: string;
  scheduleId?: string;
  type: PunchType;
  timestamp: string; // ISO datetime
  latitude?: number;
  longitude?: number;
  note?: string;
  photoUri?: string; // base64 or local URI of selfie taken at punch time
  pinVerified?: boolean; // whether driver confirmed with PIN
}

export interface WorkdayPunches {
  date: string; // YYYY-MM-DD
  driverId: string;
  driverName: string;
  scheduleId?: string;
  start?: PunchRecord;
  breakStart?: PunchRecord;
  breakEnd?: PunchRecord;
  end?: PunchRecord;
}

export type OccurrenceType =
  | "mechanical"
  | "accident"
  | "delay"
  | "passenger"
  | "route"
  | "other";

export interface Occurrence {
  id: string;
  driverId: string;
  driverName: string;
  scheduleId?: string;
  type: OccurrenceType;
  description: string;
  isRead: boolean;
  createdAt: string;
}

// ─── CNH Fictícia ────────────────────────────────────────────────────────────

export type CNHCategory = "A" | "B" | "C" | "D" | "E" | "AB" | "AC" | "AD" | "AE";
export type CNHStatus = "active" | "suspended" | "blocked";

export interface CNHRecord {
  id: string;
  driverId: string;
  driverName: string;
  cnhNumber: string; // fictitious number
  category: CNHCategory;
  expiresAt: string; // YYYY-MM-DD
  totalPoints: number; // starts at 40, decreases with fines
  usedPoints: number; // points consumed by fines
  status: CNHStatus; // active | suspended (>20pts) | blocked (>=40pts)
  createdAt: string;
  updatedAt: string;
}

export type FineType =
  | "speeding_mild"    // 3pts
  | "speeding_medium"  // 5pts
  | "speeding_severe"  // 7pts
  | "red_light"        // 7pts
  | "seatbelt"         // 5pts
  | "phone"            // 5pts
  | "alcohol"          // 7pts
  | "parking"          // 3pts
  | "other";           // custom pts

export interface Fine {
  id: string;
  driverId: string;
  driverName: string;
  cnhId: string;
  type: FineType;
  description: string;
  points: number;
  value: number; // monetary value in BRL
  date: string; // YYYY-MM-DD
  createdAt: string;
}

export type TrainingStatus = "pending" | "completed" | "approved";

export interface Training {
  id: string;
  driverId: string;
  driverName: string;
  title: string;
  description: string;
  requiredHours: number;
  status: TrainingStatus;
  completedAt?: string;
  approvedAt?: string;
  approvedBy?: string;
  createdAt: string;
  updatedAt: string;
}

// ─── Storage Keys ─────────────────────────────────────────────────────────────

const KEYS = {
  USERS: "@escalaonibus:users",
  SCHEDULES: "@escalaonibus:schedules",
  OCCURRENCES: "@escalaonibus:occurrences",
  PUNCHES: "@escalaonibus:punches",
  CNH_RECORDS: "@escalaonibus:cnh_records",
  FINES: "@escalaonibus:fines",
  TRAININGS: "@escalaonibus:trainings",
  INITIALIZED: "@escalaonibus:initialized",
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function now(): string {
  return new Date().toISOString();
}

// ─── Database Class ───────────────────────────────────────────────────────────

class Database {
  // ── Initialization ──────────────────────────────────────────────────────────

  async initialize(): Promise<void> {
    const initialized = await AsyncStorage.getItem(KEYS.INITIALIZED);
    if (initialized === "true") return;

    // Seed admin user
    const adminUser: User = {
      id: "admin-001",
      name: "Administrador",
      username: "admin",
      password: "admin123",
      role: "admin",
      createdAt: now(),
    };

    await AsyncStorage.setItem(KEYS.USERS, JSON.stringify([adminUser]));
    await AsyncStorage.setItem(KEYS.SCHEDULES, JSON.stringify([]));
    await AsyncStorage.setItem(KEYS.OCCURRENCES, JSON.stringify([]));
    await AsyncStorage.setItem(KEYS.INITIALIZED, "true");
  }

  async reset(): Promise<void> {
    await AsyncStorage.multiRemove([
      KEYS.USERS,
      KEYS.SCHEDULES,
      KEYS.OCCURRENCES,
      KEYS.INITIALIZED,
    ]);
    await this.initialize();
  }

  // ── Users ────────────────────────────────────────────────────────────────────

  async getUsers(): Promise<User[]> {
    const raw = await AsyncStorage.getItem(KEYS.USERS);
    return raw ? JSON.parse(raw) : [];
  }

  async getUserById(id: string): Promise<User | null> {
    const users = await this.getUsers();
    return users.find((u) => u.id === id) ?? null;
  }

  async getUserByUsername(username: string): Promise<User | null> {
    const users = await this.getUsers();
    return users.find((u) => u.username === username) ?? null;
  }

  async getDrivers(): Promise<User[]> {
    const users = await this.getUsers();
    return users.filter((u) => u.role === "driver");
  }

  async createDriver(data: Omit<User, "id" | "role" | "createdAt">): Promise<User> {
    const users = await this.getUsers();
    const driver: User = {
      ...data,
      id: generateId(),
      role: "driver",
      createdAt: now(),
    };
    await AsyncStorage.setItem(KEYS.USERS, JSON.stringify([...users, driver]));
    return driver;
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | null> {
    const users = await this.getUsers();
    const index = users.findIndex((u) => u.id === id);
    if (index === -1) return null;
    users[index] = { ...users[index], ...data };
    await AsyncStorage.setItem(KEYS.USERS, JSON.stringify(users));
    return users[index];
  }

  async deleteUser(id: string): Promise<boolean> {
    const users = await this.getUsers();
    const filtered = users.filter((u) => u.id !== id);
    if (filtered.length === users.length) return false;
    await AsyncStorage.setItem(KEYS.USERS, JSON.stringify(filtered));
    return true;
  }

  // ── Schedules ────────────────────────────────────────────────────────────────

  async getSchedules(): Promise<Schedule[]> {
    const raw = await AsyncStorage.getItem(KEYS.SCHEDULES);
    return raw ? JSON.parse(raw) : [];
  }

  async getScheduleById(id: string): Promise<Schedule | null> {
    const schedules = await this.getSchedules();
    return schedules.find((s) => s.id === id) ?? null;
  }

  async getSchedulesByDate(date: string): Promise<Schedule[]> {
    const schedules = await this.getSchedules();
    return schedules.filter((s) => s.date === date);
  }

  async getSchedulesByDriver(driverId: string): Promise<Schedule[]> {
    const schedules = await this.getSchedules();
    return schedules
      .filter((s) => s.driverId === driverId)
      .sort((a, b) => b.date.localeCompare(a.date));
  }

  async getSchedulesByDateRange(
    startDate: string,
    endDate: string
  ): Promise<Schedule[]> {
    const schedules = await this.getSchedules();
    return schedules
      .filter((s) => s.date >= startDate && s.date <= endDate)
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async getAllSchedules(): Promise<Schedule[]> {
    const schedules = await this.getSchedules();
    return schedules.sort((a, b) => b.date.localeCompare(a.date));
  }

  async getSchedulesByDriverAndDateRange(
    driverId: string,
    startDate: string,
    endDate: string
  ): Promise<Schedule[]> {
    const schedules = await this.getSchedules();
    return schedules
      .filter(
        (s) =>
          s.driverId === driverId &&
          s.date >= startDate &&
          s.date <= endDate
      )
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async createSchedule(
    data: Omit<Schedule, "id" | "createdAt" | "updatedAt">
  ): Promise<Schedule> {
    const schedules = await this.getSchedules();
    const schedule: Schedule = {
      ...data,
      id: generateId(),
      createdAt: now(),
      updatedAt: now(),
    };
    await AsyncStorage.setItem(
      KEYS.SCHEDULES,
      JSON.stringify([...schedules, schedule])
    );
    return schedule;
  }

  async createSchedulesBulk(
    dataList: Omit<Schedule, "id" | "createdAt" | "updatedAt">[]
  ): Promise<Schedule[]> {
    const schedules = await this.getSchedules();
    const newSchedules: Schedule[] = dataList.map((data) => ({
      ...data,
      id: generateId(),
      createdAt: now(),
      updatedAt: now(),
    }));
    await AsyncStorage.setItem(
      KEYS.SCHEDULES,
      JSON.stringify([...schedules, ...newSchedules])
    );
    return newSchedules;
  }

  async updateSchedule(
    id: string,
    data: Partial<Schedule>
  ): Promise<Schedule | null> {
    const schedules = await this.getSchedules();
    const index = schedules.findIndex((s) => s.id === id);
    if (index === -1) return null;
    schedules[index] = { ...schedules[index], ...data, updatedAt: now() };
    await AsyncStorage.setItem(KEYS.SCHEDULES, JSON.stringify(schedules));
    return schedules[index];
  }

  async deleteSchedule(id: string): Promise<boolean> {
    const schedules = await this.getSchedules();
    const filtered = schedules.filter((s) => s.id !== id);
    if (filtered.length === schedules.length) return false;
    await AsyncStorage.setItem(KEYS.SCHEDULES, JSON.stringify(filtered));
    return true;
  }

  // ── Occurrences ──────────────────────────────────────────────────────────────

  async getOccurrences(): Promise<Occurrence[]> {
    const raw = await AsyncStorage.getItem(KEYS.OCCURRENCES);
    const list: Occurrence[] = raw ? JSON.parse(raw) : [];
    return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  async createOccurrence(
    data: Omit<Occurrence, "id" | "isRead" | "createdAt">
  ): Promise<Occurrence> {
    const occurrences = await this.getOccurrences();
    const occurrence: Occurrence = {
      ...data,
      id: generateId(),
      isRead: false,
      createdAt: now(),
    };
    await AsyncStorage.setItem(
      KEYS.OCCURRENCES,
      JSON.stringify([...occurrences, occurrence])
    );
    return occurrence;
  }

  async markOccurrenceAsRead(id: string): Promise<void> {
    const occurrences = await this.getOccurrences();
    const index = occurrences.findIndex((o) => o.id === id);
    if (index !== -1) {
      occurrences[index].isRead = true;
      await AsyncStorage.setItem(KEYS.OCCURRENCES, JSON.stringify(occurrences));
    }
  }

  // ─── Ponto Eletrônico ──────────────────────────────────────────────────────

  async getPunches(): Promise<PunchRecord[]> {
    const raw = await AsyncStorage.getItem(KEYS.PUNCHES);
    return raw ? JSON.parse(raw) : [];
  }

  async getPunchesByDriver(driverId: string): Promise<PunchRecord[]> {
    const all = await this.getPunches();
    return all.filter((p) => p.driverId === driverId);
  }

  async getPunchesByDate(date: string): Promise<PunchRecord[]> {
    const all = await this.getPunches();
    return all.filter((p) => p.timestamp.startsWith(date));
  }

  async getPunchesByDriverAndDate(driverId: string, date: string): Promise<PunchRecord[]> {
    const all = await this.getPunches();
    return all.filter((p) => p.driverId === driverId && p.timestamp.startsWith(date));
  }

  async getPunchesByDateRange(start: string, end: string): Promise<PunchRecord[]> {
    const all = await this.getPunches();
    return all.filter((p) => {
      const d = p.timestamp.split("T")[0];
      return d >= start && d <= end;
    });
  }

  async createPunch(
    data: Omit<PunchRecord, "id">
  ): Promise<PunchRecord> {
    const punches = await this.getPunches();
    const punch: PunchRecord = { ...data, id: generateId() };
    await AsyncStorage.setItem(KEYS.PUNCHES, JSON.stringify([...punches, punch]));
    return punch;
  }

  async deletePunch(id: string): Promise<void> {
    const punches = await this.getPunches();
    await AsyncStorage.setItem(KEYS.PUNCHES, JSON.stringify(punches.filter((p) => p.id !== id)));
  }

  /** Builds a WorkdayPunches summary for a driver on a given date */
  async getWorkdayPunches(driverId: string, date: string): Promise<WorkdayPunches> {
    const punches = await this.getPunchesByDriverAndDate(driverId, date);
    const byType = (t: PunchType) => punches.find((p) => p.type === t);
    const first = punches[0];
    return {
      date,
      driverId,
      driverName: first?.driverName ?? "",
      scheduleId: first?.scheduleId,
      start: byType("start"),
      breakStart: byType("break_start"),
      breakEnd: byType("break_end"),
      end: byType("end"),
    };
  }

  // ─── CNH Fictícia ───────────────────────────────────────────────────────────

  async getCNHRecords(): Promise<CNHRecord[]> {
    const raw = await AsyncStorage.getItem(KEYS.CNH_RECORDS);
    return raw ? JSON.parse(raw) : [];
  }

  async getCNHByDriver(driverId: string): Promise<CNHRecord | null> {
    const all = await this.getCNHRecords();
    return all.find((c) => c.driverId === driverId) ?? null;
  }

  async createCNH(data: Omit<CNHRecord, "id" | "createdAt" | "updatedAt">): Promise<CNHRecord> {
    const all = await this.getCNHRecords();
    const cnh: CNHRecord = { ...data, id: generateId(), createdAt: now(), updatedAt: now() };
    await AsyncStorage.setItem(KEYS.CNH_RECORDS, JSON.stringify([...all, cnh]));
    return cnh;
  }

  async updateCNH(id: string, data: Partial<CNHRecord>): Promise<CNHRecord | null> {
    const all = await this.getCNHRecords();
    const idx = all.findIndex((c) => c.id === id);
    if (idx === -1) return null;
    all[idx] = { ...all[idx], ...data, updatedAt: now() };
    await AsyncStorage.setItem(KEYS.CNH_RECORDS, JSON.stringify(all));
    return all[idx];
  }

  /** Generates a fictitious CNH number */
  generateCNHNumber(): string {
    const digits = Array.from({ length: 11 }, () => Math.floor(Math.random() * 10)).join("");
    return digits;
  }

  // ─── Multas ───────────────────────────────────────────────────────────────────────

  async getFines(): Promise<Fine[]> {
    const raw = await AsyncStorage.getItem(KEYS.FINES);
    const list: Fine[] = raw ? JSON.parse(raw) : [];
    return list.sort((a, b) => b.date.localeCompare(a.date));
  }

  async getFinesByDriver(driverId: string): Promise<Fine[]> {
    const all = await this.getFines();
    return all.filter((f) => f.driverId === driverId);
  }

  async createFine(data: Omit<Fine, "id" | "createdAt">): Promise<Fine> {
    const fines = await this.getFines();
    const fine: Fine = { ...data, id: generateId(), createdAt: now() };
    await AsyncStorage.setItem(KEYS.FINES, JSON.stringify([...fines, fine]));

    // Update CNH points
    const cnh = await this.getCNHByDriver(data.driverId);
    if (cnh) {
      const newUsed = cnh.usedPoints + data.points;
      let newStatus: CNHStatus = cnh.status;
      if (newUsed >= cnh.totalPoints) {
        newStatus = "blocked";
        // Suspend driver account
        await this.updateUser(cnh.driverId, { isSuspended: true });
      } else if (newUsed >= Math.floor(cnh.totalPoints / 2)) {
        newStatus = "suspended";
      }
      await this.updateCNH(cnh.id, { usedPoints: newUsed, status: newStatus });
    }
    return fine;
  }

  async deleteFine(id: string): Promise<void> {
    const fine = (await this.getFines()).find((f) => f.id === id);
    if (!fine) return;
    const fines = await this.getFines();
    await AsyncStorage.setItem(KEYS.FINES, JSON.stringify(fines.filter((f) => f.id !== id)));
    // Recalculate CNH points
    const cnh = await this.getCNHByDriver(fine.driverId);
    if (cnh) {
      const remaining = await this.getFinesByDriver(fine.driverId);
      const usedPoints = remaining.reduce((s, f) => s + f.points, 0);
      let status: CNHStatus = "active";
      if (usedPoints >= cnh.totalPoints) status = "blocked";
      else if (usedPoints >= Math.floor(cnh.totalPoints / 2)) status = "suspended";
      await this.updateCNH(cnh.id, { usedPoints, status });
      if (status !== "blocked") {
        await this.updateUser(fine.driverId, { isSuspended: false });
      }
    }
  }

  // ─── Treinamentos ──────────────────────────────────────────────────────────────────

  async getTrainings(): Promise<Training[]> {
    const raw = await AsyncStorage.getItem(KEYS.TRAININGS);
    const list: Training[] = raw ? JSON.parse(raw) : [];
    return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  async getTrainingsByDriver(driverId: string): Promise<Training[]> {
    const all = await this.getTrainings();
    return all.filter((t) => t.driverId === driverId);
  }

  async createTraining(data: Omit<Training, "id" | "createdAt" | "updatedAt">): Promise<Training> {
    const trainings = await this.getTrainings();
    const training: Training = { ...data, id: generateId(), createdAt: now(), updatedAt: now() };
    await AsyncStorage.setItem(KEYS.TRAININGS, JSON.stringify([...trainings, training]));
    return training;
  }

  async updateTraining(id: string, data: Partial<Training>): Promise<Training | null> {
    const trainings = await this.getTrainings();
    const idx = trainings.findIndex((t) => t.id === id);
    if (idx === -1) return null;
    trainings[idx] = { ...trainings[idx], ...data, updatedAt: now() };
    await AsyncStorage.setItem(KEYS.TRAININGS, JSON.stringify(trainings));
    return trainings[idx];
  }

  /** Approve training and unblock driver if CNH points allow */
  async approveTraining(trainingId: string, adminName: string): Promise<Training | null> {
    const training = await this.updateTraining(trainingId, {
      status: "approved",
      approvedAt: now(),
      approvedBy: adminName,
    });
    if (!training) return null;
    // Unblock driver
    await this.updateUser(training.driverId, { isSuspended: false });
    // Reset CNH to active if points allow
    const cnh = await this.getCNHByDriver(training.driverId);
    if (cnh && cnh.status === "blocked") {
      await this.updateCNH(cnh.id, { status: "active", usedPoints: 0 });
    }
    return training;
  }
}

export const db = new Database();
