import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

// Configure how notifications are handled when app is in foreground
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

/**
 * Request notification permissions and set up Android channel.
 * Should be called once on app startup.
 */
export async function setupNotifications(): Promise<boolean> {
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("escalas", {
      name: "Escalas",
      description: "Notificações sobre aprovação e negação de escalas",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#1A56DB",
      sound: "default",
    });
    await Notifications.setNotificationChannelAsync("ocorrencias", {
      name: "Ocorrências",
      description: "Notificações sobre novas ocorrências dos motoristas",
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#F59E0B",
    });
    await Notifications.setNotificationChannelAsync("cnh", {
      name: "CNH",
      description: "Notificações sobre pontuação e status da CNH",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 500, 200, 500],
      lightColor: "#DC2626",
      sound: "default",
    });
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  if (existingStatus === "granted") return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

/**
 * Notify a driver that their schedule was approved.
 */
export async function notifyScheduleApproved(params: {
  driverName: string;
  date: string;
  line: string;
  startTime: string;
  endTime: string;
}): Promise<void> {
  const [year, month, day] = params.date.split("-");
  const formattedDate = `${day}/${month}/${year}`;

  await Notifications.scheduleNotificationAsync({
    content: {
      title: "✅ Escala Aprovada!",
      body: `Sua escala de ${formattedDate} foi aprovada.\nLinha: ${params.line} | ${params.startTime}–${params.endTime}`,
      data: { type: "schedule_approved", date: params.date },
      sound: "default",
      categoryIdentifier: "escalas",
    },
    trigger: null, // immediate
  });
}

/**
 * Notify a driver that their schedule was denied.
 */
export async function notifyScheduleDenied(params: {
  driverName: string;
  date: string;
  line: string;
}): Promise<void> {
  const [year, month, day] = params.date.split("-");
  const formattedDate = `${day}/${month}/${year}`;

  await Notifications.scheduleNotificationAsync({
    content: {
      title: "❌ Escala Negada",
      body: `Sua escala de ${formattedDate} (${params.line}) foi negada pelo administrador. Entre em contato para mais informações.`,
      data: { type: "schedule_denied", date: params.date },
      sound: "default",
      categoryIdentifier: "escalas",
    },
    trigger: null, // immediate
  });
}

/**
 * Notify admin that a new occurrence was reported.
 */
export async function notifyNewOccurrence(params: {
  driverName: string;
  type: string;
}): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "⚠️ Nova Ocorrência Reportada",
      body: `${params.driverName} reportou uma ocorrência: ${params.type}. Acesse o app para visualizar.`,
      data: { type: "new_occurrence" },
      sound: "default",
      categoryIdentifier: "ocorrencias",
    },
    trigger: null, // immediate
  });
}

/**
 * Notify a driver that a fine was added to their CNH.
 */
export async function notifyCNHFine(params: {
  driverName: string;
  fineType: string;
  pointsDeducted: number;
  remainingPoints: number;
  isSuspended: boolean;
}): Promise<void> {
  const isSuspended = params.isSuspended;
  await Notifications.scheduleNotificationAsync({
    content: {
      title: isSuspended ? "🚫 CNH Suspensa!" : "⚠️ Multa Registrada na CNH",
      body: isSuspended
        ? `Sua CNH foi suspensa por perda total de pontos. Solicite o treinamento para reativação.`
        : `Multa: ${params.fineType} \u2022 -${params.pointsDeducted} pontos \u2022 Saldo: ${params.remainingPoints} pontos restantes.`,
      data: { type: "cnh_fine", isSuspended },
      sound: "default",
      categoryIdentifier: "cnh",
    },
    trigger: null,
  });
}

/**
 * Notify a driver that their CNH was reactivated after training.
 */
export async function notifyCNHReactivated(): Promise<void> {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "✅ CNH Reativada!",
      body: "Seu treinamento foi aprovado e sua CNH foi reativada. Você já pode acessar o app normalmente.",
      data: { type: "cnh_reactivated" },
      sound: "default",
      categoryIdentifier: "cnh",
    },
    trigger: null,
  });
}

/**
 * Cancel all pending notifications.
 */
export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}
