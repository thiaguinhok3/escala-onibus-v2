import axios, { AxiosInstance } from "axios";
import { Platform } from "react-native";

/**
 * Resolve a URL base da API de forma dinâmica.
 *
 * Prioridade:
 * 1. Variável de ambiente EXPO_PUBLIC_API_URL (definida no .env ou no painel do Vercel)
 * 2. No navegador (web): deriva do hostname atual — substitui a porta 8081 por 3000
 *    ou usa a mesma origem (útil quando o frontend e o backend estão no mesmo domínio)
 * 3. Fallback para localhost:3000 (desenvolvimento local)
 */
function resolveApiBaseUrl(): string {
  // 1. Variável de ambiente explícita
  const envUrl = process.env.EXPO_PUBLIC_API_URL;
  if (envUrl) {
    return envUrl.replace(/\/$/, "");
  }

  // 2. Derivação automática no navegador
  if (Platform.OS === "web" && typeof window !== "undefined" && window.location) {
    const { protocol, hostname, port } = window.location;

    // Padrão do ambiente Manus: 8081-sandboxid.region.domain → 3000-sandboxid.region.domain
    const apiHostname = hostname.replace(/^8081-/, "3000-");
    if (apiHostname !== hostname) {
      return `${protocol}//${apiHostname}`;
    }

    // Mesmo domínio (Vercel, Render, etc.): usa URL relativa (sem host)
    // O servidor Express e o frontend estão no mesmo domínio
    if (!port || port === "80" || port === "443") {
      return "";
    }
  }

  // 3. Fallback para desenvolvimento local
  return "http://localhost:3000";
}

const API_BASE_URL = resolveApiBaseUrl();
const API_TIMEOUT = 10000; // 10 segundos

class APIClient {
  private client: AxiosInstance;

  constructor() {
    const baseURL = API_BASE_URL ? `${API_BASE_URL}/api` : "/api";
    this.client = axios.create({
      baseURL,
      timeout: API_TIMEOUT,
    });
  }

  // ─── Auth ──────────────────────────────────────────────────────────────

  async login(username: string, password: string) {
    try {
      const response = await this.client.post("/auth/login", { username, password });
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Login failed");
    }
  }

  // ─── Drivers ───────────────────────────────────────────────────────────

  async getDrivers() {
    try {
      const response = await this.client.get("/drivers");
      return response.data;
    } catch (error) {
      console.error("Error fetching drivers:", error);
      return [];
    }
  }

  async createDriver(data: any) {
    try {
      const response = await this.client.post("/drivers", data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to create driver");
    }
  }

  async updateDriver(id: string, data: any) {
    try {
      const response = await this.client.put(`/drivers/${id}`, data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to update driver");
    }
  }

  async deleteDriver(id: string) {
    try {
      const response = await this.client.delete(`/drivers/${id}`);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to delete driver");
    }
  }

  // ─── Schedules ─────────────────────────────────────────────────────────

  async getSchedules() {
    try {
      const response = await this.client.get("/schedules");
      return response.data;
    } catch (error) {
      console.error("Error fetching schedules:", error);
      return [];
    }
  }

  async getSchedulesByDriver(driverId: string) {
    try {
      const response = await this.client.get(`/schedules/driver/${driverId}`);
      return response.data;
    } catch (error) {
      console.error("Error fetching driver schedules:", error);
      return [];
    }
  }

  async createSchedule(data: any) {
    try {
      const response = await this.client.post("/schedules", data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to create schedule");
    }
  }

  async updateSchedule(id: string, data: any) {
    try {
      const response = await this.client.put(`/schedules/${id}`, data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to update schedule");
    }
  }

  async deleteSchedule(id: string) {
    try {
      const response = await this.client.delete(`/schedules/${id}`);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to delete schedule");
    }
  }

  // ─── CNH ────────────────────────────────────────────────────────────────

  async getCNHByDriver(driverId: string) {
    try {
      const response = await this.client.get(`/cnh/driver/${driverId}`);
      return response.data;
    } catch (error) {
      console.error("Error fetching CNH:", error);
      return null;
    }
  }

  async createCNH(data: any) {
    try {
      const response = await this.client.post("/cnh", data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to create CNH");
    }
  }

  async updateCNH(id: string, data: any) {
    try {
      const response = await this.client.put(`/cnh/${id}`, data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to update CNH");
    }
  }

  // ─── Fines ──────────────────────────────────────────────────────────────

  async getFinesByDriver(driverId: string) {
    try {
      const response = await this.client.get(`/fines/driver/${driverId}`);
      return response.data;
    } catch (error) {
      console.error("Error fetching fines:", error);
      return [];
    }
  }

  async createFine(data: any) {
    try {
      const response = await this.client.post("/fines", data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to create fine");
    }
  }

  // ─── Punches ────────────────────────────────────────────────────────────

  async getPunchesByDriver(driverId: string) {
    try {
      const response = await this.client.get(`/punches/driver/${driverId}`);
      return response.data;
    } catch (error) {
      console.error("Error fetching punches:", error);
      return [];
    }
  }

  async createPunch(data: any) {
    try {
      const response = await this.client.post("/punches", data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to create punch");
    }
  }

  // ─── Occurrences ────────────────────────────────────────────────────────

  async getOccurrencesByDriver(driverId: string) {
    try {
      const response = await this.client.get(`/occurrences/driver/${driverId}`);
      return response.data;
    } catch (error) {
      console.error("Error fetching occurrences:", error);
      return [];
    }
  }

  async createOccurrence(data: any) {
    try {
      const response = await this.client.post("/occurrences", data);
      return response.data;
    } catch (error: any) {
      throw new Error(error.response?.data?.error || "Failed to create occurrence");
    }
  }
}

export const apiClient = new APIClient();
