import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { type User } from "./database";
import { apiClient } from "./api-client";

const SESSION_KEY = "@escalaonibus:session";

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
}

interface AuthContextValue extends AuthState {
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isLoading: true,
    isAuthenticated: false,
  });

  // Restaurar sessão salva ao iniciar o app
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(SESSION_KEY);
        if (raw) {
          const savedUser: User = JSON.parse(raw);
          setState({ user: savedUser, isLoading: false, isAuthenticated: true });
          return;
        }
      } catch {
        // Ignorar erros de parse
      }
      setState({ user: null, isLoading: false, isAuthenticated: false });
    })();
  }, []);

  const login = useCallback(
    async (username: string, password: string) => {
      const trimmedUsername = username.trim().toLowerCase();

      try {
        // Login via API remota
        const serverUser = await apiClient.login(trimmedUsername, password);

        const user: User = {
          id: serverUser.id,
          name: serverUser.name,
          username: serverUser.username,
          password: password,
          driverId: serverUser.driverId,
          role: serverUser.role || "driver",
          whatsapp: serverUser.whatsapp,
          photoUri: serverUser.photoUri,
          isSuspended: serverUser.isSuspended,
          createdAt: new Date().toISOString(),
        };

        // Salvar sessão localmente para restaurar após fechar o app
        await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(user));

        setState({ user, isLoading: false, isAuthenticated: true });
        return { success: true };
      } catch (serverError: any) {
        const errorMsg: string = serverError?.message || "Erro ao conectar ao servidor";

        // Erros de credenciais inválidas — não tentar sessão local
        const isCredentialError =
          errorMsg.includes("Usuário") ||
          errorMsg.includes("senha") ||
          errorMsg.includes("incorretos") ||
          errorMsg.includes("não encontrado") ||
          errorMsg.includes("incorreta") ||
          errorMsg.includes("inválid");

        if (isCredentialError) {
          return { success: false, error: errorMsg };
        }

        // Erro de rede/conexão — tentar sessão salva localmente como fallback
        try {
          const raw = await AsyncStorage.getItem(SESSION_KEY);
          if (raw) {
            const savedUser: User = JSON.parse(raw);
            if (
              savedUser.username === trimmedUsername &&
              savedUser.password === password
            ) {
              setState({ user: savedUser, isLoading: false, isAuthenticated: true });
              return { success: true };
            }
          }
        } catch {
          // Ignorar erros de leitura do cache
        }

        // Verificar se é um erro de timeout ou rede
        const isNetworkError =
          errorMsg.toLowerCase().includes("timeout") ||
          errorMsg.toLowerCase().includes("network") ||
          errorMsg.toLowerCase().includes("econnrefused") ||
          errorMsg.toLowerCase().includes("enotfound") ||
          errorMsg.toLowerCase().includes("failed to fetch");

        if (isNetworkError) {
          return {
            success: false,
            error: "Não foi possível conectar ao servidor. Verifique sua conexão com a internet.",
          };
        }

        return {
          success: false,
          error: errorMsg || "Erro ao fazer login. Tente novamente.",
        };
      }
    },
    []
  );

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem(SESSION_KEY);
    setState({ user: null, isLoading: false, isAuthenticated: false });
  }, []);

  const refreshUser = useCallback(async () => {
    if (!state.user) return;
    try {
      // Buscar dados atualizados do servidor
      const drivers = await apiClient.getDrivers();
      const fresh = drivers.find((d: any) => d.id === state.user!.id);
      if (fresh) {
        const updatedUser: User = {
          ...state.user,
          name: fresh.name,
          whatsapp: fresh.whatsapp,
          photoUri: fresh.photoUri,
          isSuspended: fresh.isSuspended,
        };
        await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(updatedUser));
        setState((prev) => ({ ...prev, user: updatedUser }));
      }
    } catch {
      // Ignorar erros de refresh
    }
  }, [state.user]);

  return (
    <AuthContext.Provider value={{ ...state, login, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
