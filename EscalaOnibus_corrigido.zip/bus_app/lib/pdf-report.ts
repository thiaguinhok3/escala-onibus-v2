import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { Platform } from "react-native";
import type { Schedule, User, WorkdayPunches } from "./database";

function formatDate(dateStr: string): string {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-");
  return `${d}/${m}/${y}`;
}

function getMonthName(month: string): string {
  const months = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
  ];
  return months[parseInt(month, 10) - 1] ?? month;
}

function statusLabel(status: string): string {
  switch (status) {
    case "approved": return "Aprovada";
    case "denied": return "Negada";
    default: return "Pendente";
  }
}

function statusColor(status: string): string {
  switch (status) {
    case "approved": return "#16a34a";
    case "denied": return "#dc2626";
    default: return "#d97706";
  }
}

function statusBg(status: string): string {
  switch (status) {
    case "approved": return "#dcfce7";
    case "denied": return "#fee2e2";
    default: return "#fef3c7";
  }
}

/**
 * Generate HTML for the PDF report.
 */
function buildReportHTML(params: {
  schedules: Schedule[];
  drivers: User[];
  filterDriver: User | null;
  periodLabel: string;
  generatedAt: string;
}): string {
  const { schedules, filterDriver, periodLabel, generatedAt } = params;

  const totalApproved = schedules.filter((s) => s.status === "approved").length;
  const totalPending = schedules.filter((s) => s.status === "pending").length;
  const totalDenied = schedules.filter((s) => s.status === "denied").length;

  const rows = schedules
    .sort((a, b) => a.date.localeCompare(b.date))
    .map(
      (s) => `
      <tr>
        <td>${formatDate(s.date)}</td>
        <td>${s.driverName}</td>
        <td>${s.line}</td>
        <td>${s.busModel}</td>
        <td>${s.busPrefix}</td>
        <td>${s.startTime} – ${s.endTime}</td>
        <td>
          <span style="
            background:${statusBg(s.status)};
            color:${statusColor(s.status)};
            padding:2px 8px;
            border-radius:4px;
            font-weight:600;
            font-size:11px;
          ">${statusLabel(s.status)}</span>
        </td>
        <td>${s.confirmedAt ? "✓ Sim" : "—"}</td>
      </tr>
    `
    )
    .join("");

  return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Relatório de Escalas — EscalaOnibus</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      color: #1e293b;
      background: #fff;
      padding: 32px;
      font-size: 13px;
    }
    .header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 3px solid #1A56DB;
      padding-bottom: 16px;
      margin-bottom: 24px;
    }
    .header-left h1 {
      font-size: 22px;
      font-weight: 800;
      color: #1A56DB;
    }
    .header-left p {
      font-size: 13px;
      color: #64748b;
      margin-top: 4px;
    }
    .header-right {
      text-align: right;
      font-size: 11px;
      color: #94a3b8;
    }
    .meta {
      display: flex;
      gap: 12px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }
    .meta-item {
      background: #f1f5f9;
      border-radius: 8px;
      padding: 10px 16px;
      flex: 1;
      min-width: 120px;
    }
    .meta-item .label {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #64748b;
      font-weight: 600;
    }
    .meta-item .value {
      font-size: 20px;
      font-weight: 800;
      margin-top: 2px;
    }
    .meta-item.approved .value { color: #16a34a; }
    .meta-item.pending .value { color: #d97706; }
    .meta-item.denied .value { color: #dc2626; }
    .meta-item.total .value { color: #1A56DB; }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 8px;
    }
    thead tr {
      background: #1A56DB;
      color: #fff;
    }
    thead th {
      padding: 10px 8px;
      text-align: left;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    tbody tr:nth-child(even) { background: #f8fafc; }
    tbody tr:hover { background: #eff6ff; }
    tbody td {
      padding: 9px 8px;
      border-bottom: 1px solid #e2e8f0;
      font-size: 12px;
    }
    .footer {
      margin-top: 24px;
      border-top: 1px solid #e2e8f0;
      padding-top: 12px;
      font-size: 11px;
      color: #94a3b8;
      text-align: center;
    }
    @media print {
      body { padding: 16px; }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="header-left">
      <h1>EscalaOnibus</h1>
      <p>Relatório de Escalas${filterDriver ? ` — ${filterDriver.name}` : ""}</p>
      <p style="margin-top:2px;font-size:12px;color:#1A56DB;font-weight:600;">${periodLabel}</p>
    </div>
    <div class="header-right">
      <div>Gerado em</div>
      <div style="font-weight:600;color:#1e293b;">${generatedAt}</div>
    </div>
  </div>

  <div class="meta">
    <div class="meta-item total">
      <div class="label">Total</div>
      <div class="value">${schedules.length}</div>
    </div>
    <div class="meta-item approved">
      <div class="label">Aprovadas</div>
      <div class="value">${totalApproved}</div>
    </div>
    <div class="meta-item pending">
      <div class="label">Pendentes</div>
      <div class="value">${totalPending}</div>
    </div>
    <div class="meta-item denied">
      <div class="label">Negadas</div>
      <div class="value">${totalDenied}</div>
    </div>
  </div>

  ${
    schedules.length === 0
      ? `<div style="text-align:center;padding:40px;color:#94a3b8;">Nenhuma escala encontrada para o período selecionado.</div>`
      : `
  <table>
    <thead>
      <tr>
        <th>Data</th>
        <th>Motorista</th>
        <th>Linha</th>
        <th>Modelo</th>
        <th>Prefixo</th>
        <th>Horário</th>
        <th>Status</th>
        <th>Confirmada</th>
      </tr>
    </thead>
    <tbody>
      ${rows}
    </tbody>
  </table>
  `
  }

  <div class="footer">
    EscalaOnibus v1.1 · Relatório gerado automaticamente em ${generatedAt}
  </div>
</body>
</html>
  `.trim();
}

export interface ReportParams {
  schedules: Schedule[];
  drivers: User[];
  filterDriver: User | null;
  periodLabel: string;
}

/**
 * Generate a PDF from the schedules and open the share sheet.
 */
// ─── Punch Report ────────────────────────────────────────────────────────────

function formatTime(isoStr: string): string {
  if (!isoStr) return "—";
  const d = new Date(isoStr);
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

function calcWorkDuration(wp: WorkdayPunches): string {
  if (!wp.start) return "—";
  const endTime = wp.end?.timestamp ?? new Date().toISOString();
  const totalMs = new Date(endTime).getTime() - new Date(wp.start.timestamp).getTime();
  let breakMs = 0;
  if (wp.breakStart && wp.breakEnd) {
    breakMs = new Date(wp.breakEnd.timestamp).getTime() - new Date(wp.breakStart.timestamp).getTime();
  }
  const workMs = Math.max(0, totalMs - breakMs);
  const totalMin = Math.floor(workMs / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return `${h}h ${String(m).padStart(2, "0")}min`;
}

function buildPunchReportHTML(params: {
  workdays: WorkdayPunches[];
  drivers: User[];
  filterDriver: User | null;
  periodLabel: string;
  generatedAt: string;
}): string {
  const { workdays, filterDriver, periodLabel, generatedAt } = params;

  const complete = workdays.filter((w) => w.end).length;
  const incomplete = workdays.filter((w) => w.start && !w.end).length;

  const rows = workdays
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((w) => `
      <tr>
        <td>${formatDate(w.date)}</td>
        <td>${w.driverName}</td>
        <td>${w.start ? formatTime(w.start.timestamp) : "—"}</td>
        <td>${w.breakStart ? formatTime(w.breakStart.timestamp) : "—"}</td>
        <td>${w.breakEnd ? formatTime(w.breakEnd.timestamp) : "—"}</td>
        <td>${w.end ? formatTime(w.end.timestamp) : "—"}</td>
        <td style="font-weight:700;">${calcWorkDuration(w)}</td>
        <td>
          <span style="background:${w.end ? "#dcfce7" : "#fef3c7"};color:${w.end ? "#16a34a" : "#d97706"};padding:2px 8px;border-radius:4px;font-weight:600;font-size:11px;">
            ${w.end ? "Completo" : "Em andamento"}
          </span>
        </td>
      </tr>
    `).join("");

  return `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>Relatório de Ponto — EscalaOnibus</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #1e293b; background: #fff; padding: 32px; font-size: 13px; }
    .header { display: flex; align-items: center; justify-content: space-between; border-bottom: 3px solid #1A56DB; padding-bottom: 16px; margin-bottom: 24px; }
    .header-left h1 { font-size: 22px; font-weight: 800; color: #1A56DB; }
    .header-left p { font-size: 13px; color: #64748b; margin-top: 4px; }
    .header-right { text-align: right; font-size: 11px; color: #94a3b8; }
    .meta { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
    .meta-item { background: #f1f5f9; border-radius: 8px; padding: 10px 16px; flex: 1; min-width: 120px; }
    .meta-item .label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; font-weight: 600; }
    .meta-item .value { font-size: 20px; font-weight: 800; margin-top: 2px; }
    .meta-item.complete .value { color: #16a34a; }
    .meta-item.incomplete .value { color: #d97706; }
    .meta-item.total .value { color: #1A56DB; }
    table { width: 100%; border-collapse: collapse; margin-top: 8px; }
    thead tr { background: #1A56DB; color: #fff; }
    thead th { padding: 10px 8px; text-align: left; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; }
    tbody tr:nth-child(even) { background: #f8fafc; }
    tbody td { padding: 9px 8px; border-bottom: 1px solid #e2e8f0; font-size: 12px; }
    .footer { margin-top: 24px; border-top: 1px solid #e2e8f0; padding-top: 12px; font-size: 11px; color: #94a3b8; text-align: center; }
  </style>
</head>
<body>
  <div class="header">
    <div class="header-left">
      <h1>EscalaOnibus</h1>
      <p>Relatório de Ponto Eletrônico${filterDriver ? ` — ${filterDriver.name}` : ""}</p>
      <p style="margin-top:2px;font-size:12px;color:#1A56DB;font-weight:600;">${periodLabel}</p>
    </div>
    <div class="header-right">
      <div>Gerado em</div>
      <div style="font-weight:600;color:#1e293b;">${generatedAt}</div>
    </div>
  </div>
  <div class="meta">
    <div class="meta-item total"><div class="label">Total de Dias</div><div class="value">${workdays.length}</div></div>
    <div class="meta-item complete"><div class="label">Completos</div><div class="value">${complete}</div></div>
    <div class="meta-item incomplete"><div class="label">Em andamento</div><div class="value">${incomplete}</div></div>
  </div>
  ${workdays.length === 0
    ? `<div style="text-align:center;padding:40px;color:#94a3b8;">Nenhum registro de ponto encontrado.</div>`
    : `<table>
    <thead><tr>
      <th>Data</th><th>Motorista</th><th>Início</th><th>Pausa</th><th>Retorno</th><th>Término</th><th>Jornada</th><th>Status</th>
    </tr></thead>
    <tbody>${rows}</tbody>
  </table>`}
  <div class="footer">EscalaOnibus · Relatório de Ponto gerado em ${generatedAt}</div>
</body>
</html>`.trim();
}

export interface PunchReportParams {
  workdays: WorkdayPunches[];
  drivers: User[];
  filterDriver: User | null;
  periodLabel: string;
}

export async function exportPunchPDF(params: PunchReportParams): Promise<void> {
  const now = new Date();
  const generatedAt = now.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  const html = buildPunchReportHTML({ ...params, generatedAt });
  const { uri } = await Print.printToFileAsync({ html, base64: false });
  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(uri, { mimeType: "application/pdf", dialogTitle: "Compartilhar Relatório de Ponto", UTI: "com.adobe.pdf" });
  } else if (Platform.OS === "web") {
    const link = document.createElement("a");
    link.href = uri;
    link.download = `ponto-${now.toISOString().split("T")[0]}.pdf`;
    link.click();
  }
}

// ─── Schedule Report ──────────────────────────────────────────────────────────

export async function exportSchedulesPDF(params: ReportParams): Promise<void> {
  const now = new Date();
  const generatedAt = now.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const html = buildReportHTML({ ...params, generatedAt });

  const { uri } = await Print.printToFileAsync({
    html,
    base64: false,
  });

  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(uri, {
      mimeType: "application/pdf",
      dialogTitle: "Compartilhar Relatório de Escalas",
      UTI: "com.adobe.pdf",
    });
  } else if (Platform.OS === "web") {
    // On web, open the PDF in a new tab
    const link = document.createElement("a");
    link.href = uri;
    link.download = `escalas-${now.toISOString().split("T")[0]}.pdf`;
    link.click();
  }
}
