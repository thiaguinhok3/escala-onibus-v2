CREATE TABLE `cnhRecords` (
	`id` varchar(36) NOT NULL,
	`driverId` varchar(36) NOT NULL,
	`number` varchar(20) NOT NULL,
	`category` varchar(10) NOT NULL,
	`expiryDate` varchar(10) NOT NULL,
	`totalPoints` int DEFAULT 40,
	`usedPoints` int DEFAULT 0,
	`status` enum('active','suspended','blocked') DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cnhRecords_id` PRIMARY KEY(`id`),
	CONSTRAINT `cnhRecords_number_unique` UNIQUE(`number`)
);
--> statement-breakpoint
CREATE TABLE `drivers` (
	`id` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`whatsapp` varchar(20),
	`driverId` varchar(50) NOT NULL,
	`username` varchar(100) NOT NULL,
	`password` varchar(255) NOT NULL,
	`status` enum('active','inactive','suspended') DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `drivers_id` PRIMARY KEY(`id`),
	CONSTRAINT `drivers_driverId_unique` UNIQUE(`driverId`),
	CONSTRAINT `drivers_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
CREATE TABLE `fines` (
	`id` varchar(36) NOT NULL,
	`driverId` varchar(36) NOT NULL,
	`cnhId` varchar(36) NOT NULL,
	`type` varchar(50) NOT NULL,
	`description` text,
	`points` int NOT NULL,
	`value` int,
	`date` varchar(10) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `fines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `occurrences` (
	`id` varchar(36) NOT NULL,
	`driverId` varchar(36) NOT NULL,
	`type` varchar(100) NOT NULL,
	`description` text,
	`date` varchar(10) NOT NULL,
	`viewed` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `occurrences_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `punches` (
	`id` varchar(36) NOT NULL,
	`driverId` varchar(36) NOT NULL,
	`scheduleId` varchar(36),
	`type` enum('start','break_start','break_end','end') NOT NULL,
	`timestamp` varchar(30) NOT NULL,
	`note` text,
	`photoUrl` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `punches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `schedules` (
	`id` varchar(36) NOT NULL,
	`driverId` varchar(36) NOT NULL,
	`date` varchar(10) NOT NULL,
	`line` varchar(50) NOT NULL,
	`busModel` varchar(100),
	`busPrefix` varchar(50),
	`startTime` varchar(5) NOT NULL,
	`endTime` varchar(5) NOT NULL,
	`status` enum('pending','approved','denied') DEFAULT 'pending',
	`denyReason` text,
	`scheduleType` enum('work','vacation','off') DEFAULT 'work',
	`observations` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `schedules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trainings` (
	`id` varchar(36) NOT NULL,
	`driverId` varchar(36) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`requiredHours` int,
	`status` enum('pending','in_progress','completed','approved') DEFAULT 'pending',
	`approvedBy` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trainings_id` PRIMARY KEY(`id`)
);
