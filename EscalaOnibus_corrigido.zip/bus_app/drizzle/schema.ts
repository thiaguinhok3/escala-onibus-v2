import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Drivers table
export const drivers = mysqlTable("drivers", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  whatsapp: varchar("whatsapp", { length: 20 }),
  driverId: varchar("driverId", { length: 50 }).notNull().unique(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["active", "inactive", "suspended"]).default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Driver = typeof drivers.$inferSelect;
export type InsertDriver = typeof drivers.$inferInsert;

// Schedules table
export const schedules = mysqlTable("schedules", {
  id: varchar("id", { length: 36 }).primaryKey(),
  driverId: varchar("driverId", { length: 36 }).notNull(),
  date: varchar("date", { length: 10 }).notNull(),
  line: varchar("line", { length: 50 }).notNull(),
  busModel: varchar("busModel", { length: 100 }),
  busPrefix: varchar("busPrefix", { length: 50 }),
  startTime: varchar("startTime", { length: 5 }).notNull(),
  endTime: varchar("endTime", { length: 5 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "denied"]).default("pending"),
  denyReason: text("denyReason"),
  scheduleType: mysqlEnum("scheduleType", ["work", "vacation", "off"]).default("work"),
  observations: text("observations"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Schedule = typeof schedules.$inferSelect;
export type InsertSchedule = typeof schedules.$inferInsert;

// CNH table
export const cnhRecords = mysqlTable("cnhRecords", {
  id: varchar("id", { length: 36 }).primaryKey(),
  driverId: varchar("driverId", { length: 36 }).notNull(),
  number: varchar("number", { length: 20 }).notNull().unique(),
  category: varchar("category", { length: 10 }).notNull(),
  expiryDate: varchar("expiryDate", { length: 10 }).notNull(),
  totalPoints: int("totalPoints").default(40),
  usedPoints: int("usedPoints").default(0),
  status: mysqlEnum("status", ["active", "suspended", "blocked"]).default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CNHRecord = typeof cnhRecords.$inferSelect;
export type InsertCNHRecord = typeof cnhRecords.$inferInsert;

// Fines table
export const fines = mysqlTable("fines", {
  id: varchar("id", { length: 36 }).primaryKey(),
  driverId: varchar("driverId", { length: 36 }).notNull(),
  cnhId: varchar("cnhId", { length: 36 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  description: text("description"),
  points: int("points").notNull(),
  value: int("value"),
  date: varchar("date", { length: 10 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Fine = typeof fines.$inferSelect;
export type InsertFine = typeof fines.$inferInsert;

// Trainings table
export const trainings = mysqlTable("trainings", {
  id: varchar("id", { length: 36 }).primaryKey(),
  driverId: varchar("driverId", { length: 36 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  requiredHours: int("requiredHours"),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "approved"]).default("pending"),
  approvedBy: varchar("approvedBy", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Training = typeof trainings.$inferSelect;
export type InsertTraining = typeof trainings.$inferInsert;

// Punches table
export const punches = mysqlTable("punches", {
  id: varchar("id", { length: 36 }).primaryKey(),
  driverId: varchar("driverId", { length: 36 }).notNull(),
  scheduleId: varchar("scheduleId", { length: 36 }),
  type: mysqlEnum("type", ["start", "break_start", "break_end", "end"]).notNull(),
  timestamp: varchar("timestamp", { length: 30 }).notNull(),
  note: text("note"),
  photoUrl: varchar("photoUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Punch = typeof punches.$inferSelect;
export type InsertPunch = typeof punches.$inferInsert;

// Occurrences table
export const occurrences = mysqlTable("occurrences", {
  id: varchar("id", { length: 36 }).primaryKey(),
  driverId: varchar("driverId", { length: 36 }).notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  description: text("description"),
  date: varchar("date", { length: 10 }).notNull(),
  viewed: int("viewed").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Occurrence = typeof occurrences.$inferSelect;
export type InsertOccurrence = typeof occurrences.$inferInsert;
