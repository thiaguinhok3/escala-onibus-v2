/** @type {const} */
const themeColors = {
  primary: { light: '#1A56DB', dark: '#3B82F6' },
  background: { light: '#F8FAFC', dark: '#0F172A' },
  surface: { light: '#FFFFFF', dark: '#1E293B' },
  foreground: { light: '#1E293B', dark: '#F1F5F9' },
  muted: { light: '#64748B', dark: '#94A3B8' },
  border: { light: '#E2E8F0', dark: '#334155' },
  success: { light: '#16A34A', dark: '#4ADE80' },
  warning: { light: '#D97706', dark: '#FBBF24' },
  error: { light: '#DC2626', dark: '#F87171' },
  tint: { light: '#1A56DB', dark: '#3B82F6' },
};

module.exports = { themeColors };
