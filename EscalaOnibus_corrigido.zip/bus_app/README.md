# EscalaOnibus - Sistema de Gestão de Escalas de Motoristas

Aplicativo mobile (Expo/React Native) para gerenciamento de escalas de motoristas de ônibus, com sincronização em tempo real via API em nuvem (PostgreSQL/Neon).

## 🚀 Características

- ✅ **Autenticação em Nuvem**: Login via API remota com fallback local para sessões salvas
- ✅ **Múltiplos Usuários**: Suporte para Admin e Motoristas
- ✅ **Escalas Remotas**: Criar, editar, aprovar e negar escalas
- ✅ **Ponto Eletrônico**: Registro de entrada/saída com foto
- ✅ **Ocorrências**: Registro de problemas durante o turno
- ✅ **CNH Virtual**: Gestão de carteira de habilitação fictícia
- ✅ **Multas e Pontos**: Sistema de pontuação e infrações
- ✅ **Dashboard**: Estatísticas e relatórios para admin
- ✅ **Acesso Remoto**: Funciona em qualquer lugar com internet

---

## 📋 Pré-requisitos

- Node.js 18+ e pnpm
- Expo CLI (`npm install -g expo-cli`)
- PostgreSQL em nuvem (Neon.tech) — já configurado
- Conta no Render.com para deploy do backend

---

## 🔧 Instalação Local

### 1. Instalar dependências

```bash
pnpm install
```

### 2. Configurar variáveis de ambiente

Crie o arquivo `.env` na raiz do projeto:

```env
DATABASE_URL=postgresql://neondb_owner:npg_Sx7rIvH1uWNA@ep-aged-feather-amazlq0g.c-5.us-east-1.aws.neon.tech/neondb?sslmode=require
PORT=3000
NODE_ENV=development
```

> **Nota:** A variável `EXPO_PUBLIC_API_URL` é opcional. O app detecta automaticamente a URL correta:
> - No emulador/web local: usa `http://localhost:3000`
> - No Vercel/Render: usa a mesma origem (URL relativa `/api`)
> - Se quiser forçar uma URL específica: `EXPO_PUBLIC_API_URL=https://seu-app.onrender.com`

### 3. Executar em modo desenvolvimento

```bash
pnpm run dev
```

Isso inicia:
- Backend em `http://localhost:3000`
- Metro bundler para o app mobile em `http://localhost:8081`

---

## 🏃 Executar Localmente

```bash
# Frontend + Backend juntos
pnpm run dev

# Apenas Backend
pnpm run dev:server

# Apenas Frontend
pnpm run dev:metro
```

---

## 📱 Testar no Celular

### Via Expo Go

1. Instale o app **Expo Go** no seu celular (iOS/Android)
2. Execute `pnpm run qr` para gerar QR code
3. Escaneie o QR code com a câmera ou Expo Go

> **Importante:** Para testar no celular físico, defina `EXPO_PUBLIC_API_URL` com o IP da sua máquina:
> ```env
> EXPO_PUBLIC_API_URL=http://192.168.1.X:3000
> ```

### Via Emulador

```bash
pnpm run android    # Android Emulator
pnpm run ios        # iOS Simulator (macOS only)
```

---

## 🚀 Deploy no Render (Recomendado)

O projeto já está configurado com `render.yaml`. Siga os passos:

1. Crie uma conta em [render.com](https://render.com)
2. Conecte seu repositório GitHub
3. Crie um novo **Web Service** e selecione o repositório
4. O Render detectará automaticamente o `render.yaml`
5. Configure a variável de ambiente `DATABASE_URL` no painel do Render

Após o deploy, o backend estará disponível em `https://escalaonibus-api.onrender.com`.

**Para o app mobile apontar para o Render:**
Defina `EXPO_PUBLIC_API_URL=https://escalaonibus-api.onrender.com` no `.env.production`.

---

## 🚀 Deploy no Vercel (Alternativo)

O projeto inclui `vercel.json` para deploy no Vercel.

1. Instale a Vercel CLI: `npm i -g vercel`
2. Execute `vercel` na pasta `bus_app`
3. Configure a variável de ambiente `DATABASE_URL` no painel do Vercel

---

## 👤 Usuários Padrão

| Usuário | Senha     | Papel          |
|---------|-----------|----------------|
| admin   | admin123  | Administrador  |

> Novos motoristas devem ser criados pelo admin na aba **Motoristas**.

---

## 📊 Estrutura do Projeto

```
bus_app/
├── app/                    # Telas do app (Expo Router)
│   ├── (admin)/           # Telas do administrador
│   ├── (driver)/          # Telas do motorista
│   ├── (auth)/            # Telas de autenticação
│   └── index.tsx          # Roteamento principal
├── server/                # Backend Node.js/Express
│   ├── api.ts             # Rotas da API (PostgreSQL)
│   ├── simple-api.ts      # Rotas auxiliares
│   └── _core/index.ts     # Inicialização do servidor
├── api/
│   └── server.ts          # Serverless function (Vercel)
├── lib/                   # Utilitários
│   ├── api-client.ts      # Cliente HTTP (URL dinâmica)
│   ├── auth-context.tsx   # Contexto de autenticação
│   └── database.ts        # Tipos TypeScript
├── render.yaml            # Configuração do Render
├── vercel.json            # Configuração do Vercel
└── package.json
```

---

## 🐛 Troubleshooting

### Motorista criado pelo admin não consegue fazer login

**Causa:** O app estava usando armazenamento em memória (`simple-api.ts`) que era zerado a cada reinício do servidor, em vez do banco PostgreSQL.

**Solução aplicada:** A `simple-api.ts` foi corrigida para não duplicar as rotas de autenticação. Agora **todas** as operações usam o PostgreSQL via `api.ts`.

### App mostra "Sem conexão com o servidor"

1. Verifique se o backend está rodando: `pnpm run dev:server`
2. No celular físico, defina `EXPO_PUBLIC_API_URL` com o IP da sua máquina
3. Em produção, verifique se a URL do Render/Vercel está correta
4. Verifique se a variável `DATABASE_URL` está configurada no servidor

### Erro de conexão com banco de dados

Verifique se a URL do PostgreSQL está correta:

```bash
psql "postgresql://neondb_owner:PASSWORD@ep-aged-feather-amazlq0g.c-5.us-east-1.aws.neon.tech/neondb?sslmode=require"
```

### Erro ao fazer build

```bash
pnpm install --force
pnpm run check  # Verificar tipos TypeScript
pnpm run build  # Build do servidor
```

---

## 📞 Suporte

Para suporte, entre em contato via WhatsApp: **(19) 99560-5536**

## 📄 Licença

Propriedade privada — Todos os direitos reservados

---

**Desenvolvido com ❤️ para EscalaOnibus**
