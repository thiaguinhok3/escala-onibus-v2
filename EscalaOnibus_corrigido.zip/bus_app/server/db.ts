import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  InsertDriver,
  drivers,
  InsertSchedule,
  schedules,
  InsertCNHRecord,
  cnhRecords,
  InsertFine,
  fines,
  InsertTraining,
  trainings,
  InsertPunch,
  punches,
  InsertOccurrence,
  occurrences,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ─── Drivers ──────────────────────────────────────────────────────────────

export async function createDriver(data: InsertDriver) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(drivers).values(data);
}

export async function getDriverByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(drivers).where(eq(drivers.username, username)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getDriverById(id: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(drivers).where(eq(drivers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllDrivers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(drivers);
}

export async function updateDriver(id: string, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(drivers).set(data).where(eq(drivers.id, id));
  return { success: true };
}

// ─── Schedules ────────────────────────────────────────────────────────────

export async function createSchedule(data: InsertSchedule) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(schedules).values(data);
}

export async function getSchedulesByDriver(driverId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(schedules).where(eq(schedules.driverId, driverId));
}

export async function getSchedulesByDate(date: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(schedules).where(eq(schedules.date, date));
}

export async function updateSchedule(id: string, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(schedules).set(data).where(eq(schedules.id, id));
  return { success: true };
}

export async function deleteSchedule(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(schedules).where(eq(schedules.id, id));
}

// ─── CNH Records ───────────────────────────────────────────────────────────

export async function createCNH(data: InsertCNHRecord) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(cnhRecords).values(data);
}

export async function getCNHByDriver(driverId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(cnhRecords).where(eq(cnhRecords.driverId, driverId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateCNH(id: string, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(cnhRecords).set(data).where(eq(cnhRecords.id, id));
  return { success: true };
}

// ─── Fines ────────────────────────────────────────────────────────────────

export async function createFine(data: InsertFine) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(fines).values(data);
}

export async function getFinesByDriver(driverId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(fines).where(eq(fines.driverId, driverId));
}

// ─── Trainings ────────────────────────────────────────────────────────────

export async function createTraining(data: InsertTraining) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(trainings).values(data);
}

export async function getTrainingsByDriver(driverId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(trainings).where(eq(trainings.driverId, driverId));
}

export async function updateTraining(id: string, data: Partial<InsertTraining>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(trainings).set(data).where(eq(trainings.id, id));
}

// ─── Punches ──────────────────────────────────────────────────────────────

export async function createPunch(data: InsertPunch) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(punches).values(data);
}

export async function getPunchesByDriver(driverId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(punches).where(eq(punches.driverId, driverId));
}

export async function getPunchesByDate(date: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(punches).where(eq(punches.timestamp, date));
}

// ─── Occurrences ──────────────────────────────────────────────────────────

export async function createOccurrence(data: InsertOccurrence) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(occurrences).values(data);
}

export async function getOccurrencesByDriver(driverId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(occurrences).where(eq(occurrences.driverId, driverId));
}
