import express, { Request, Response } from "express";
import { Pool } from "pg";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || "postgresql://postgres:postgres@localhost:5432/escalaonibus",
  ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false,
  connectionTimeoutMillis: 10000,
  idleTimeoutMillis: 30000,
  max: 10,
});

export const setupAPI = (app: express.Application) => {

  // ─── Auth API ──────────────────────────────────────────────────────────

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ error: "Usuário e senha são obrigatórios" });
      }
      const result = await pool.query(
        "SELECT * FROM users WHERE username = $1 AND password = $2",
        [username.toLowerCase().trim(), password]
      );
      if (result.rows.length === 0) {
        return res.status(401).json({ error: "Usuário ou senha incorretos" });
      }
      const user = result.rows[0];
      res.json({
        id: user.id,
        name: user.name,
        username: user.username,
        driverId: user.driver_id,
        role: user.role,
        whatsapp: user.whatsapp,
        photoUri: user.photo_uri,
        isSuspended: user.is_suspended,
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Erro ao fazer login" });
    }
  });

  // ─── Drivers API ───────────────────────────────────────────────────────

  app.get("/api/drivers", async (_req: Request, res: Response) => {
    try {
      const result = await pool.query(
        "SELECT id, name, username, driver_id, whatsapp, photo_uri, is_suspended, role, created_at FROM users WHERE role = 'driver' ORDER BY name ASC"
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        name: r.name,
        username: r.username,
        driverId: r.driver_id,
        whatsapp: r.whatsapp,
        photoUri: r.photo_uri,
        isSuspended: r.is_suspended,
        role: r.role,
        createdAt: r.created_at,
      })));
    } catch (error) {
      console.error("Error fetching drivers:", error);
      res.status(500).json({ error: "Erro ao buscar motoristas" });
    }
  });

  app.get("/api/drivers/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const result = await pool.query(
        "SELECT id, name, username, driver_id, whatsapp, photo_uri, is_suspended, role FROM users WHERE id = $1",
        [id]
      );
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Motorista não encontrado" });
      }
      const r = result.rows[0];
      res.json({
        id: r.id,
        name: r.name,
        username: r.username,
        driverId: r.driver_id,
        whatsapp: r.whatsapp,
        photoUri: r.photo_uri,
        isSuspended: r.is_suspended,
        role: r.role,
      });
    } catch (error) {
      console.error("Error fetching driver:", error);
      res.status(500).json({ error: "Erro ao buscar motorista" });
    }
  });

  app.post("/api/drivers", async (req: Request, res: Response) => {
    try {
      const { name, username, password, driverId, whatsapp } = req.body;
      if (!name || !username || !password) {
        return res.status(400).json({ error: "Nome, usuário e senha são obrigatórios" });
      }
      const result = await pool.query(
        "INSERT INTO users (name, username, password, driver_id, whatsapp, role) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
        [name.trim(), username.toLowerCase().trim(), password, driverId?.trim() || null, whatsapp?.trim() || null, "driver"]
      );
      const r = result.rows[0];
      res.json({
        id: r.id,
        name: r.name,
        username: r.username,
        driverId: r.driver_id,
        whatsapp: r.whatsapp,
        role: r.role,
      });
    } catch (error: any) {
      console.error("Error creating driver:", error);
      if (error.code === "23505") {
        return res.status(400).json({ error: "Usuário já existe" });
      }
      res.status(500).json({ error: "Erro ao criar motorista" });
    }
  });

  app.put("/api/drivers/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { name, password, whatsapp, photoUri, driverId, isSuspended } = req.body;
      const result = await pool.query(
        `UPDATE users SET 
          name = COALESCE($1, name), 
          password = COALESCE($2, password), 
          whatsapp = COALESCE($3, whatsapp), 
          photo_uri = COALESCE($4, photo_uri),
          driver_id = COALESCE($5, driver_id),
          is_suspended = COALESCE($6, is_suspended),
          updated_at = CURRENT_TIMESTAMP 
        WHERE id = $7 RETURNING *`,
        [name || null, password || null, whatsapp || null, photoUri || null, driverId || null, isSuspended !== undefined ? isSuspended : null, id]
      );
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Motorista não encontrado" });
      }
      const r = result.rows[0];
      res.json({
        id: r.id,
        name: r.name,
        username: r.username,
        driverId: r.driver_id,
        whatsapp: r.whatsapp,
        photoUri: r.photo_uri,
        isSuspended: r.is_suspended,
        role: r.role,
      });
    } catch (error) {
      console.error("Error updating driver:", error);
      res.status(500).json({ error: "Erro ao atualizar motorista" });
    }
  });

  app.delete("/api/drivers/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      await pool.query("DELETE FROM users WHERE id = $1 AND role = 'driver'", [id]);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting driver:", error);
      res.status(500).json({ error: "Erro ao excluir motorista" });
    }
  });

  // ─── Schedules API ─────────────────────────────────────────────────────

  app.get("/api/schedules", async (req: Request, res: Response) => {
    try {
      const { date } = req.query;
      let query = `
        SELECT s.*, u.name as driver_name, u.driver_id as driver_code 
        FROM schedules s 
        LEFT JOIN users u ON s.driver_id = u.id
      `;
      const params: any[] = [];
      if (date) {
        query += " WHERE s.date = $1";
        params.push(date);
      }
      query += " ORDER BY s.date DESC, s.start_time ASC";
      const result = await pool.query(query, params);
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        driverName: r.driver_name,
        driverCode: r.driver_code,
        date: r.date,
        line: r.line,
        busModel: r.bus_model,
        busPrefix: r.bus_prefix,
        startTime: r.start_time,
        endTime: r.end_time,
        scheduleType: r.schedule_type,
        observations: r.observations,
        status: r.status,
        denyReason: r.deny_reason,
        confirmedAt: r.confirmed_at,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      })));
    } catch (error) {
      console.error("Error fetching schedules:", error);
      res.status(500).json({ error: "Erro ao buscar escalas" });
    }
  });

  app.get("/api/schedules/driver/:driverId", async (req: Request, res: Response) => {
    try {
      const { driverId } = req.params;
      const result = await pool.query(
        `SELECT s.*, u.name as driver_name 
         FROM schedules s 
         LEFT JOIN users u ON s.driver_id = u.id
         WHERE s.driver_id = $1 ORDER BY s.date DESC`,
        [driverId]
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        driverName: r.driver_name,
        date: r.date,
        line: r.line,
        busModel: r.bus_model,
        busPrefix: r.bus_prefix,
        startTime: r.start_time,
        endTime: r.end_time,
        scheduleType: r.schedule_type,
        observations: r.observations,
        status: r.status,
        denyReason: r.deny_reason,
        confirmedAt: r.confirmed_at,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      })));
    } catch (error) {
      console.error("Error fetching driver schedules:", error);
      res.status(500).json({ error: "Erro ao buscar escalas do motorista" });
    }
  });

  app.post("/api/schedules", async (req: Request, res: Response) => {
    try {
      const { driverId, date, line, busModel, busPrefix, startTime, endTime, scheduleType, observations } = req.body;
      if (!driverId || !date || !line || !startTime || !endTime) {
        return res.status(400).json({ error: "Campos obrigatórios: motorista, data, linha, horários" });
      }
      const result = await pool.query(
        `INSERT INTO schedules (driver_id, date, line, bus_model, bus_prefix, start_time, end_time, schedule_type, observations) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
        [driverId, date, line, busModel || null, busPrefix || null, startTime, endTime, scheduleType || "work", observations || null]
      );
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        date: r.date,
        line: r.line,
        busModel: r.bus_model,
        busPrefix: r.bus_prefix,
        startTime: r.start_time,
        endTime: r.end_time,
        scheduleType: r.schedule_type,
        observations: r.observations,
        status: r.status,
        createdAt: r.created_at,
      });
    } catch (error: any) {
      console.error("Error creating schedule:", error);
      if (error.code === "23505") {
        return res.status(400).json({ error: "Já existe uma escala para este motorista nesta data" });
      }
      res.status(500).json({ error: "Erro ao criar escala" });
    }
  });

  app.put("/api/schedules/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { status, denyReason, confirmedAt, line, busModel, busPrefix, startTime, endTime, observations, scheduleType } = req.body;
      const result = await pool.query(
        `UPDATE schedules SET 
          status = COALESCE($1, status), 
          deny_reason = COALESCE($2, deny_reason), 
          confirmed_at = COALESCE($3, confirmed_at),
          line = COALESCE($4, line),
          bus_model = COALESCE($5, bus_model),
          bus_prefix = COALESCE($6, bus_prefix),
          start_time = COALESCE($7, start_time),
          end_time = COALESCE($8, end_time),
          observations = COALESCE($9, observations),
          schedule_type = COALESCE($10, schedule_type),
          updated_at = CURRENT_TIMESTAMP 
        WHERE id = $11 RETURNING *`,
        [status || null, denyReason || null, confirmedAt || null, line || null, busModel || null, busPrefix || null, startTime || null, endTime || null, observations || null, scheduleType || null, id]
      );
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Escala não encontrada" });
      }
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        date: r.date,
        line: r.line,
        busModel: r.bus_model,
        busPrefix: r.bus_prefix,
        startTime: r.start_time,
        endTime: r.end_time,
        scheduleType: r.schedule_type,
        observations: r.observations,
        status: r.status,
        denyReason: r.deny_reason,
        confirmedAt: r.confirmed_at,
        updatedAt: r.updated_at,
      });
    } catch (error) {
      console.error("Error updating schedule:", error);
      res.status(500).json({ error: "Erro ao atualizar escala" });
    }
  });

  app.delete("/api/schedules/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      await pool.query("DELETE FROM schedules WHERE id = $1", [id]);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting schedule:", error);
      res.status(500).json({ error: "Erro ao deletar escala" });
    }
  });

  // ─── CNH API ────────────────────────────────────────────────────────────

  app.get("/api/cnh", async (_req: Request, res: Response) => {
    try {
      const result = await pool.query(
        `SELECT c.*, u.name as driver_name 
         FROM cnh_records c 
         LEFT JOIN users u ON c.driver_id = u.id 
         ORDER BY u.name ASC`
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        driverName: r.driver_name,
        number: r.number,
        category: r.category,
        expiryDate: r.expiry_date,
        totalPoints: r.total_points,
        usedPoints: r.used_points,
        status: r.status,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      })));
    } catch (error) {
      console.error("Error fetching CNH records:", error);
      res.status(500).json({ error: "Erro ao buscar CNHs" });
    }
  });

  app.get("/api/cnh/driver/:driverId", async (req: Request, res: Response) => {
    try {
      const { driverId } = req.params;
      const result = await pool.query("SELECT * FROM cnh_records WHERE driver_id = $1", [driverId]);
      if (result.rows.length === 0) {
        return res.json(null);
      }
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        number: r.number,
        category: r.category,
        expiryDate: r.expiry_date,
        totalPoints: r.total_points,
        usedPoints: r.used_points,
        status: r.status,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      });
    } catch (error) {
      console.error("Error fetching CNH:", error);
      res.status(500).json({ error: "Erro ao buscar CNH" });
    }
  });

  app.post("/api/cnh", async (req: Request, res: Response) => {
    try {
      const { driverId, number, category, expiryDate } = req.body;
      if (!driverId || !number) {
        return res.status(400).json({ error: "Motorista e número da CNH são obrigatórios" });
      }
      const result = await pool.query(
        "INSERT INTO cnh_records (driver_id, number, category, expiry_date) VALUES ($1, $2, $3, $4) RETURNING *",
        [driverId, number, category || null, expiryDate || null]
      );
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        number: r.number,
        category: r.category,
        expiryDate: r.expiry_date,
        totalPoints: r.total_points,
        usedPoints: r.used_points,
        status: r.status,
      });
    } catch (error: any) {
      console.error("Error creating CNH:", error);
      if (error.code === "23505") {
        return res.status(400).json({ error: "CNH já cadastrada para este motorista" });
      }
      res.status(500).json({ error: "Erro ao criar CNH" });
    }
  });

  app.put("/api/cnh/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { usedPoints, status, category, expiryDate, number } = req.body;
      const result = await pool.query(
        `UPDATE cnh_records SET 
          used_points = COALESCE($1, used_points), 
          status = COALESCE($2, status),
          category = COALESCE($3, category),
          expiry_date = COALESCE($4, expiry_date),
          number = COALESCE($5, number),
          updated_at = CURRENT_TIMESTAMP 
        WHERE id = $6 RETURNING *`,
        [usedPoints !== undefined ? usedPoints : null, status || null, category || null, expiryDate || null, number || null, id]
      );
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "CNH não encontrada" });
      }
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        number: r.number,
        category: r.category,
        expiryDate: r.expiry_date,
        totalPoints: r.total_points,
        usedPoints: r.used_points,
        status: r.status,
        updatedAt: r.updated_at,
      });
    } catch (error) {
      console.error("Error updating CNH:", error);
      res.status(500).json({ error: "Erro ao atualizar CNH" });
    }
  });

  // ─── Fines API ──────────────────────────────────────────────────────────

  app.get("/api/fines", async (_req: Request, res: Response) => {
    try {
      const result = await pool.query(
        `SELECT f.*, u.name as driver_name 
         FROM fines f 
         LEFT JOIN users u ON f.driver_id = u.id 
         ORDER BY f.date DESC`
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        driverName: r.driver_name,
        cnhId: r.cnh_id,
        type: r.type,
        description: r.description,
        points: r.points,
        value: r.value,
        date: r.date,
        createdAt: r.created_at,
      })));
    } catch (error) {
      console.error("Error fetching fines:", error);
      res.status(500).json({ error: "Erro ao buscar multas" });
    }
  });

  app.get("/api/fines/driver/:driverId", async (req: Request, res: Response) => {
    try {
      const { driverId } = req.params;
      const result = await pool.query(
        "SELECT * FROM fines WHERE driver_id = $1 ORDER BY date DESC",
        [driverId]
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        cnhId: r.cnh_id,
        type: r.type,
        description: r.description,
        points: r.points,
        value: r.value,
        date: r.date,
        createdAt: r.created_at,
      })));
    } catch (error) {
      console.error("Error fetching fines:", error);
      res.status(500).json({ error: "Erro ao buscar multas" });
    }
  });

  app.post("/api/fines", async (req: Request, res: Response) => {
    try {
      const { driverId, cnhId, type, description, points, value, date } = req.body;
      if (!driverId || !cnhId || !type || !points || !date) {
        return res.status(400).json({ error: "Campos obrigatórios: motorista, CNH, tipo, pontos, data" });
      }
      const result = await pool.query(
        "INSERT INTO fines (driver_id, cnh_id, type, description, points, value, date) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *",
        [driverId, cnhId, type, description || null, points, value || null, date]
      );
      // Atualizar pontos da CNH
      const cnhResult = await pool.query("SELECT * FROM cnh_records WHERE id = $1", [cnhId]);
      if (cnhResult.rows.length > 0) {
        const cnh = cnhResult.rows[0];
        const newUsed = (cnh.used_points || 0) + parseInt(points);
        let newStatus = "active";
        if (newUsed >= cnh.total_points) {
          newStatus = "blocked";
          await pool.query("UPDATE users SET is_suspended = TRUE, updated_at = CURRENT_TIMESTAMP WHERE id = $1", [driverId]);
        } else if (newUsed >= Math.floor(cnh.total_points / 2)) {
          newStatus = "suspended";
        }
        await pool.query(
          "UPDATE cnh_records SET used_points = $1, status = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3",
          [newUsed, newStatus, cnhId]
        );
      }
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        cnhId: r.cnh_id,
        type: r.type,
        description: r.description,
        points: r.points,
        value: r.value,
        date: r.date,
        createdAt: r.created_at,
      });
    } catch (error) {
      console.error("Error creating fine:", error);
      res.status(500).json({ error: "Erro ao registrar multa" });
    }
  });

  app.delete("/api/fines/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      // Buscar multa antes de deletar para recalcular pontos
      const fineResult = await pool.query("SELECT * FROM fines WHERE id = $1", [id]);
      if (fineResult.rows.length === 0) {
        return res.status(404).json({ error: "Multa não encontrada" });
      }
      const fine = fineResult.rows[0];
      await pool.query("DELETE FROM fines WHERE id = $1", [id]);
      // Recalcular pontos da CNH
      const remainingResult = await pool.query(
        "SELECT COALESCE(SUM(points), 0) as total FROM fines WHERE driver_id = $1",
        [fine.driver_id]
      );
      const usedPoints = parseInt(remainingResult.rows[0].total);
      const cnhResult = await pool.query("SELECT * FROM cnh_records WHERE driver_id = $1", [fine.driver_id]);
      if (cnhResult.rows.length > 0) {
        const cnh = cnhResult.rows[0];
        let newStatus = "active";
        if (usedPoints >= cnh.total_points) newStatus = "blocked";
        else if (usedPoints >= Math.floor(cnh.total_points / 2)) newStatus = "suspended";
        await pool.query(
          "UPDATE cnh_records SET used_points = $1, status = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3",
          [usedPoints, newStatus, cnh.id]
        );
        if (newStatus !== "blocked") {
          await pool.query("UPDATE users SET is_suspended = FALSE, updated_at = CURRENT_TIMESTAMP WHERE id = $1", [fine.driver_id]);
        }
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting fine:", error);
      res.status(500).json({ error: "Erro ao excluir multa" });
    }
  });

  // ─── Trainings API ──────────────────────────────────────────────────────

  app.get("/api/trainings", async (_req: Request, res: Response) => {
    try {
      const result = await pool.query(
        `SELECT t.*, u.name as driver_name 
         FROM trainings t 
         LEFT JOIN users u ON t.driver_id = u.id 
         ORDER BY t.created_at DESC`
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        driverName: r.driver_name,
        title: r.title,
        description: r.description,
        requiredHours: r.required_hours,
        status: r.status,
        approvedBy: r.approved_by,
        approvedAt: r.approved_at,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      })));
    } catch (error) {
      console.error("Error fetching trainings:", error);
      res.status(500).json({ error: "Erro ao buscar treinamentos" });
    }
  });

  app.get("/api/trainings/driver/:driverId", async (req: Request, res: Response) => {
    try {
      const { driverId } = req.params;
      const result = await pool.query(
        "SELECT * FROM trainings WHERE driver_id = $1 ORDER BY created_at DESC",
        [driverId]
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        title: r.title,
        description: r.description,
        requiredHours: r.required_hours,
        status: r.status,
        approvedBy: r.approved_by,
        approvedAt: r.approved_at,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      })));
    } catch (error) {
      console.error("Error fetching trainings:", error);
      res.status(500).json({ error: "Erro ao buscar treinamentos" });
    }
  });

  app.post("/api/trainings", async (req: Request, res: Response) => {
    try {
      const { driverId, title, description, requiredHours } = req.body;
      if (!driverId || !title) {
        return res.status(400).json({ error: "Motorista e título são obrigatórios" });
      }
      const result = await pool.query(
        "INSERT INTO trainings (driver_id, title, description, required_hours) VALUES ($1, $2, $3, $4) RETURNING *",
        [driverId, title, description || null, requiredHours || null]
      );
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        title: r.title,
        description: r.description,
        requiredHours: r.required_hours,
        status: r.status,
        createdAt: r.created_at,
      });
    } catch (error) {
      console.error("Error creating training:", error);
      res.status(500).json({ error: "Erro ao criar treinamento" });
    }
  });

  app.put("/api/trainings/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { status, approvedBy, title, description } = req.body;
      const approvedAt = status === "approved" ? new Date().toISOString() : null;
      const result = await pool.query(
        `UPDATE trainings SET 
          status = COALESCE($1, status),
          approved_by = COALESCE($2, approved_by),
          approved_at = COALESCE($3, approved_at),
          title = COALESCE($4, title),
          description = COALESCE($5, description),
          updated_at = CURRENT_TIMESTAMP 
        WHERE id = $6 RETURNING *`,
        [status || null, approvedBy || null, approvedAt, title || null, description || null, id]
      );
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Treinamento não encontrado" });
      }
      // Se aprovado, desbloquear motorista
      if (status === "approved") {
        const training = result.rows[0];
        await pool.query("UPDATE users SET is_suspended = FALSE, updated_at = CURRENT_TIMESTAMP WHERE id = $1", [training.driver_id]);
        // Resetar CNH se estava bloqueada
        await pool.query(
          "UPDATE cnh_records SET status = 'active', used_points = 0, updated_at = CURRENT_TIMESTAMP WHERE driver_id = $1 AND status = 'blocked'",
          [training.driver_id]
        );
      }
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        title: r.title,
        description: r.description,
        status: r.status,
        approvedBy: r.approved_by,
        approvedAt: r.approved_at,
        updatedAt: r.updated_at,
      });
    } catch (error) {
      console.error("Error updating training:", error);
      res.status(500).json({ error: "Erro ao atualizar treinamento" });
    }
  });

  // ─── Punches API ────────────────────────────────────────────────────────

  app.get("/api/punches", async (_req: Request, res: Response) => {
    try {
      const result = await pool.query(
        `SELECT p.*, u.name as driver_name 
         FROM punch_records p 
         LEFT JOIN users u ON p.driver_id = u.id 
         ORDER BY p.timestamp DESC`
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        driverName: r.driver_name,
        scheduleId: r.schedule_id,
        type: r.type,
        timestamp: r.timestamp,
        note: r.note,
        photoUrl: r.photo_url,
        createdAt: r.created_at,
      })));
    } catch (error) {
      console.error("Error fetching punches:", error);
      res.status(500).json({ error: "Erro ao buscar registros de ponto" });
    }
  });

  app.get("/api/punches/driver/:driverId", async (req: Request, res: Response) => {
    try {
      const { driverId } = req.params;
      const result = await pool.query(
        "SELECT * FROM punch_records WHERE driver_id = $1 ORDER BY timestamp DESC",
        [driverId]
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        scheduleId: r.schedule_id,
        type: r.type,
        timestamp: r.timestamp,
        note: r.note,
        photoUrl: r.photo_url,
        createdAt: r.created_at,
      })));
    } catch (error) {
      console.error("Error fetching punches:", error);
      res.status(500).json({ error: "Erro ao buscar registros de ponto" });
    }
  });

  app.post("/api/punches", async (req: Request, res: Response) => {
    try {
      const { driverId, scheduleId, type, timestamp, note, photoUrl } = req.body;
      if (!driverId || !type || !timestamp) {
        return res.status(400).json({ error: "Motorista, tipo e horário são obrigatórios" });
      }
      const result = await pool.query(
        "INSERT INTO punch_records (driver_id, schedule_id, type, timestamp, note, photo_url) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
        [driverId, scheduleId || null, type, timestamp, note || null, photoUrl || null]
      );
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        scheduleId: r.schedule_id,
        type: r.type,
        timestamp: r.timestamp,
        note: r.note,
        photoUrl: r.photo_url,
        createdAt: r.created_at,
      });
    } catch (error) {
      console.error("Error creating punch:", error);
      res.status(500).json({ error: "Erro ao registrar ponto" });
    }
  });

  // ─── Occurrences API ────────────────────────────────────────────────────

  app.get("/api/occurrences", async (_req: Request, res: Response) => {
    try {
      const result = await pool.query(
        `SELECT o.*, u.name as driver_name 
         FROM occurrences o 
         LEFT JOIN users u ON o.driver_id = u.id 
         ORDER BY o.created_at DESC`
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        driverName: r.driver_name,
        type: r.type,
        description: r.description,
        date: r.date,
        viewed: r.viewed,
        createdAt: r.created_at,
      })));
    } catch (error) {
      console.error("Error fetching occurrences:", error);
      res.status(500).json({ error: "Erro ao buscar ocorrências" });
    }
  });

  app.get("/api/occurrences/driver/:driverId", async (req: Request, res: Response) => {
    try {
      const { driverId } = req.params;
      const result = await pool.query(
        "SELECT * FROM occurrences WHERE driver_id = $1 ORDER BY created_at DESC",
        [driverId]
      );
      res.json(result.rows.map(r => ({
        id: r.id,
        driverId: r.driver_id,
        type: r.type,
        description: r.description,
        date: r.date,
        viewed: r.viewed,
        createdAt: r.created_at,
      })));
    } catch (error) {
      console.error("Error fetching occurrences:", error);
      res.status(500).json({ error: "Erro ao buscar ocorrências" });
    }
  });

  app.post("/api/occurrences", async (req: Request, res: Response) => {
    try {
      const { driverId, type, description, date } = req.body;
      if (!driverId || !type || !date) {
        return res.status(400).json({ error: "Motorista, tipo e data são obrigatórios" });
      }
      const result = await pool.query(
        "INSERT INTO occurrences (driver_id, type, description, date) VALUES ($1, $2, $3, $4) RETURNING *",
        [driverId, type, description || null, date]
      );
      const r = result.rows[0];
      res.json({
        id: r.id,
        driverId: r.driver_id,
        type: r.type,
        description: r.description,
        date: r.date,
        viewed: r.viewed,
        createdAt: r.created_at,
      });
    } catch (error) {
      console.error("Error creating occurrence:", error);
      res.status(500).json({ error: "Erro ao criar ocorrência" });
    }
  });

  app.put("/api/occurrences/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { viewed } = req.body;
      const result = await pool.query(
        "UPDATE occurrences SET viewed = $1 WHERE id = $2 RETURNING *",
        [viewed ? 1 : 0, id]
      );
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Ocorrência não encontrada" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating occurrence:", error);
      res.status(500).json({ error: "Erro ao atualizar ocorrência" });
    }
  });

};

export async function initializeDatabase() {
  const client = await pool.connect();
  try {
    // Criar tabelas
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name VARCHAR(255) NOT NULL,
        username VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) DEFAULT 'driver',
        driver_id VARCHAR(50),
        whatsapp VARCHAR(20),
        photo_uri TEXT,
        is_suspended BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS schedules (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        date DATE NOT NULL,
        line VARCHAR(100) NOT NULL,
        bus_model VARCHAR(100),
        bus_prefix VARCHAR(50),
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        schedule_type VARCHAR(20) DEFAULT 'work',
        observations TEXT,
        status VARCHAR(20) DEFAULT 'pending',
        deny_reason TEXT,
        confirmed_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS cnh_records (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
        number VARCHAR(50) NOT NULL,
        category VARCHAR(10),
        expiry_date DATE,
        total_points INT DEFAULT 40,
        used_points INT DEFAULT 0,
        status VARCHAR(20) DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fines (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        cnh_id UUID NOT NULL REFERENCES cnh_records(id) ON DELETE CASCADE,
        type VARCHAR(50) NOT NULL,
        description TEXT,
        points INT NOT NULL,
        value DECIMAL(10, 2),
        date DATE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS trainings (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        required_hours INT,
        status VARCHAR(20) DEFAULT 'pending',
        approved_by VARCHAR(255),
        approved_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS punch_records (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        schedule_id UUID REFERENCES schedules(id) ON DELETE SET NULL,
        type VARCHAR(20) NOT NULL,
        timestamp TIMESTAMP NOT NULL,
        note TEXT,
        photo_url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS occurrences (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        type VARCHAR(100) NOT NULL,
        description TEXT,
        date DATE NOT NULL,
        viewed INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Índices para melhor performance
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_schedules_driver_id ON schedules(driver_id);
      CREATE INDEX IF NOT EXISTS idx_schedules_date ON schedules(date);
      CREATE INDEX IF NOT EXISTS idx_fines_driver_id ON fines(driver_id);
      CREATE INDEX IF NOT EXISTS idx_punch_records_driver_id ON punch_records(driver_id);
      CREATE INDEX IF NOT EXISTS idx_occurrences_driver_id ON occurrences(driver_id);
    `);

    // Criar usuário admin padrão se não existir
    await client.query(
      "INSERT INTO users (name, username, password, role) VALUES ($1, $2, $3, $4) ON CONFLICT (username) DO NOTHING",
      ["Administrador", "admin", "admin123", "admin"]
    );

    console.log("✅ Database initialized successfully");
  } catch (error) {
    console.error("❌ Error initializing database:", error);
    throw error;
  } finally {
    client.release();
  }
}
