import { Pool, PoolClient } from "pg";

const DATABASE_URL = process.env.DATABASE_URL || "postgresql://postgres:postgres@localhost:5432/escalaonibus";

const pool = new Pool({
  connectionString: DATABASE_URL,
});

export async function getDb(): Promise<PoolClient> {
  return pool.connect();
}

export async function initializeDatabase() {
  const client = await getDb();
  try {
    // Create users table
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name VARCHAR(255) NOT NULL,
        username VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) DEFAULT 'driver',
        driver_id VARCHAR(50),
        whatsapp VARCHAR(20),
        photo_uri TEXT,
        is_suspended BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create schedules table
    await client.query(`
      CREATE TABLE IF NOT EXISTS schedules (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        date DATE NOT NULL,
        line VARCHAR(100) NOT NULL,
        bus_model VARCHAR(100),
        bus_prefix VARCHAR(50),
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        schedule_type VARCHAR(20) DEFAULT 'work',
        observations TEXT,
        status VARCHAR(20) DEFAULT 'pending',
        deny_reason TEXT,
        confirmed_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(driver_id, date)
      );
    `);

    // Create CNH records table
    await client.query(`
      CREATE TABLE IF NOT EXISTS cnh_records (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
        number VARCHAR(50) NOT NULL,
        category VARCHAR(10),
        expiry_date DATE,
        total_points INT DEFAULT 40,
        used_points INT DEFAULT 0,
        status VARCHAR(20) DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create fines table
    await client.query(`
      CREATE TABLE IF NOT EXISTS fines (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        cnh_id UUID NOT NULL REFERENCES cnh_records(id) ON DELETE CASCADE,
        type VARCHAR(50) NOT NULL,
        description TEXT,
        points INT NOT NULL,
        value DECIMAL(10, 2),
        date DATE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create trainings table
    await client.query(`
      CREATE TABLE IF NOT EXISTS trainings (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        required_hours INT,
        status VARCHAR(20) DEFAULT 'pending',
        approved_by VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create punch records table
    await client.query(`
      CREATE TABLE IF NOT EXISTS punch_records (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        schedule_id UUID REFERENCES schedules(id) ON DELETE SET NULL,
        type VARCHAR(20) NOT NULL,
        timestamp TIMESTAMP NOT NULL,
        note TEXT,
        photo_url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create occurrences table
    await client.query(`
      CREATE TABLE IF NOT EXISTS occurrences (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        driver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        type VARCHAR(100) NOT NULL,
        description TEXT,
        date DATE NOT NULL,
        viewed INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create indexes for better performance
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_schedules_driver_id ON schedules(driver_id);
      CREATE INDEX IF NOT EXISTS idx_schedules_date ON schedules(date);
      CREATE INDEX IF NOT EXISTS idx_fines_driver_id ON fines(driver_id);
      CREATE INDEX IF NOT EXISTS idx_punch_records_driver_id ON punch_records(driver_id);
      CREATE INDEX IF NOT EXISTS idx_occurrences_driver_id ON occurrences(driver_id);
    `);

    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Error initializing database:", error);
    throw error;
  } finally {
    client.release();
  }
}

export async function closeDatabase() {
  await pool.end();
}
