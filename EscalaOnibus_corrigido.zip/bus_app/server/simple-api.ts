import express, { Request, Response } from "express";

/**
 * Simple API — apenas rotas auxiliares que não conflitam com o api.ts (PostgreSQL).
 *
 * IMPORTANTE: As rotas de auth, drivers, schedules, cnh, fines, trainings,
 * punches e occurrences foram REMOVIDAS daqui para evitar conflito com o
 * api.ts que usa PostgreSQL como fonte de dados persistente.
 *
 * O armazenamento em memória era zerado a cada reinício do servidor, fazendo
 * com que motoristas criados pelo admin não conseguissem fazer login.
 */
export function setupSimpleAPI(app: express.Express) {
  // Rota de sincronização — retorna status do servidor
  app.get("/api/sync", (_req: Request, res: Response) => {
    res.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      message: "Dados persistidos no PostgreSQL",
    });
  });

  console.log("✅ Simple API initialized (PostgreSQL mode)");
}
