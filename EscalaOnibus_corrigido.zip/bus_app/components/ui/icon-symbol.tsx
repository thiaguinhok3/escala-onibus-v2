import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<string, ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

const MAPPING = {
  // Navigation
  "house.fill": "home",
  "calendar.fill": "calendar-today",
  "person.fill": "person",
  "person.2.fill": "group",
  "doc.text.fill": "description",
  "clock.fill": "schedule",
  "chart.bar.fill": "bar-chart",
  // Actions
  "paperplane.fill": "send",
  "plus": "add",
  "pencil": "edit",
  "trash": "delete",
  "checkmark": "check",
  "xmark": "close",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "chevron.left.forwardslash.chevron.right": "code",
  "eye": "visibility",
  "eye.slash": "visibility-off",
  // Status
  "checkmark.circle.fill": "check-circle",
  "xmark.circle.fill": "cancel",
  "clock": "pending",
  "exclamationmark.triangle.fill": "warning",
  // Bus/Transport
  "bus.fill": "directions-bus",
  "map.fill": "map",
  // Misc
  "bell.fill": "notifications",
  "gear": "settings",
  "arrow.right.square": "logout",
  "lock.fill": "lock",
  "phone.fill": "phone",
  "envelope.fill": "email",
} as IconMapping;

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return (
    <MaterialIcons
      color={color}
      size={size}
      name={MAPPING[name] ?? "help"}
      style={style}
    />
  );
}
