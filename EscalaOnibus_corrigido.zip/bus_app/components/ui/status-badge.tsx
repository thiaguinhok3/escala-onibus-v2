import React from "react";
import { View, Text } from "react-native";
import type { ScheduleStatus } from "@/lib/database";

interface StatusBadgeProps {
  status: ScheduleStatus;
  size?: "sm" | "md";
}

const CONFIG: Record<ScheduleStatus, { label: string; bg: string; text: string }> = {
  pending: { label: "Pendente", bg: "#FEF3C7", text: "#92400E" },
  approved: { label: "Aprovada", bg: "#DCFCE7", text: "#14532D" },
  denied: { label: "Negada", bg: "#FEE2E2", text: "#7F1D1D" },
};

export function StatusBadge({ status, size = "md" }: StatusBadgeProps) {
  const cfg = CONFIG[status];
  const paddingH = size === "sm" ? 8 : 12;
  const paddingV = size === "sm" ? 2 : 4;
  const fontSize = size === "sm" ? 11 : 12;

  return (
    <View
      style={{
        backgroundColor: cfg.bg,
        paddingHorizontal: paddingH,
        paddingVertical: paddingV,
        borderRadius: 999,
        alignSelf: "flex-start",
      }}
    >
      <Text style={{ color: cfg.text, fontSize, fontWeight: "600" }}>
        {cfg.label}
      </Text>
    </View>
  );
}
