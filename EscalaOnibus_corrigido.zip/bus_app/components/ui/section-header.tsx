import React from "react";
import { View, Text } from "react-native";
import { useColors } from "@/hooks/use-colors";

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
}

export function SectionHeader({ title, subtitle }: SectionHeaderProps) {
  const colors = useColors();
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={{ fontSize: 20, fontWeight: "700", color: colors.foreground }}>
        {title}
      </Text>
      {subtitle ? (
        <Text style={{ fontSize: 13, color: colors.muted, marginTop: 2 }}>
          {subtitle}
        </Text>
      ) : null}
    </View>
  );
}
