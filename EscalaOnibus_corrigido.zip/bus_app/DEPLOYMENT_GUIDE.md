# 🚀 Guia Completo de Deployment - EscalaOnibus

Este guia passo a passo para colocar o EscalaOnibus em produção.

## 📋 Checklist de Configuração

- [x] Banco de dados PostgreSQL criado no Neon.tech
- [x] Backend atualizado para usar API remota
- [x] Frontend atualizado para usar API remota
- [x] Autenticação configurada
- [ ] Repositório criado no GitHub
- [ ] Backend deployado no Render
- [ ] App testado em produção

## 1️⃣ Criar Repositório no GitHub

### Opção A: Via Interface Web (Recomendado)

1. Acesse [github.com/new](https://github.com/new)
2. Preencha:
   - **Repository name**: `bus_driver_schedule`
   - **Description**: `EscalaOnibus - Sistema de Gestão de Escalas de Motoristas`
   - **Private**: ✅ Marque como privado
   - **Initialize**: Deixe em branco (já temos conteúdo)
3. Clique em "Create repository"

### Opção B: Via CLI

```bash
gh repo create bus_driver_schedule --private --description "EscalaOnibus - Sistema de Gestão de Escalas de Motoristas"
```

## 2️⃣ Fazer Push do Código

```bash
cd /home/ubuntu/bus_app

# Configurar remote (se não estiver configurado)
git remote add origin https://github.com/SEU_USUARIO/bus_driver_schedule.git

# Fazer push
git push -u origin main
```

## 3️⃣ Configurar Backend no Render

### Passo 1: Criar Web Service

1. Acesse [render.com](https://render.com)
2. Clique em "New +" → "Web Service"
3. Conecte seu repositório GitHub
4. Selecione `bus_driver_schedule`

### Passo 2: Configurar Serviço

| Campo | Valor |
|-------|-------|
| **Name** | `escalaonibus-api` |
| **Environment** | `Node` |
| **Build Command** | `pnpm install && pnpm build` |
| **Start Command** | `pnpm start` |
| **Plan** | Free |

### Passo 3: Adicionar Variáveis de Ambiente

Clique em "Environment" e adicione:

```
DATABASE_URL=postgresql://neondb_owner:npg_Sx7rIvH1uWNA@ep-aged-feather-amazlq0g.c-5.us-east-1.aws.neon.tech/neondb?sslmode=require
NODE_ENV=production
PORT=3000
```

**⚠️ IMPORTANTE**: Substitua `npg_Sx7rIvH1uWNA` pela sua senha do Neon (encontrada em `.env`)

### Passo 4: Deploy

1. Clique em "Create Web Service"
2. Aguarde o build (pode levar 2-5 minutos)
3. Quando concluído, você terá uma URL como: `https://escalaonibus-api.onrender.com`

## 4️⃣ Atualizar URL da API no App

Após o backend estar deployado, atualize a URL:

### Arquivo: `app.config.ts`

```typescript
const env = {
  appName: "EscalaOnibus",
  appSlug: "bus_driver_schedule",
  logoUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663523554173/dRxP3go2zZKSjsWynqrK2q/icon-aZCTafXqhQS4myEpmXMBWq.png",
  scheme: schemeFromBundleId,
  iosBundleId: bundleId,
  androidPackage: bundleId,
  apiUrl: "https://escalaonibus-api.onrender.com", // ← ADICIONE ESTA LINHA
};
```

### Arquivo: `lib/api-client.ts`

```typescript
const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || "https://escalaonibus-api.onrender.com";
```

### Arquivo: `.env.production`

```env
DATABASE_URL=postgresql://neondb_owner:npg_Sx7rIvH1uWNA@ep-aged-feather-amazlq0g.c-5.us-east-1.aws.neon.tech/neondb?sslmode=require
EXPO_PUBLIC_API_URL=https://escalaonibus-api.onrender.com
NODE_ENV=production
```

## 5️⃣ Testar Backend em Produção

```bash
# Testar health check
curl https://escalaonibus-api.onrender.com/api/health

# Resposta esperada:
# {"ok":true,"timestamp":1234567890}
```

## 6️⃣ Testar Login em Produção

```bash
# Fazer login com usuário padrão
curl -X POST https://escalaonibus-api.onrender.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Resposta esperada:
# {"id":"admin-001","name":"Administrador","username":"admin","role":"admin"}
```

## 7️⃣ Testar App Mobile

### Via Expo Go

```bash
pnpm run qr
```

Escaneie o QR code com Expo Go. O app vai conectar ao backend em produção.

### Testar Login

1. Abra o app
2. Digite: `admin` / `admin123`
3. Você deve ver o dashboard do admin

## 🔍 Troubleshooting

### Erro: "Cannot connect to API"

**Solução**: Verifique se:
1. O backend está rodando no Render (check status em dashboard)
2. A URL em `.env.production` está correta
3. A DATABASE_URL está configurada no Render
4. Firewall/VPN não está bloqueando

### Erro: "Database connection failed"

**Solução**: Verifique:
1. A DATABASE_URL está correta (copie de `.env`)
2. O Neon.tech está acessível (teste com `psql`)
3. A senha não tem caracteres especiais não escapados

### App não sincroniza dados

**Solução**:
1. Verifique internet do celular
2. Tente fazer logout e login novamente
3. Verifique logs do backend: `render.com` → seu serviço → "Logs"

## 📊 Monitorar em Produção

### Render Dashboard

1. Acesse seu serviço no Render
2. Veja "Metrics": CPU, memória, requisições
3. Veja "Logs" para erros

### Neon Dashboard

1. Acesse [console.neon.tech](https://console.neon.tech)
2. Veja "Monitoring": conexões, queries lentas
3. Veja "Branches" para gerenciar ambientes

## 🔐 Segurança em Produção

### Checklist

- [ ] DATABASE_URL não está em `.env` (apenas em Render)
- [ ] Senhas padrão foram alteradas (admin123 → senha forte)
- [ ] CORS está configurado corretamente
- [ ] SSL/TLS está ativado (Render faz automaticamente)
- [ ] Backups do banco estão configurados

### Alterar Senha Admin

1. Acesse o app como admin
2. Vá para Perfil
3. Clique "Alterar Senha"
4. Digite a nova senha forte

## 📱 Build de Produção (iOS/Android)

### Gerar APK/IPA

```bash
# Instalar EAS CLI
npm install -g eas-cli

# Login
eas login

# Build
eas build --platform all

# Após completar, baixe os arquivos e distribua
```

## 🎯 Próximos Passos

1. ✅ Testar login com admin/admin123
2. ✅ Criar novos motoristas via admin
3. ✅ Testar login com motorista
4. ✅ Testar criar escala
5. ✅ Testar ponto eletrônico
6. ✅ Testar ocorrências
7. ✅ Verificar sincronização entre celulares

## 📞 Suporte

Dúvidas? Entre em contato via WhatsApp: **(19) 99560-5536**

---

**Última atualização**: Abril 2026
