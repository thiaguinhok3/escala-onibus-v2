# Deploy do EscalaOnibus no Render.com com PostgreSQL

## Passo 1: Criar conta no Render.com

1. Acesse [render.com](https://render.com)
2. Clique em "Sign Up"
3. Crie uma conta (pode usar GitHub para facilitar)

## Passo 2: Criar banco de dados PostgreSQL no Render

1. No Render, clique em "New +" → "PostgreSQL"
2. Configure:
   - **Name**: `escalaonibus-db`
   - **Database**: `escalaonibus`
   - **User**: `postgres`
   - **Region**: Escolha a mais próxima
   - **Plan**: Free (até 1GB)
3. Clique em "Create Database"
4. Copie a **External Database URL** (será algo como `postgresql://user:pass@host:5432/db`)

## Passo 3: Criar Web Service no Render

1. No Render, clique em "New +" → "Web Service"
2. Selecione "Deploy an existing repository"
3. Conecte sua conta GitHub e selecione `bus_driver_schedule`
4. Configure:
   - **Name**: `escalaonibus-api`
   - **Environment**: Node
   - **Build Command**: `pnpm install && pnpm build`
   - **Start Command**: `pnpm start`
   - **Plan**: Free

## Passo 4: Configurar variáveis de ambiente

No Render Web Service, vá para "Environment" e adicione:

```
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://user:password@host:5432/escalaonibus
```

Cole a URL do banco de dados que você copiou no Passo 2.

## Passo 5: Deploy

Clique em "Create Web Service". O Render fará o deploy automaticamente.

Após o deploy, você receberá uma URL como: `https://escalaonibus-api.onrender.com`

## Passo 6: Atualizar o app mobile

No arquivo `.env` do app, configure:
```
EXPO_PUBLIC_API_URL=https://escalaonibus-api.onrender.com
```

## Testando a conexão

```bash
# Testar se o servidor está rodando
curl https://escalaonibus-api.onrender.com/api/health

# Testar login com admin padrão
curl -X POST https://escalaonibus-api.onrender.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

## Notas importantes

- O plano free do Render coloca o serviço em sleep após 15 minutos sem requisições
- Na primeira requisição após o sleep, pode levar alguns segundos para acordar
- O banco de dados PostgreSQL free tem limite de 1GB
- Para produção, considere um plano pago

## Dados persistidos

Todos os dados agora são armazenados no PostgreSQL:
- ✅ Motoristas
- ✅ Escalas
- ✅ CNH e multas
- ✅ Ponto eletrônico
- ✅ Ocorrências

Quando você trocar de celular, todos os dados estarão disponíveis no servidor!
