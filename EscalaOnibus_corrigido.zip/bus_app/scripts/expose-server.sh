#!/bin/bash

# Script para expor o servidor local para a internet usando ngrok
# Uso: ./scripts/expose-server.sh

echo "🚀 Expondo servidor EscalaOnibus para a internet..."
echo ""

# Verificar se ngrok está instalado
if ! command -v ngrok &> /dev/null; then
    echo "❌ ngrok não está instalado!"
    echo "Instale com: curl https://ngrok-agent.s3.amazonaws.com/ngrok-v3-stable-linux-amd64.zip -o ngrok.zip && unzip ngrok.zip && sudo mv ngrok /usr/local/bin/"
    exit 1
fi

# Verificar se o servidor está rodando
if ! curl -s http://localhost:3000/api/health > /dev/null 2>&1; then
    echo "⚠️  Servidor não está rodando em http://localhost:3000"
    echo "Inicie o servidor com: pnpm dev"
    exit 1
fi

echo "✅ Servidor detectado em http://localhost:3000"
echo ""
echo "📡 Expondo para a internet..."
echo ""

# Expor a porta 3000 com ngrok
ngrok http 3000 --log=stdout

# Quando ngrok for encerrado, mostrar mensagem
echo ""
echo "❌ Conexão encerrada"
echo "Para acessar o app, use a URL mostrada acima"
