/**
 * Vercel Serverless Function — Entry point para todas as rotas /api/*
 *
 * O vercel.json redireciona todas as chamadas /api/* para este arquivo.
 * Aqui montamos o Express app com as mesmas rotas do servidor local.
 */
import "dotenv/config";
import express from "express";
import { setupAPI, initializeDatabase } from "../server/api";

const app = express();

// CORS
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin) {
    res.header("Access-Control-Allow-Origin", origin);
  } else {
    res.header("Access-Control-Allow-Origin", "*");
  }
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, PATCH");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization",
  );
  res.header("Access-Control-Allow-Credentials", "true");
  if (req.method === "OPTIONS") {
    res.sendStatus(200);
    return;
  }
  next();
});

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Inicializar banco e rotas
let initialized = false;
async function ensureInitialized() {
  if (!initialized) {
    await initializeDatabase();
    setupAPI(app);
    initialized = true;
  }
}

// Handler principal
export default async function handler(req: any, res: any) {
  await ensureInitialized();
  app(req, res);
}
