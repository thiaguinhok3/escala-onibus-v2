# Design do App — EscalaOnibus

## Visão Geral

Aplicativo mobile para gerenciamento de escalas de motoristas de ônibus. Dois perfis de acesso: **Admin** e **Motorista**. Interface profissional, limpa e funcional, inspirada em apps de gestão corporativa iOS.

---

## Paleta de Cores

| Token | Valor | Uso |
|-------|-------|-----|
| `primary` | `#1A56DB` | Ações principais, botões, destaques |
| `background` | `#F8FAFC` / `#0F172A` | Fundo de telas |
| `surface` | `#FFFFFF` / `#1E293B` | Cards, modais |
| `foreground` | `#1E293B` / `#F1F5F9` | Texto principal |
| `muted` | `#64748B` / `#94A3B8` | Texto secundário |
| `border` | `#E2E8F0` / `#334155` | Bordas, divisores |
| `success` | `#16A34A` / `#4ADE80` | Escala aprovada |
| `warning` | `#D97706` / `#FBBF24` | Escala pendente |
| `error` | `#DC2626` / `#F87171` | Escala negada, erros |

---

## Telas

### Tela de Login
- Logo do app centralizado
- Campo usuário e senha
- Botão "Entrar" com feedback de carregamento
- Detecção automática do perfil (Admin ou Motorista)

---

### App Admin — 4 Tabs

#### Tab 1 — Escalas (Home)
- Header com data atual e saudação
- Cards de resumo: total de escalas hoje, aprovadas, pendentes, negadas
- Lista de escalas do dia com status visual (badge colorido)
- Botão FAB para criar nova escala
- Filtro por data (DatePicker)

#### Tab 2 — Motoristas
- Lista de motoristas cadastrados (FlatList)
- Card por motorista: nome, ID, WhatsApp
- Botão FAB para adicionar motorista
- Swipe para editar/excluir
- Modal de criação/edição com campos: Nome, WhatsApp, ID Motorista, Usuário, Senha

#### Tab 3 — Relatórios
- Lista de ocorrências enviadas pelos motoristas
- Card: motorista, data, tipo de problema, descrição
- Badge de status (novo / visualizado)
- Toque para ver detalhes completos

#### Tab 4 — Perfil Admin
- Nome e cargo do admin
- Opção de alterar senha
- Informações do sistema (versão)
- Botão de sair

---

### App Motorista — 4 Tabs

#### Tab 1 — Minha Escala (Home)
- Header com nome do motorista e data
- Card da escala de hoje (se houver): linha, ônibus, prefixo, horários, observações
- Badge de status: Aprovada (verde) / Pendente (amarelo) / Negada (vermelho)
- Botão "Confirmar Visualização" (quando aprovada)
- Lista de escalas dos próximos 7 dias

#### Tab 2 — Histórico
- Lista de escalas passadas com filtro por mês
- Card resumido: data, linha, status

#### Tab 3 — Ocorrências
- Formulário para reportar problema/ocorrência
- Campos: tipo (dropdown), descrição (textarea)
- Lista de ocorrências enviadas anteriormente

#### Tab 4 — Perfil Motorista
- Nome, ID, WhatsApp
- Opção de alterar senha
- Botão de sair

---

## Fluxos Principais

### Fluxo Admin — Criar Escala
1. Tab Escalas → FAB "+" → Modal de nova escala
2. Preencher: Data, Linha, Motorista (dropdown), Modelo ônibus, Prefixo, Horário início, Horário fim, Observações
3. Salvar → Escala criada com status "Pendente"
4. Na lista, tocar na escala → Ações: Aprovar / Negar

### Fluxo Motorista — Ver e Confirmar Escala
1. Tab Minha Escala → Card da escala de hoje
2. Ver detalhes: linha, ônibus, horários
3. Botão "Confirmar Visualização" → Confirmação registrada

### Fluxo Motorista — Reportar Ocorrência
1. Tab Ocorrências → Formulário
2. Selecionar tipo → Descrever → Enviar
3. Ocorrência aparece na lista do Admin (Tab Relatórios)

---

## Componentes Reutilizáveis

- `StatusBadge` — Badge colorido para status de escala
- `ScheduleCard` — Card de escala com info resumida
- `DriverCard` — Card de motorista
- `SectionHeader` — Cabeçalho de seção com título
- `EmptyState` — Tela vazia com ícone e mensagem
- `ConfirmModal` — Modal de confirmação de ação destrutiva
- `FormModal` — Modal de formulário (criar/editar)
